﻿from pathlib import Path

p = Path("smc_base.py")
s = p.read_text(encoding="utf-8")

marker = "/* ===== END MODERN DASHBOARD DESIGN ===== */"

if s.count(marker) != 1:
    raise SystemExit(f"Expected marker once, found {s.count(marker)}")

css = """
/* ===== SHAKIL AI DASHBOARD V2 ===== */
body{background:#f5f7fb;color:#172033}
nav{background:linear-gradient(135deg,#111827 0%,#1e3a8a 55%,#2563eb 100%);padding:13px 18px;position:sticky;top:0;z-index:1000}
nav .brand{font-size:20px;font-weight:800;color:#fff}
.nav-links{gap:6px}
.nav-links a{font-size:14px;padding:9px 12px;color:#e5e7eb;border-radius:8px}
.nav-links a:hover{background:rgba(255,255,255,.14);color:#fff;transform:translateY(-1px)}
.badge{border-radius:999px;padding:5px 10px;font-size:12px;font-weight:700}
.container{max-width:1320px;margin:30px auto;padding:0 22px}
.container>h1{font-size:34px;margin:0 0 5px;color:#111827}
.container>p{color:#64748b;margin:0 0 25px}

.grid{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:18px}
.stat{position:relative;overflow:hidden;min-height:125px;padding:22px 20px;border:1px solid #e5e7eb;border-radius:16px;background:#fff;box-shadow:0 5px 18px rgba(15,23,42,.06);transition:all .2s ease}
.stat:before{content:"";position:absolute;left:0;top:0;width:4px;height:100%;background:#2563eb}
.stat:hover{transform:translateY(-4px);box-shadow:0 14px 30px rgba(37,99,235,.12)}
.stat h3{margin:0;color:#64748b;font-size:14px;font-weight:700;text-transform:uppercase;letter-spacing:.4px}
.stat h2{margin:12px 0 0;font-size:36px;line-height:1;color:#172554;font-weight:800}

.card{border:1px solid #e5e7eb;border-radius:18px;background:#fff;box-shadow:0 6px 20px rgba(15,23,42,.06);padding:24px;margin-bottom:24px}
.card h2{font-size:21px;color:#111827;margin-top:0;margin-bottom:18px}
.card .grid{grid-template-columns:repeat(4,minmax(0,1fr))}
.card .stat{min-height:105px;padding:19px}

.card:has(a.btn){background:linear-gradient(135deg,#ffffff,#f8fbff)}
.btn{border:0;border-radius:9px;padding:10px 15px;font-weight:700;text-decoration:none;display:inline-block;margin:4px;transition:all .18s ease}
.btn:hover{transform:translateY(-2px);box-shadow:0 7px 18px rgba(37,99,235,.18)}

table{border:1px solid #e5e7eb;border-radius:12px;overflow:hidden}
th{background:#f8fafc;color:#334155;font-weight:750}
tr:hover td{background:#f8fbff}

@media(max-width:1000px){
  .grid{grid-template-columns:repeat(2,minmax(0,1fr))}
}
@media(max-width:800px){
  nav{position:relative;padding:10px 12px}
  .container{margin:18px auto;padding:0 12px}
  .container>h1{font-size:28px}
  .grid,.card .grid{grid-template-columns:repeat(2,minmax(0,1fr))!important;gap:12px}
  .stat{min-height:105px;padding:18px 14px}
  .stat h2{font-size:29px}
  .card{padding:17px;border-radius:14px}
}
@media(max-width:430px){
  .grid,.card .grid{grid-template-columns:1fr!important}
  .stat h2{font-size:27px}
}
/* ===== END SHAKIL AI DASHBOARD V2 ===== */
"""

p.write_text(s.replace(marker, marker + "\n" + css, 1), encoding="utf-8")
print("DASHBOARD V2 CSS APPLIED")
