﻿from pathlib import Path

path = Path("smc_base.py")
text = path.read_text(encoding="utf-8")

marker = "# ===== SHAKIL AI ACADEMY RESOURCE LIBRARY V2 ====="

if marker in text:
    print("Resource Library V2 already exists - STOP")
    raise SystemExit(0)

code = r'''

# ===== SHAKIL AI ACADEMY RESOURCE LIBRARY V2 =====

from werkzeug.utils import secure_filename
from flask import send_file
from pathlib import Path as _ResourcePath

_RESOURCE_UPLOAD_DIR = _ResourcePath(BASE_DIR) / "academy_resource_uploads"
_RESOURCE_UPLOAD_DIR.mkdir(parents=True, exist_ok=True)

_RESOURCE_ALLOWED_EXTENSIONS = {
    "pdf", "doc", "docx", "ppt", "pptx",
    "xls", "xlsx", "csv",
    "jpg", "jpeg", "png",
    "mp4", "webm"
}


def _resource_db():
    conn = sqlite3.connect(DATABASE)
    conn.row_factory = sqlite3.Row
    return conn


@app.route("/academy/resource-library")
@login_required
def academy_resource_library_v2():

    conn = _resource_db()

    resources = conn.execute("""
        SELECT id, title, category, description,
               filename, created_at, download_count
        FROM academy_resources
        ORDER BY id DESC
    """).fetchall()

    conn.close()

    rows = ""

    for resource in resources:

        rows += (
            "<tr>"
            "<td>" + str(resource["id"]) + "</td>"
            "<td>" + str(resource["title"] or "-") + "</td>"
            "<td>" + str(resource["category"] or "-") + "</td>"
            "<td>" + str(resource["description"] or "-") + "</td>"
            "<td>" + str(resource["filename"] or "-") + "</td>"
            "<td>" + str(resource["download_count"] or 0) + "</td>"
            "<td><a href='/academy/resource-library/download/" +
            str(resource["id"]) +
            "' target='_blank'>Download</a></td>"
            "</tr>"
        )

    if not rows:
        rows = (
            "<tr><td colspan='7'>"
            "No resources available."
            "</td></tr>"
        )

    html = """
    <style>
    .resource-wrap{
        max-width:1150px;
        margin:20px auto;
    }

    .resource-card{
        background:#fff;
        border:1px solid #e2e8f0;
        border-radius:14px;
        padding:22px;
        margin-bottom:20px;
        box-shadow:0 3px 10px rgba(0,0,0,.05);
    }

    .resource-title{
        font-size:24px;
        font-weight:800;
        color:#17202a;
        margin-bottom:18px;
    }

    .resource-grid{
        display:grid;
        grid-template-columns:repeat(2,1fr);
        gap:12px;
    }

    .resource-grid input,
    .resource-grid textarea{
        width:100%;
        box-sizing:border-box;
        padding:11px;
        border:1px solid #cbd5e1;
        border-radius:8px;
    }

    .resource-grid textarea{
        min-height:100px;
    }

    .resource-btn{
        padding:11px 18px;
        border:0;
        border-radius:8px;
        background:#2563eb;
        color:#fff;
        font-weight:700;
        cursor:pointer;
    }

    .resource-table{
        width:100%;
        border-collapse:collapse;
    }

    .resource-table th,
    .resource-table td{
        padding:10px;
        border-bottom:1px solid #e2e8f0;
        text-align:left;
        vertical-align:top;
    }

    .resource-table th{
        background:#f8fafc;
    }

    @media(max-width:800px){
        .resource-grid{
            grid-template-columns:1fr;
        }

        .resource-table{
            font-size:12px;
        }
    }
    </style>

    <div class="resource-wrap">

        <div class="resource-card">

            <div class="resource-title">
                Academy Resource Library
            </div>

            <form method="post"
                  action="/academy/resource-library/upload"
                  enctype="multipart/form-data">

                <div class="resource-grid">

                    <input
                        name="title"
                        placeholder="Resource title"
                        required
                    >

                    <input
                        name="category"
                        placeholder="Category / Course / Subject"
                    >

                    <textarea
                        name="description"
                        placeholder="Resource description"
                    ></textarea>

                    <input
                        type="file"
                        name="file"
                        required
                        accept=".pdf,.doc,.docx,.ppt,.pptx,.xls,.xlsx,.csv,.jpg,.jpeg,.png,.mp4,.webm"
                    >

                </div>

                <br>

                <button class="resource-btn" type="submit">
                    Upload Resource
                </button>

            </form>

        </div>

        <div class="resource-card">

            <div class="resource-title">
                Available Resources
            </div>

            <div style="overflow-x:auto">

                <table class="resource-table">

                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Title</th>
                            <th>Category</th>
                            <th>Description</th>
                            <th>File</th>
                            <th>Downloads</th>
                            <th>Action</th>
                        </tr>
                    </thead>

                    <tbody>
                        """ + rows + """
                    </tbody>

                </table>

            </div>

        </div>

    </div>
    """

    return page("Academy Resource Library", html)


@app.route("/academy/resource-library/upload", methods=["POST"])
@login_required
def academy_resource_library_upload_v2():

    title = request.form.get("title", "").strip()
    category = request.form.get("category", "").strip()
    description = request.form.get("description", "").strip()
    uploaded = request.files.get("file")

    if not title or not uploaded or not uploaded.filename:
        flash("Title and file are required.")
        return redirect("/academy/resource-library")

    original_name = secure_filename(uploaded.filename)

    if not original_name or "." not in original_name:
        flash("Invalid filename.")
        return redirect("/academy/resource-library")

    extension = original_name.rsplit(".", 1)[1].lower()

    if extension not in _RESOURCE_ALLOWED_EXTENSIONS:
        flash("This file type is not allowed.")
        return redirect("/academy/resource-library")

    stamp = datetime.now().strftime("%Y%m%d_%H%M%S_%f")

    saved_name = (
        stamp + "_" +
        secure_filename(title)[:50] + "_" +
        original_name
    )

    saved_path = _RESOURCE_UPLOAD_DIR / saved_name
    uploaded.save(saved_path)

    conn = _resource_db()

    conn.execute("""
        INSERT INTO academy_resources
        (
            title,
            category,
            description,
            filename,
            stored_path,
            uploaded_by,
            created_at,
            download_count
        )
        VALUES (?, ?, ?, ?, ?, ?, ?, ?)
    """, (
        title,
        category,
        description,
        original_name,
        str(saved_path.resolve()),
        session.get("username", "system"),
        datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        0
    ))

    conn.commit()
    conn.close()

    flash("Resource uploaded successfully.")
    return redirect("/academy/resource-library")


@app.route("/academy/resource-library/download/<int:resource_id>")
@login_required
def academy_resource_library_download_v2(resource_id):

    conn = _resource_db()

    resource = conn.execute("""
        SELECT id, filename, stored_path
        FROM academy_resources
        WHERE id=?
    """, (resource_id,)).fetchone()

    if not resource:
        conn.close()
        flash("Resource not found.")
        return redirect("/academy/resource-library")

    stored_path = _ResourcePath(resource["stored_path"]).resolve()
    upload_root = _RESOURCE_UPLOAD_DIR.resolve()

    # Security check: prevent path traversal or outside-directory access
    try:
        stored_path.relative_to(upload_root)
    except ValueError:
        conn.close()
        flash("Invalid resource path.")
        return redirect("/academy/resource-library")

    if not stored_path.is_file():
        conn.close()
        flash("File is missing from the server.")
        return redirect("/academy/resource-library")

    conn.execute("""
        UPDATE academy_resources
        SET download_count = COALESCE(download_count, 0) + 1
        WHERE id=?
    """, (resource_id,))

    conn.commit()
    conn.close()

    return send_file(
        str(stored_path),
        as_attachment=True,
        download_name=resource["filename"] or stored_path.name
    )

# ===== END SHAKIL AI ACADEMY RESOURCE LIBRARY V2 =====
'''

anchor = 'if __name__ == "__main__":'

if anchor not in text:
    print("ANCHOR NOT FOUND - STOP")
    raise SystemExit(1)

text = text.replace(anchor, code + "\n\n" + anchor, 1)

path.write_text(text, encoding="utf-8")

print("RESOURCE LIBRARY V2 PATCH OK")
