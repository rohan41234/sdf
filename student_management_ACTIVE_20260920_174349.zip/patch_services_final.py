﻿from pathlib import Path

p = Path("smc_base.py")
s = p.read_text(encoding="utf-8")

old = """    <div class="card">
      <h2>English Wings Academy Services</h2>
      <a class="btn" href="/portal">Unified Portal</a>
      <a class="btn" href="/website/" target="_blank">Academy Website</a>
      <a class="btn" href="/analytics" target="_blank">AI Analytics</a>
    </div>"""

new = """    <div class="card academy-services-card">
      <div class="academy-services-title">English Wings Academy Services</div>
      <div class="academy-services-buttons">
        <a class="academy-service-btn" href="/portal">Unified Portal</a>
        <a class="academy-service-btn" href="/website/" target="_blank">Academy Website</a>
        <a class="academy-service-btn" href="/analytics" target="_blank">AI Analytics</a>
      </div>
    </div>"""

if old not in s:
    raise SystemExit("Services HTML pattern not found. No changes made.")

s = s.replace(old, new, 1)

marker = "/* ===== END ENGLISH WINGS SERVICES BUTTON FIX ===== */"

css = """
/* ===== ENGLISH WINGS ACADEMY SERVICES FINAL ===== */

.academy-services-card{
  background:#ffffff !important;
  border:1px solid #e2e8f0;
}

.academy-services-title{
  display:block;
  color:#17202a;
  font-size:23px;
  font-weight:800;
  line-height:1.3;
  margin-bottom:18px;
}

.academy-services-buttons{
  display:flex;
  flex-wrap:wrap;
  gap:12px;
}

.academy-service-btn{
  display:inline-flex;
  align-items:center;
  justify-content:center;
  min-width:155px;
  padding:12px 18px;
  border-radius:10px;
  background:#2563eb !important;
  color:#ffffff !important;
  border:1px solid #2563eb !important;
  font-weight:700;
  text-decoration:none !important;
  box-shadow:0 3px 8px rgba(37,99,235,.18);
  transition:all .2s ease;
}

.academy-service-btn:hover{
  background:#1d4ed8 !important;
  border-color:#1d4ed8 !important;
  color:#ffffff !important;
  transform:translateY(-2px);
  box-shadow:0 6px 14px rgba(37,99,235,.25);
}

@media(max-width:800px){
  .academy-services-buttons{
    display:grid;
    grid-template-columns:1fr 1fr;
  }

  .academy-service-btn{
    min-width:0;
  }
}

@media(max-width:430px){
  .academy-services-buttons{
    grid-template-columns:1fr;
  }

  .academy-services-title{
    font-size:20px;
  }
}

/* ===== END ENGLISH WINGS ACADEMY SERVICES FINAL ===== */
"""

if marker not in s:
    raise SystemExit("Services CSS marker not found. No changes made.")

s = s.replace(marker, marker + "\n" + css, 1)

p.write_text(s, encoding="utf-8")
print("SERVICES FINAL FIX APPLIED")
