from pathlib import Path

p = Path("smc_base.py")
s = p.read_text(encoding="utf-8")

old = '''    html = f"""
    <h1>Results</h1>'''

new = '''    # Results intelligence summary
    total_results = len(rows)

    valid_results = [
        r for r in rows
        if r["total_marks"] and r["marks"] is not None
    ]

    percentages = [
        (r["marks"] / r["total_marks"] * 100)
        for r in valid_results
    ]

    average_percentage = (
        sum(percentages) / len(percentages)
        if percentages else 0
    )

    pass_count = sum(
        1 for pct in percentages if pct >= 40
    )

    fail_count = len(percentages) - pass_count

    pass_rate = (
        pass_count / len(percentages) * 100
        if percentages else 0
    )

    html = f"""
    <h1>Results</h1>

    <div class="grid">
      <div class="stat"><h3>Total Results</h3><h2>{total_results}</h2></div>
      <div class="stat"><h3>Average</h3><h2>{average_percentage:.1f}%</h2></div>
      <div class="stat"><h3>Passed</h3><h2>{pass_count}</h2></div>
      <div class="stat"><h3>Failed</h3><h2>{fail_count}</h2></div>
      <div class="stat"><h3>Pass Rate</h3><h2>{pass_rate:.1f}%</h2></div>
    </div>

    <div class="card">
      <strong>Performance Summary:</strong>
      {pass_count} passed, {fail_count} failed
      from {len(percentages)} graded results.
    </div>'''

if old not in s:
    raise SystemExit("TARGET NOT FOUND")

s = s.replace(old, new, 1)

p.write_text(s, encoding="utf-8")
print("RESULTS INTELLIGENCE ADDED")