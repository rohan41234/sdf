﻿from flask import Flask, request, jsonify
import urllib.request
import urllib.error
import json
import os

app = Flask(__name__)

OLLAMA_URL = "http://127.0.0.1:11434/api/chat"
MODEL = "llama3.2:3b"

HTML = """
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Shakil AI</title>
<style>
body{font-family:Arial,sans-serif;background:#f4f7fb;margin:0}
.container{max-width:900px;margin:30px auto;padding:20px}
.card{background:white;border-radius:14px;padding:20px;box-shadow:0 3px 15px #0001}
h1{margin-top:0}
textarea{width:100%;box-sizing:border-box;min-height:130px;padding:14px;border:1px solid #ccd4df;border-radius:10px;font-size:16px}
button{margin-top:12px;padding:12px 22px;border:0;border-radius:8px;background:#1769aa;color:white;font-size:16px;cursor:pointer}
button:disabled{opacity:.6}
#answer{margin-top:20px;padding:18px;background:#f8fafc;border-radius:10px;white-space:pre-wrap;line-height:1.6}
.status{font-size:14px;color:#666;margin-top:8px}
</style>
</head>
<body>
<div class="container">
<div class="card">
<h1>🤖 Shakil AI Assistant</h1>
<p>Local AI powered by Ollama + Qwen.</p>
<textarea id="question" placeholder="Ask something...&#10;&#10;Example: Create a lesson plan for Class 8 English."></textarea>
<br>
<button id="btn" onclick="askAI()">Ask Shakil AI</button>
<div class="status" id="status"></div>
<div id="answer">AI answer will appear here.</div>
</div>
</div>

<script>
async function askAI(){
    const q=document.getElementById("question").value.trim();
    const btn=document.getElementById("btn");
    const answer=document.getElementById("answer");
    const status=document.getElementById("status");

    if(!q){
        answer.textContent="Please enter a question.";
        return;
    }

    btn.disabled=true;
    status.textContent="AI is thinking...";
    answer.textContent="";

    try{
        const r=await fetch("/api/ask",{
            method:"POST",
            headers:{"Content-Type":"application/json"},
            body:JSON.stringify({question:q})
        });

        const data=await r.json();

        if(data.ok){
            answer.textContent=data.answer;
            status.textContent="Ready";
        }else{
            answer.textContent=data.error || "AI request failed.";
            status.textContent="Error";
        }
    }catch(e){
        answer.textContent="Could not connect to Shakil AI server.";
        status.textContent="Connection error";
    }

    btn.disabled=false;
}
</script>
</body>
</html>
"""

@app.get("/")
def home():
    return HTML

@app.post("/api/ask")
def ask():
    data = request.get_json(silent=True) or {}
    question = str(data.get("question", "")).strip()

    if not question:
        return jsonify(ok=False, error="Question is required."), 400

    payload = {
        "model": MODEL,
        "messages": [
            {
                "role": "system",
                "content": "You are Shakil AI, a helpful local educational assistant. Give clear, practical and accurate answers."
            },
            {
                "role": "user",
                "content": question
            }
        ],
        "stream": False,
        "options": {
            "num_ctx": 2048,
            "num_predict": 512,
            "temperature": 0.3
        }
    }

    try:
        body = json.dumps(payload).encode("utf-8")
        req = urllib.request.Request(
            OLLAMA_URL,
            data=body,
            headers={"Content-Type": "application/json"},
            method="POST"
        )

        with urllib.request.urlopen(req, timeout=180) as response:
            result = json.loads(response.read().decode("utf-8"))

        answer = result.get("message", {}).get("content", "")

        if not answer:
            answer = "Ollama returned no answer."

        return jsonify(ok=True, answer=answer)

    except urllib.error.URLError as e:
        return jsonify(
            ok=False,
            error=f"Ollama connection error: {e}"
        ), 503

    except Exception as e:
        print("AI ERROR:", repr(e))
        return jsonify(
            ok=False,
            error="AI request failed. Check the Ollama model."
        ), 500

if __name__ == "__main__":
    host = os.environ.get("SHAKIL_AI_HOST", "0.0.0.0")
    port = int(os.environ.get("SHAKIL_AI_PORT", "7000"))
    app.run(host=host, port=port, debug=False)





