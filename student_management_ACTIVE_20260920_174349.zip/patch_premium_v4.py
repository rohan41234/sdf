﻿from pathlib import Path
import re

p = Path("smc_base.py")
text = p.read_text(encoding="utf-8")

if "===== SHAKIL AI PREMIUM COURSES V4 =====" in text:
    print("V4 ALREADY INSTALLED")
    raise SystemExit

marker = "# ===== END SHAKIL AI PREMIUM COURSES V3 ====="

if marker not in text:
    raise SystemExit("V3 END MARKER NOT FOUND - NO CHANGES MADE")

block = r'''
# ===== SHAKIL AI PREMIUM COURSES V4 =====

def _premium_v4_init_db():
    conn = _premium_db()

    conn.execute("""
        CREATE TABLE IF NOT EXISTS premium_modules (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            course_id INTEGER NOT NULL,
            title TEXT NOT NULL,
            description TEXT DEFAULT '',
            sort_order INTEGER DEFAULT 0,
            created_at TEXT NOT NULL
        )
    """)

    conn.execute("""
        CREATE TABLE IF NOT EXISTS premium_lessons (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            module_id INTEGER NOT NULL,
            title TEXT NOT NULL,
            lesson_type TEXT DEFAULT 'text',
            content TEXT DEFAULT '',
            video_url TEXT DEFAULT '',
            resource_id INTEGER,
            sort_order INTEGER DEFAULT 0,
            created_at TEXT NOT NULL
        )
    """)

    conn.commit()
    conn.close()


@app.route("/premium-courses/admin/<int:course_id>/modules", methods=["GET", "POST"])
def premium_admin_modules(course_id):
    if not _premium_admin_required():
        return _premium_redirect(_premium_url_for("login"))

    _premium_v2_init_db()
    _premium_v4_init_db()

    conn = _premium_db()
    course = conn.execute(
        "SELECT * FROM premium_courses WHERE id=?",
        (course_id,)
    ).fetchone()

    if not course:
        conn.close()
        return "Course not found", 404

    if request.method == "POST":
        title = request.form.get("title", "").strip()
        description = request.form.get("description", "").strip()
        sort_order = int(request.form.get("sort_order", "0") or 0)

        if title:
            conn.execute("""
                INSERT INTO premium_modules
                (course_id,title,description,sort_order,created_at)
                VALUES (?,?,?,?,?)
            """, (
                course_id,
                title,
                description,
                sort_order,
                datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            ))
            conn.commit()

        conn.close()
        return _premium_redirect(
            _premium_url_for("premium_admin_modules", course_id=course_id)
        )

    modules = conn.execute("""
        SELECT *
        FROM premium_modules
        WHERE course_id=?
        ORDER BY sort_order,id
    """, (course_id,)).fetchall()

    conn.close()

    rows = "".join(
        f"""
        <tr>
          <td>{m['sort_order']}</td>
          <td><strong>{m['title']}</strong><br>{m['description'] or ''}</td>
          <td>
            <a class="btn" href="/premium-courses/admin/module/{m['id']}/lessons">
              Lessons
            </a>
            <form method="post"
                  action="/premium-courses/admin/module/{m['id']}/delete"
                  style="display:inline"
                  onsubmit="return confirm('Delete this module and its lessons?')">
              <button class="btn" type="submit">Delete</button>
            </form>
          </td>
        </tr>
        """
        for m in modules
    )

    html = f"""
    <div class="card">
      <h2>Manage Modules — {course['title']}</h2>

      <form method="post">
        <p><label>Module Title</label>
        <input name="title" required></p>

        <p><label>Description</label>
        <textarea name="description" rows="3"></textarea></p>

        <p><label>Order</label>
        <input type="number" name="sort_order" value="0"></p>

        <button class="btn" type="submit">Add Module</button>
      </form>
    </div>

    <div class="card">
      <h2>Modules</h2>
      <div class="table-wrap">
        <table>
          <tr>
            <th>Order</th>
            <th>Module</th>
            <th>Actions</th>
          </tr>
          {rows or '<tr><td colspan="3">No modules yet.</td></tr>'}
        </table>
      </div>
    </div>
    """

    return page("Course Modules", html)


@app.route("/premium-courses/admin/module/<int:module_id>/delete", methods=["POST"])
def premium_admin_module_delete(module_id):
    if not _premium_admin_required():
        return _premium_redirect(_premium_url_for("login"))

    _premium_v2_init_db()
    _premium_v4_init_db()

    conn = _premium_db()

    module = conn.execute(
        "SELECT course_id FROM premium_modules WHERE id=?",
        (module_id,)
    ).fetchone()

    if not module:
        conn.close()
        return "Module not found", 404

    conn.execute(
        "DELETE FROM premium_lessons WHERE module_id=?",
        (module_id,)
    )
    conn.execute(
        "DELETE FROM premium_modules WHERE id=?",
        (module_id,)
    )
    conn.commit()
    conn.close()

    return _premium_redirect(
        _premium_url_for(
            "premium_admin_modules",
            course_id=module["course_id"]
        )
    )


@app.route("/premium-courses/admin/module/<int:module_id>/lessons", methods=["GET", "POST"])
def premium_admin_lessons(module_id):
    if not _premium_admin_required():
        return _premium_redirect(_premium_url_for("login"))

    _premium_v2_init_db()
    _premium_v4_init_db()

    conn = _premium_db()

    module = conn.execute("""
        SELECT m.*,c.title AS course_title
        FROM premium_modules m
        JOIN premium_courses c ON c.id=m.course_id
        WHERE m.id=?
    """, (module_id,)).fetchone()

    if not module:
        conn.close()
        return "Module not found", 404

    if request.method == "POST":
        title = request.form.get("title", "").strip()
        lesson_type = request.form.get("lesson_type", "text").strip()
        content = request.form.get("content", "").strip()
        video_url = request.form.get("video_url", "").strip()
        sort_order = int(request.form.get("sort_order", "0") or 0)

        if title:
            conn.execute("""
                INSERT INTO premium_lessons
                (module_id,title,lesson_type,content,video_url,sort_order,created_at)
                VALUES (?,?,?,?,?,?,?)
            """, (
                module_id,
                title,
                lesson_type,
                content,
                video_url,
                sort_order,
                datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            ))
            conn.commit()

        conn.close()
        return _premium_redirect(
            _premium_url_for(
                "premium_admin_lessons",
                module_id=module_id
            )
        )

    lessons = conn.execute("""
        SELECT *
        FROM premium_lessons
        WHERE module_id=?
        ORDER BY sort_order,id
    """, (module_id,)).fetchall()

    conn.close()

    rows = "".join(
        f"""
        <tr>
          <td>{l['sort_order']}</td>
          <td>
            <strong>{l['title']}</strong><br>
            Type: {l['lesson_type']}
          </td>
          <td>
            <form method="post"
                  action="/premium-courses/admin/lesson/{l['id']}/delete"
                  onsubmit="return confirm('Delete this lesson?')">
              <button class="btn" type="submit">Delete</button>
            </form>
          </td>
        </tr>
        """
        for l in lessons
    )

    html = f"""
    <div class="card">
      <h2>{module['course_title']} → {module['title']}</h2>

      <form method="post">

        <p><label>Lesson Title</label>
        <input name="title" required></p>

        <p><label>Lesson Type</label>
        <select name="lesson_type">
          <option value="text">Text</option>
          <option value="video">Video</option>
          <option value="resource">Resource</option>
        </select></p>

        <p><label>Lesson Content</label>
        <textarea name="content" rows="8"
                  placeholder="Write lesson content here..."></textarea></p>

        <p><label>Video URL</label>
        <input name="video_url"
               placeholder="Optional YouTube/video URL"></p>

        <p><label>Order</label>
        <input type="number" name="sort_order" value="0"></p>

        <button class="btn" type="submit">Add Lesson</button>
      </form>
    </div>

    <div class="card">
      <h2>Lessons</h2>
      <div class="table-wrap">
        <table>
          <tr>
            <th>Order</th>
            <th>Lesson</th>
            <th>Action</th>
          </tr>
          {rows or '<tr><td colspan="3">No lessons yet.</td></tr>'}
        </table>
      </div>
    </div>
    """

    return page("Course Lessons", html)


@app.route("/premium-courses/admin/lesson/<int:lesson_id>/delete", methods=["POST"])
def premium_admin_lesson_delete(lesson_id):
    if not _premium_admin_required():
        return _premium_redirect(_premium_url_for("login"))

    _premium_v2_init_db()
    _premium_v4_init_db()

    conn = _premium_db()

    lesson = conn.execute("""
        SELECT m.id AS module_id
        FROM premium_lessons l
        JOIN premium_modules m ON m.id=l.module_id
        WHERE l.id=?
    """, (lesson_id,)).fetchone()

    if not lesson:
        conn.close()
        return "Lesson not found", 404

    conn.execute(
        "DELETE FROM premium_lessons WHERE id=?",
        (lesson_id,)
    )
    conn.commit()
    conn.close()

    return _premium_redirect(
        _premium_url_for(
            "premium_admin_lessons",
            module_id=lesson["module_id"]
        )
    )


@app.route("/my-premium-courses/<int:enrollment_id>/lesson/<int:lesson_id>")
def premium_student_lesson(enrollment_id, lesson_id):
    if "username" not in session:
        return _premium_redirect(_premium_url_for("login"))

    _premium_v2_init_db()
    _premium_v4_init_db()

    username = session.get("username")
    conn = _premium_db()

    enrollment = conn.execute("""
        SELECT e.*,c.title AS course_title
        FROM premium_enrollments e
        JOIN premium_courses c ON c.id=e.course_id
        WHERE e.id=? AND e.username=?
    """, (enrollment_id, username)).fetchone()

    if not enrollment:
        conn.close()
        return "Enrollment not found", 404

    lesson = conn.execute("""
        SELECT l.*,m.title AS module_title,m.course_id
        FROM premium_lessons l
        JOIN premium_modules m ON m.id=l.module_id
        WHERE l.id=? AND m.course_id=?
    """, (lesson_id, enrollment["course_id"])).fetchone()

    if not lesson:
        conn.close()
        return "Lesson not found", 404

    conn.close()

    video = ""
    if lesson["video_url"]:
        video = f"""
        <p>
          <a class="btn" href="{lesson['video_url']}" target="_blank">
            Open Video
          </a>
        </p>
        """

    html = f"""
    <div class="card">
      <p><strong>{enrollment['course_title']}</strong></p>
      <p>Module: {lesson['module_title']}</p>
      <h1>{lesson['title']}</h1>
      <hr>
      <div style="white-space:pre-wrap;line-height:1.8">
        {lesson['content']}
      </div>
      {video}
    </div>
    """

    return page("Premium Lesson", html)


# ===== END SHAKIL AI PREMIUM COURSES V4 =====
'''

text = text.replace(marker, marker + "\n" + block, 1)
p.write_text(text, encoding="utf-8")
print("V4 PATCH APPLIED")
