from pathlib import Path

p = Path("smc_base.py")
s = p.read_text(encoding="utf-8")

old = '''    html = f"""
    <h1>Daily Attendance</h1>'''

new = '''    # Attendance intelligence for selected date
    present_count = sum(1 for x in existing_status.values() if x == "Present")
    absent_count = sum(1 for x in existing_status.values() if x == "Absent")
    late_count = sum(1 for x in existing_status.values() if x == "Late")
    leave_count = sum(1 for x in existing_status.values() if x == "Leave")
    total_students = len(students_list)
    marked_count = len(existing_status)
    completion_pct = (marked_count / total_students * 100) if total_students else 0

    html = f"""
    <h1>Daily Attendance</h1>

    <div class="grid">
      <div class="stat"><h3>Present</h3><h2>{present_count}</h2></div>
      <div class="stat"><h3>Absent</h3><h2>{absent_count}</h2></div>
      <div class="stat"><h3>Late</h3><h2>{late_count}</h2></div>
      <div class="stat"><h3>Leave</h3><h2>{leave_count}</h2></div>
    </div>

    <div class="card">
      <strong>Attendance Completion:</strong>
      {marked_count}/{total_students} students marked
      ({completion_pct:.1f}%)
    </div>'''

if old not in s:
    raise SystemExit("TARGET NOT FOUND")

s = s.replace(old, new, 1)

p.write_text(s, encoding="utf-8")
print("ATTENDANCE INTELLIGENCE ADDED")