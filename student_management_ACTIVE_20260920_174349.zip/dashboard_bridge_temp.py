﻿from smc_base import app
import smc_base

@app.route("/smc")
@app.route("/smc/")
def unified_smc_dashboard():
    return smc_base.dashboard()
