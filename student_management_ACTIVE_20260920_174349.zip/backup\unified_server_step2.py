from flask import Flask

app = Flask(__name__)


@app.route("/")
def home():
    return """
    <!DOCTYPE html>
    <html>
    <head>
        <meta charset="UTF-8">
        <title>Shakil AI Unified Server</title>
        <style>
            body {
                font-family: Arial, sans-serif;
                max-width: 900px;
                margin: 50px auto;
                padding: 20px;
            }

            h1 {
                margin-bottom: 10px;
            }

            .status {
                padding: 15px;
                border: 1px solid #ccc;
                border-radius: 8px;
                margin-top: 20px;
            }
        </style>
    </head>

    <body>
        <h1>🚀 Shakil AI Unified Server</h1>

        <div class="status">
            <h2>✅ Server is working</h2>
            <p>Unified Server Step 2 test successful.</p>
            <p>Existing SMC, Website, AI and Analytics servers are untouched.</p>
        </div>
    </body>
    </html>
    """


if __name__ == "__main__":
    app.run(
        host="0.0.0.0",
        port=7200,
        debug=False
    )