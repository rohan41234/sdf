﻿import sqlite3

db = r"C:\Users\Md Shakil Hossain\ShakilAI\websites\student_management\students.db"
conn = sqlite3.connect(db)

tables = conn.execute(
    "SELECT name FROM sqlite_master WHERE type='table' ORDER BY name"
).fetchall()

print("=== TABLES ===")
for (table,) in tables:
    print(table)

print("\n=== COLUMNS ===")
for (table,) in tables:
    cols = conn.execute(f'PRAGMA table_info("{table}")').fetchall()
    print(f"\n{table}:")
    print(", ".join(col[1] for col in cols))

conn.close()
