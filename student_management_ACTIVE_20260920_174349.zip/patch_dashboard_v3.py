﻿from pathlib import Path

p = Path("smc_base.py")
s = p.read_text(encoding="utf-8")

old = """<h1>Dashboard</h1>
    <p>Welcome, <strong>{esc(session.get('username'))}</strong>
       <span class="badge">{esc(session.get('role'))}</span></p>"""

new = """<div class="dashboard-hero">
      <div>
        <div class="dashboard-kicker">ENGLISH WINGS ACADEMY</div>
        <h1>Welcome to Shakil AI SMC</h1>
        <p>School Management • Academy • Consultancy</p>
      </div>
      <div class="dashboard-user">
        <span>Signed in as</span>
        <strong>{esc(session.get('username'))}</strong>
        <span class="badge">{esc(session.get('role'))}</span>
      </div>
    </div>"""

if old not in s:
    raise SystemExit("Dashboard header pattern not found. No changes made.")

s = s.replace(old, new, 1)

marker = "/* ===== END SHAKIL AI DASHBOARD V2 ===== */"

css = """
/* ===== SHAKIL AI DASHBOARD V3 ===== */

.dashboard-hero{
  display:flex;
  justify-content:space-between;
  align-items:center;
  gap:24px;
  margin-bottom:24px;
  padding:30px 32px;
  border-radius:22px;
  background:linear-gradient(135deg,#111827 0%,#1e3a8a 55%,#2563eb 100%);
  color:#fff;
  box-shadow:0 14px 35px rgba(15,23,42,.16);
}

.dashboard-kicker{
  font-size:12px;
  font-weight:800;
  letter-spacing:1.5px;
  opacity:.78;
  margin-bottom:8px;
}

.dashboard-hero h1{
  margin:0;
  font-size:34px;
  font-weight:800;
  letter-spacing:-.6px;
}

.dashboard-hero p{
  margin:9px 0 0;
  color:#dbeafe;
  font-size:15px;
}

.dashboard-user{
  min-width:190px;
  padding:16px 18px;
  border:1px solid rgba(255,255,255,.18);
  border-radius:14px;
  background:rgba(255,255,255,.10);
  backdrop-filter:blur(8px);
}

.dashboard-user span:first-child{
  display:block;
  font-size:11px;
  color:#bfdbfe;
  margin-bottom:4px;
}

.dashboard-user strong{
  display:block;
  font-size:17px;
  margin-bottom:8px;
}

.dashboard-user .badge{
  background:rgba(255,255,255,.16);
  color:#fff;
}

.grid>.stat{
  cursor:default;
}

.grid>.stat:nth-child(2):before{background:#7c3aed}
.grid>.stat:nth-child(3):before{background:#0891b2}
.grid>.stat:nth-child(4):before{background:#059669}
.grid>.stat:nth-child(5):before{background:#d97706}
.grid>.stat:nth-child(6):before{background:#dc2626}
.grid>.stat:nth-child(7):before{background:#db2777}
.grid>.stat:nth-child(8):before{background:#4f46e5}

.grid>.stat h3{
  font-size:12px;
}

.grid>.stat h2{
  font-size:38px;
}

.card>h2{
  display:flex;
  align-items:center;
  gap:10px;
}

.card>h2:after{
  content:"";
  flex:1;
  height:1px;
  background:#e5e7eb;
}

.card:has(a.btn){
  position:relative;
}

.card:has(a.btn) .btn{
  min-width:130px;
  text-align:center;
}

.card:last-child{
  background:linear-gradient(135deg,#f8fbff,#eef5ff);
}

.card:last-child .btn{
  border:1px solid #dbeafe;
  background:#fff;
}

@media(max-width:800px){
  .dashboard-hero{
    flex-direction:column;
    align-items:flex-start;
    padding:23px 20px;
  }

  .dashboard-hero h1{
    font-size:27px;
  }

  .dashboard-user{
    width:100%;
    min-width:0;
  }
}

@media(max-width:430px){
  .dashboard-hero{
    padding:20px 17px;
    border-radius:16px;
  }

  .dashboard-hero h1{
    font-size:24px;
  }

  .dashboard-hero p{
    font-size:13px;
  }
}

/* ===== END SHAKIL AI DASHBOARD V3 ===== */
"""

if marker not in s:
    raise SystemExit("V2 marker not found. No changes made.")

s = s.replace(marker, marker + "\n" + css, 1)

p.write_text(s, encoding="utf-8")
print("DASHBOARD V3 APPLIED")
