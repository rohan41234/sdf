﻿from pathlib import Path
import re

TARGET = Path("smc_base.py")
SOURCE = TARGET.read_text(encoding="utf-8")

MARKER_START = "# ===== SHAKIL AI ACADEMY UPGRADE V1 ====="
MARKER_END = "# ===== END SHAKIL AI ACADEMY UPGRADE V1 ====="

if MARKER_START in SOURCE:
    print("ACADEMY V1 PATCH ALREADY EXISTS - STOPPING SAFELY")
    raise SystemExit(0)

CODE = r'''
# ===== SHAKIL AI ACADEMY UPGRADE V1 =====

def _academy_v1_db():
    import sqlite3
    db_path = globals().get(
        "DATABASE",
        r"C:\Users\Md Shakil Hossain\ShakilAI\websites\student_management\students.db"
    )
    conn = sqlite3.connect(db_path)
    conn.row_factory = sqlite3.Row
    return conn


def _academy_v1_init_db():
    conn = _academy_v1_db()

    conn.execute("""
        CREATE TABLE IF NOT EXISTS academy_courses (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            title TEXT NOT NULL,
            category TEXT,
            level TEXT,
            description TEXT,
            duration TEXT,
            fee REAL DEFAULT 0,
            status TEXT DEFAULT 'Active',
            created_at TEXT NOT NULL
        )
    """)

    conn.execute("""
        CREATE TABLE IF NOT EXISTS academy_batches (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            course_id INTEGER,
            name TEXT NOT NULL,
            teacher TEXT,
            schedule TEXT,
            start_date TEXT,
            end_date TEXT,
            status TEXT DEFAULT 'Active',
            created_at TEXT NOT NULL
        )
    """)

    conn.execute("""
        CREATE TABLE IF NOT EXISTS academy_assignments (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            course_id INTEGER,
            batch_id INTEGER,
            title TEXT NOT NULL,
            description TEXT,
            due_date TEXT,
            marks REAL DEFAULT 0,
            created_at TEXT NOT NULL
        )
    """)

    conn.execute("""
        CREATE TABLE IF NOT EXISTS academy_resources (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            title TEXT NOT NULL,
            category TEXT,
            description TEXT,
            filename TEXT,
            stored_path TEXT,
            uploaded_by TEXT,
            created_at TEXT NOT NULL,
            download_count INTEGER DEFAULT 0
        )
    """)

    conn.commit()
    conn.close()


def _academy_v1_admin():
    try:
        username = session.get("username")
        role = str(session.get("role", "")).lower()

        return (
            username == "admin"
            or role in ("admin", "administrator")
        )
    except Exception:
        return False


def _academy_v1_page(title, body):
    return f"""
    <!doctype html>
    <html>
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width,initial-scale=1">
        <title>{title} - English Wings Academy</title>
        <style>
            body {{
                margin:0;
                font-family:Arial,Helvetica,sans-serif;
                background:#f4f7fb;
                color:#17202a;
            }}
            .top {{
                background:#173b72;
                color:white;
                padding:22px 28px;
            }}
            .top h1 {{
                margin:0 0 6px;
                font-size:25px;
            }}
            .top p {{
                margin:0;
                opacity:.9;
            }}
            .nav {{
                background:white;
                padding:12px 24px;
                border-bottom:1px solid #e2e8f0;
            }}
            .nav a {{
                display:inline-block;
                margin:4px 8px 4px 0;
                padding:8px 12px;
                border-radius:7px;
                background:#eef4ff;
                color:#173b72;
                text-decoration:none;
                font-weight:700;
            }}
            .container {{
                max-width:1200px;
                margin:25px auto;
                padding:0 18px;
            }}
            .card {{
                background:white;
                border:1px solid #e2e8f0;
                border-radius:12px;
                padding:20px;
                margin-bottom:20px;
                box-shadow:0 3px 10px rgba(0,0,0,.04);
            }}
            .grid {{
                display:grid;
                grid-template-columns:repeat(auto-fit,minmax(220px,1fr));
                gap:16px;
            }}
            .stat {{
                background:white;
                border:1px solid #e2e8f0;
                border-radius:12px;
                padding:20px;
            }}
            .stat strong {{
                display:block;
                font-size:30px;
                color:#2563eb;
                margin-top:8px;
            }}
            table {{
                width:100%;
                border-collapse:collapse;
            }}
            th,td {{
                padding:11px;
                border-bottom:1px solid #e5e7eb;
                text-align:left;
                vertical-align:top;
            }}
            th {{
                background:#f8fafc;
            }}
            input,select,textarea {{
                width:100%;
                box-sizing:border-box;
                padding:10px;
                border:1px solid #cbd5e1;
                border-radius:7px;
                margin:5px 0 12px;
                font:inherit;
            }}
            textarea {{
                min-height:100px;
            }}
            button {{
                background:#2563eb;
                color:white;
                border:0;
                padding:10px 16px;
                border-radius:7px;
                font-weight:700;
                cursor:pointer;
            }}
            .muted {{
                color:#64748b;
            }}
            .success {{
                padding:12px;
                background:#ecfdf5;
                border:1px solid #a7f3d0;
                border-radius:8px;
                color:#065f46;
                margin-bottom:15px;
            }}
            @media(max-width:700px) {{
                table {{
                    display:block;
                    overflow-x:auto;
                }}
            }}
        </style>
    </head>
    <body>
        <div class="top">
            <h1>English Wings Academy</h1>
            <p>Shakil AI Academy Management</p>
        </div>

        <div class="nav">
            <a href="/academy/dashboard">Dashboard</a>
            <a href="/academy/courses">Courses</a>
            <a href="/academy/batches">Batches</a>
            <a href="/academy/assignments">Assignments</a>
            <a href="/academy/resources">Resources</a>
            <a href="/dashboard">SMC Dashboard</a>
        </div>

        <div class="container">
            {body}
        </div>
    </body>
    </html>
    """


def _academy_v1_count(conn, table):
    allowed = {
        "academy_courses",
        "academy_batches",
        "academy_assignments",
        "academy_resources"
    }

    if table not in allowed:
        return 0

    return conn.execute(
        "SELECT COUNT(*) FROM " + table
    ).fetchone()[0]


# Initialize Academy V1 database tables.
try:
    _academy_v1_init_db()
except Exception as _academy_v1_init_error:
    print("Academy V1 database initialization warning:", _academy_v1_init_error)


@app.route("/academy/dashboard")
def academy_v1_dashboard():
    if "username" not in session:
        return redirect(url_for("login"))

    conn = _academy_v1_db()

    courses = _academy_v1_count(conn, "academy_courses")
    batches = _academy_v1_count(conn, "academy_batches")
    assignments = _academy_v1_count(conn, "academy_assignments")
    resources = _academy_v1_count(conn, "academy_resources")

    conn.close()

    body = f"""
    <h2>Academy Dashboard</h2>
    <p class="muted">
        English Wings Academy learning management overview.
    </p>

    <div class="grid">
        <div class="stat">
            Courses
            <strong>{courses}</strong>
        </div>

        <div class="stat">
            Batches
            <strong>{batches}</strong>
        </div>

        <div class="stat">
            Assignments
            <strong>{assignments}</strong>
        </div>

        <div class="stat">
            Resources
            <strong>{resources}</strong>
        </div>
    </div>

    <div class="card">
        <h3>Academy V1 Modules</h3>
        <p>
            Courses → Batches → Assignments → Resources
        </p>
        <p class="muted">
            Existing Academy Students, Notes, Vocabulary, IELTS Papers,
            Answer Keys, Tests, Results, Progress and Certificates are preserved.
        </p>
    </div>
    """

    return _academy_v1_page("Academy Dashboard", body)


@app.route("/academy/courses", methods=["GET", "POST"])
def academy_v1_courses():
    if "username" not in session:
        return redirect(url_for("login"))

    conn = _academy_v1_db()

    if request.method == "POST":
        if not _academy_v1_admin():
            conn.close()
            return "Admin access required", 403

        from datetime import datetime

        title = request.form.get("title", "").strip()

        if not title:
            conn.close()
            return "Course title is required", 400

        conn.execute("""
            INSERT INTO academy_courses
            (title, category, level, description, duration, fee, status, created_at)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)
        """, (
            title,
            request.form.get("category", "").strip(),
            request.form.get("level", "").strip(),
            request.form.get("description", "").strip(),
            request.form.get("duration", "").strip(),
            float(request.form.get("fee") or 0),
            request.form.get("status", "Active"),
            datetime.now().isoformat(timespec="seconds")
        ))

        conn.commit()

    rows = conn.execute("""
        SELECT *
        FROM academy_courses
        ORDER BY id DESC
    """).fetchall()

    form = ""

    if _academy_v1_admin():
        form = """
        <div class="card">
            <h3>Add Course</h3>

            <form method="post">
                <label>Course Title</label>
                <input name="title" required>

                <label>Category</label>
                <input name="category" placeholder="IELTS / Spoken English / O Level / A Level">

                <label>Level</label>
                <input name="level" placeholder="Beginner / Intermediate / Advanced">

                <label>Description</label>
                <textarea name="description"></textarea>

                <label>Duration</label>
                <input name="duration" placeholder="3 months">

                <label>Fee</label>
                <input name="fee" type="number" step="0.01">

                <label>Status</label>
                <select name="status">
                    <option>Active</option>
                    <option>Inactive</option>
                </select>

                <button type="submit">Add Course</button>
            </form>
        </div>
        """

    table = """
    <div class="card">
        <h3>Academy Courses</h3>
        <table>
            <tr>
                <th>ID</th>
                <th>Course</th>
                <th>Category</th>
                <th>Level</th>
                <th>Duration</th>
                <th>Fee</th>
                <th>Status</th>
            </tr>
    """

    for r in rows:
        table += f"""
            <tr>
                <td>{r["id"]}</td>
                <td><strong>{r["title"]}</strong><br>
                    <span class="muted">{r["description"] or ""}</span>
                </td>
                <td>{r["category"] or ""}</td>
                <td>{r["level"] or ""}</td>
                <td>{r["duration"] or ""}</td>
                <td>{r["fee"]}</td>
                <td>{r["status"]}</td>
            </tr>
        """

    table += "</table></div>"

    conn.close()

    return _academy_v1_page("Courses", form + table)


@app.route("/academy/batches", methods=["GET", "POST"])
def academy_v1_batches():
    if "username" not in session:
        return redirect(url_for("login"))

    conn = _academy_v1_db()

    if request.method == "POST":
        if not _academy_v1_admin():
            conn.close()
            return "Admin access required", 403

        from datetime import datetime

        name = request.form.get("name", "").strip()

        if not name:
            conn.close()
            return "Batch name is required", 400

        course_id = request.form.get("course_id") or None

        conn.execute("""
            INSERT INTO academy_batches
            (course_id, name, teacher, schedule, start_date, end_date, status, created_at)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)
        """, (
            course_id,
            name,
            request.form.get("teacher", "").strip(),
            request.form.get("schedule", "").strip(),
            request.form.get("start_date", "").strip(),
            request.form.get("end_date", "").strip(),
            request.form.get("status", "Active"),
            datetime.now().isoformat(timespec="seconds")
        ))

        conn.commit()

    courses = conn.execute("""
        SELECT id, title
        FROM academy_courses
        ORDER BY title
    """).fetchall()

    rows = conn.execute("""
        SELECT
            b.*,
            c.title AS course_title
        FROM academy_batches b
        LEFT JOIN academy_courses c
            ON c.id = b.course_id
        ORDER BY b.id DESC
    """).fetchall()

    form = ""

    if _academy_v1_admin():
        options = '<option value="">-- Select Course --</option>'

        for c in courses:
            options += f'<option value="{c["id"]}">{c["title"]}</option>'

        form = f"""
        <div class="card">
            <h3>Add Batch</h3>

            <form method="post">
                <label>Course</label>
                <select name="course_id">
                    {options}
                </select>

                <label>Batch Name</label>
                <input name="name" required>

                <label>Teacher</label>
                <input name="teacher">

                <label>Schedule</label>
                <input name="schedule" placeholder="Sat/Mon/Wed - 7:00 PM">

                <label>Start Date</label>
                <input name="start_date" type="date">

                <label>End Date</label>
                <input name="end_date" type="date">

                <label>Status</label>
                <select name="status">
                    <option>Active</option>
                    <option>Completed</option>
                    <option>Inactive</option>
                </select>

                <button type="submit">Add Batch</button>
            </form>
        </div>
        """

    table = """
    <div class="card">
        <h3>Academy Batches</h3>
        <table>
            <tr>
                <th>ID</th>
                <th>Batch</th>
                <th>Course</th>
                <th>Teacher</th>
                <th>Schedule</th>
                <th>Dates</th>
                <th>Status</th>
            </tr>
    """

    for r in rows:
        table += f"""
            <tr>
                <td>{r["id"]}</td>
                <td><strong>{r["name"]}</strong></td>
                <td>{r["course_title"] or ""}</td>
                <td>{r["teacher"] or ""}</td>
                <td>{r["schedule"] or ""}</td>
                <td>{r["start_date"] or ""} → {r["end_date"] or ""}</td>
                <td>{r["status"]}</td>
            </tr>
        """

    table += "</table></div>"

    conn.close()

    return _academy_v1_page("Batches", form + table)


@app.route("/academy/assignments", methods=["GET", "POST"])
def academy_v1_assignments():
    if "username" not in session:
        return redirect(url_for("login"))

    conn = _academy_v1_db()

    if request.method == "POST":
        if not _academy_v1_admin():
            conn.close()
            return "Admin access required", 403

        from datetime import datetime

        title = request.form.get("title", "").strip()

        if not title:
            conn.close()
            return "Assignment title is required", 400

        course_id = request.form.get("course_id") or None
        batch_id = request.form.get("batch_id") or None

        conn.execute("""
            INSERT INTO academy_assignments
            (course_id, batch_id, title, description, due_date, marks, created_at)
            VALUES (?, ?, ?, ?, ?, ?, ?)
        """, (
            course_id,
            batch_id,
            title,
            request.form.get("description", "").strip(),
            request.form.get("due_date", "").strip(),
            float(request.form.get("marks") or 0),
            datetime.now().isoformat(timespec="seconds")
        ))

        conn.commit()

    courses = conn.execute("""
        SELECT id, title
        FROM academy_courses
        ORDER BY title
    """).fetchall()

    batches = conn.execute("""
        SELECT id, name
        FROM academy_batches
        ORDER BY name
    """).fetchall()

    rows = conn.execute("""
        SELECT
            a.*,
            c.title AS course_title,
            b.name AS batch_name
        FROM academy_assignments a
        LEFT JOIN academy_courses c
            ON c.id = a.course_id
        LEFT JOIN academy_batches b
            ON b.id = a.batch_id
        ORDER BY a.id DESC
    """).fetchall()

    form = ""

    if _academy_v1_admin():
        course_options = '<option value="">-- Course --</option>'

        for c in courses:
            course_options += f'<option value="{c["id"]}">{c["title"]}</option>'

        batch_options = '<option value="">-- Batch --</option>'

        for b in batches:
            batch_options += f'<option value="{b["id"]}">{b["name"]}</option>'

        form = f"""
        <div class="card">
            <h3>Add Assignment</h3>

            <form method="post">
                <label>Course</label>
                <select name="course_id">
                    {course_options}
                </select>

                <label>Batch</label>
                <select name="batch_id">
                    {batch_options}
                </select>

                <label>Assignment Title</label>
                <input name="title" required>

                <label>Description</label>
                <textarea name="description"></textarea>

                <label>Due Date</label>
                <input name="due_date" type="date">

                <label>Total Marks</label>
                <input name="marks" type="number" step="0.01">

                <button type="submit">Add Assignment</button>
            </form>
        </div>
        """

    table = """
    <div class="card">
        <h3>Assignments</h3>
        <table>
            <tr>
                <th>ID</th>
                <th>Assignment</th>
                <th>Course</th>
                <th>Batch</th>
                <th>Due</th>
                <th>Marks</th>
            </tr>
    """

    for r in rows:
        table += f"""
            <tr>
                <td>{r["id"]}</td>
                <td>
                    <strong>{r["title"]}</strong><br>
                    <span class="muted">{r["description"] or ""}</span>
                </td>
                <td>{r["course_title"] or ""}</td>
                <td>{r["batch_name"] or ""}</td>
                <td>{r["due_date"] or ""}</td>
                <td>{r["marks"]}</td>
            </tr>
        """

    table += "</table></div>"

    conn.close()

    return _academy_v1_page("Assignments", form + table)


@app.route("/academy/resources")
def academy_v1_resources():
    if "username" not in session:
        return redirect(url_for("login"))

    conn = _academy_v1_db()

    rows = conn.execute("""
        SELECT *
        FROM academy_resources
        ORDER BY id DESC
    """).fetchall()

    table = """
    <div class="card">
        <h2>Academy Resource Library</h2>

        <p class="muted">
            Central location for course notes, PDFs, presentations,
            worksheets, videos and other Academy learning resources.
        </p>

        <table>
            <tr>
                <th>ID</th>
                <th>Resource</th>
                <th>Category</th>
                <th>Description</th>
                <th>Uploaded By</th>
                <th>Downloads</th>
            </tr>
    """

    for r in rows:
        table += f"""
            <tr>
                <td>{r["id"]}</td>
                <td><strong>{r["title"]}</strong></td>
                <td>{r["category"] or ""}</td>
                <td>{r["description"] or ""}</td>
                <td>{r["uploaded_by"] or ""}</td>
                <td>{r["download_count"] or 0}</td>
            </tr>
        """

    table += "</table></div>"

    if _academy_v1_admin():
        table = """
        <div class="card">
            <h3>Resource Library</h3>
            <p>
                The resource database is ready in V1.
                File upload/download workflow will be connected in the next
                Academy Resource upgrade.
            </p>
        </div>
        """ + table

    conn.close()

    return _academy_v1_page("Resources", table)


# ===== END SHAKIL AI ACADEMY UPGRADE V1 =====
'''

# Insert before the application's main run block.
patterns = [
    r'\nif __name__\s*==\s*[\'"]__main__[\'"]\s*:',
    r'\nif __name__\s*==\s*[\'"]__main__[\'"]\s*:'
]

match = None

for pattern in patterns:
    match = re.search(pattern, SOURCE)
    if match:
        break

if not match:
    raise RuntimeError(
        "Could not find Flask __main__ block. "
        "No changes were made."
    )

NEW_SOURCE = (
    SOURCE[:match.start()]
    + "\n\n"
    + MARKER_START
    + "\n"
    + CODE.split(MARKER_START, 1)[1].rsplit(MARKER_END, 1)[0]
    + MARKER_END
    + "\n"
    + SOURCE[match.start():]
)

TARGET.write_text(NEW_SOURCE, encoding="utf-8")

print("ACADEMY V1 PATCH APPLIED")
print("New routes:")
print("/academy/dashboard")
print("/academy/courses")
print("/academy/batches")
print("/academy/assignments")
print("/academy/resources")
