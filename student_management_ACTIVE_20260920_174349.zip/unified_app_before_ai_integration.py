﻿from smc_base import app
from analytics_base import get_data, HTML
from flask import render_template_string, request, jsonify, send_from_directory
import sqlite3
from pathlib import Path
from datetime import date
import requests


@app.route("/analytics")
def analytics_dashboard():
    (
        students,
        alerts,
        total,
        with_att,
        with_results,
        classes
    ) = get_data()

    return render_template_string(
        HTML,
        students=students,
        alerts=alerts,
        classes=classes,
        total_students=total,
        students_with_attendance=with_att,
        students_with_results=with_results,
        low_attendance=sum(
            1 for s in students
            if 0 < s["attendance"] < 75
        ),
        low_results=sum(
            1 for s in students
            if 0 < s["result"] < 50
        )
    )


@app.route("/api/analytics/ai-explain", methods=["POST"])
def analytics_ai_explain():
    data = request.get_json() or {}

    prompt = f"""
You are Shakil AI, an educational analytics assistant.

Analyze this student data for a teacher.

Student: {data.get("name", "")}
Class: {data.get("class_name", "")}
Attendance: {data.get("attendance", 0)}%
Average Result: {data.get("result", 0)}%

Provide:
1. Short performance summary.
2. Possible academic concerns.
3. Three practical teacher actions.

Do not make medical or psychological diagnoses.
Do not make high-stakes decisions automatically.
Keep the response concise and teacher-friendly.
"""

    try:
        response = requests.post(
            "http://127.0.0.1:11434/api/generate",
            json={
                "model": "llama3.2:3b",
                "prompt": prompt,
                "stream": False,
                "options": {
                    "num_ctx": 2048,
                    "num_predict": 300,
                    "temperature": 0.3
                }
            },
            timeout=60
        )

        result = response.json()

        return jsonify({
            "ok": True,
            "answer": result.get("response", "")
        })

    except Exception as e:
        return jsonify({
            "ok": False,
            "answer": "AI is currently unavailable.",
            "error": str(e)
        }), 503



# =========================================================
# ENGLISH WINGS ACADEMY WEBSITE
# =========================================================

from flask import send_from_directory

EWA_DIR = Path(
    r"C:\Users\Md Shakil Hossain\ShakilAI\websites\student_management\english_wings_academy"
)

@app.route("/website")
@app.route("/website/")
def ewa_home():
    return send_from_directory(EWA_DIR, "index.html")


@app.route("/website/<path:path>")
def ewa_static(path):
    return send_from_directory(EWA_DIR, path)


@app.route("/api/admission", methods=["POST"])
def ewa_admission():
    f = request.form

    applicant = (f.get("applicant_name") or "").strip()[:150]
    guardian = (f.get("guardian") or "").strip()[:150]
    phone = (f.get("phone") or "").strip()[:50]
    desired = (f.get("desired_class") or "").strip()[:100]
    previous = (f.get("previous_school") or "").strip()[:200]
    program = (f.get("program") or "").strip()[:100]

    if not applicant or not phone:
        return jsonify(
            ok=False,
            message="Applicant name and phone are required."
        ), 400

    desired_value = desired
    if program:
        desired_value = f"{desired} ? {program}" if desired else program

    conn = sqlite3.connect(
        r"C:\Users\Md Shakil Hossain\ShakilAI\websites\student_management\students.db",
        timeout=10
    )

    try:
        conn.execute(
            """
            INSERT INTO admissions
            (applicant_name, guardian, phone, desired_class,
             previous_school, status, application_date)
            VALUES (?, ?, ?, ?, ?, ?, ?)
            """,
            (
                applicant,
                guardian,
                phone,
                desired_value,
                previous,
                "Pending",
                date.today().isoformat()
            )
        )
        conn.commit()

        return jsonify(
            ok=True,
            message="Application submitted."
        )

    except Exception as e:
        conn.rollback()
        return jsonify(
            ok=False,
            message=f"Database submission failed: {e}"
        ), 500

    finally:
        conn.close()



if __name__ == "__main__":
    app.run(host="0.0.0.0", port=7200, debug=False)
