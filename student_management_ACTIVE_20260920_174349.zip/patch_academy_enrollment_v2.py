﻿from pathlib import Path

path = Path("smc_base.py")
text = path.read_text(encoding="utf-8")

marker = "# ===== SHAKIL AI ACADEMY V2 ENROLLMENT ====="

if marker in text:
    print("Academy V2 Enrollment already exists - STOP")
    raise SystemExit(0)

code = r'''

# ===== SHAKIL AI ACADEMY V2 ENROLLMENT =====

def _academy_v2_db():
    conn = sqlite3.connect(DATABASE)
    conn.row_factory = sqlite3.Row
    return conn

def _academy_v2_init_db():
    conn = _academy_v2_db()

    conn.execute("""
        CREATE TABLE IF NOT EXISTS academy_enrollments (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            student_id TEXT NOT NULL,
            course_id INTEGER NOT NULL,
            batch_id INTEGER,
            status TEXT NOT NULL DEFAULT 'Active',
            enrolled_at TEXT NOT NULL,
            notes TEXT
        )
    """)

    conn.commit()
    conn.close()

_academy_v2_init_db()


@app.route("/academy/enrollments")
@login_required
def academy_v2_enrollments():
    conn = _academy_v2_db()

    rows = conn.execute("""
        SELECT
            e.id,
            e.student_id,
            e.course_id,
            e.batch_id,
            e.status,
            e.enrolled_at,
            e.notes,
            c.title AS course_title,
            b.name AS batch_name
        FROM academy_enrollments e
        LEFT JOIN academy_courses c ON c.id = e.course_id
        LEFT JOIN academy_batches b ON b.id = e.batch_id
        ORDER BY e.id DESC
    """).fetchall()

    courses = conn.execute("""
        SELECT id, title
        FROM academy_courses
        ORDER BY id DESC
    """).fetchall()

    batches = conn.execute("""
        SELECT id, name, course_id
        FROM academy_batches
        ORDER BY id DESC
    """).fetchall()

    conn.close()

    html = """
    <style>
    .academy-v2-wrap{
        max-width:1100px;
        margin:20px auto;
    }
    .academy-v2-card{
        background:#fff;
        border:1px solid #e2e8f0;
        border-radius:14px;
        padding:22px;
        margin-bottom:20px;
        box-shadow:0 3px 10px rgba(0,0,0,.05);
    }
    .academy-v2-title{
        font-size:24px;
        font-weight:800;
        margin-bottom:18px;
        color:#17202a;
    }
    .academy-v2-grid{
        display:grid;
        grid-template-columns:repeat(3,1fr);
        gap:12px;
    }
    .academy-v2-grid input,
    .academy-v2-grid select,
    .academy-v2-grid textarea{
        width:100%;
        box-sizing:border-box;
        padding:11px;
        border:1px solid #cbd5e1;
        border-radius:8px;
    }
    .academy-v2-btn{
        padding:11px 18px;
        border:0;
        border-radius:8px;
        background:#2563eb;
        color:#fff;
        font-weight:700;
        cursor:pointer;
    }
    .academy-v2-table{
        width:100%;
        border-collapse:collapse;
    }
    .academy-v2-table th,
    .academy-v2-table td{
        padding:10px;
        border-bottom:1px solid #e2e8f0;
        text-align:left;
    }
    .academy-v2-badge{
        padding:5px 9px;
        border-radius:6px;
        background:#dcfce7;
        color:#166534;
        font-weight:700;
    }
    @media(max-width:800px){
        .academy-v2-grid{
            grid-template-columns:1fr;
        }
        .academy-v2-table{
            font-size:13px;
        }
    }
    </style>

    <div class="academy-v2-wrap">

        <div class="academy-v2-card">
            <div class="academy-v2-title">Academy Student Enrollment</div>

            <form method="post" action="/academy/enrollments/add">
                <div class="academy-v2-grid">

                    <input
                        name="student_id"
                        placeholder="Student ID / Username"
                        required
                    >

                    <select name="course_id" required>
                        <option value="">Select Course</option>
                        {%COURSES%}
                    </select>

                    <select name="batch_id">
                        <option value="">Select Batch</option>
                        {%BATCHES%}
                    </select>

                    <select name="status">
                        <option value="Active">Active</option>
                        <option value="Completed">Completed</option>
                        <option value="Cancelled">Cancelled</option>
                    </select>

                    <input
                        name="enrolled_at"
                        type="date"
                        required
                    >

                    <input
                        name="notes"
                        placeholder="Notes"
                    >

                </div>

                <br>
                <button class="academy-v2-btn" type="submit">
                    Enroll Student
                </button>
            </form>
        </div>

        <div class="academy-v2-card">
            <div class="academy-v2-title">Enrollment Records</div>

            <table class="academy-v2-table">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Student</th>
                        <th>Course</th>
                        <th>Batch</th>
                        <th>Status</th>
                        <th>Enrolled</th>
                    </tr>
                </thead>
                <tbody>
                    {%ROWS%}
                </tbody>
            </table>
        </div>

    </div>
    """

    course_html = ""
    for c in courses:
        course_html += (
            '<option value="' + str(c["id"]) + '">' +
            str(c["title"]) +
            '</option>'
        )

    batch_html = ""
    for b in batches:
        batch_html += (
            '<option value="' + str(b["id"]) + '">' +
            str(b["name"]) +
            '</option>'
        )

    row_html = ""

    for r in rows:
        course = r["course_title"] or str(r["course_id"])
        batch = r["batch_name"] or (
            str(r["batch_id"]) if r["batch_id"] else "-"
        )

        row_html += (
            "<tr>"
            "<td>" + str(r["id"]) + "</td>"
            "<td>" + str(r["student_id"]) + "</td>"
            "<td>" + str(course) + "</td>"
            "<td>" + str(batch) + "</td>"
            "<td><span class='academy-v2-badge'>" +
            str(r["status"]) +
            "</span></td>"
            "<td>" + str(r["enrolled_at"]) + "</td>"
            "</tr>"
        )

    html = html.replace("{%COURSES%}", course_html)
    html = html.replace("{%BATCHES%}", batch_html)

    if not row_html:
        row_html = (
            "<tr><td colspan='6'>"
            "No enrollment records yet."
            "</td></tr>"
        )

    html = html.replace("{%ROWS%}", row_html)

    return page("Academy Enrollments", html)


@app.route("/academy/enrollments/add", methods=["POST"])
@login_required
def academy_v2_add_enrollment():

    student_id = request.form.get("student_id", "").strip()
    course_id = request.form.get("course_id", "").strip()
    batch_id = request.form.get("batch_id", "").strip()
    status = request.form.get("status", "Active").strip()
    enrolled_at = request.form.get("enrolled_at", "").strip()
    notes = request.form.get("notes", "").strip()

    if not student_id or not course_id or not enrolled_at:
        flash("Student, course and enrollment date are required.")
        return redirect("/academy/enrollments")

    conn = _academy_v2_db()

    conn.execute("""
        INSERT INTO academy_enrollments
        (student_id, course_id, batch_id, status, enrolled_at, notes)
        VALUES (?, ?, ?, ?, ?, ?)
    """, (
        student_id,
        int(course_id),
        int(batch_id) if batch_id else None,
        status,
        enrolled_at,
        notes
    ))

    conn.commit()
    conn.close()

    flash("Student enrolled successfully.")
    return redirect("/academy/enrollments")

# ===== END SHAKIL AI ACADEMY V2 ENROLLMENT =====
'''

anchor = 'if __name__ == "__main__":'

if anchor not in text:
    print("ANCHOR NOT FOUND - STOP")
    raise SystemExit(1)

text = text.replace(anchor, code + "\n\n" + anchor, 1)

path.write_text(text, encoding="utf-8")

print("ACADEMY V2 ENROLLMENT PATCH OK")
