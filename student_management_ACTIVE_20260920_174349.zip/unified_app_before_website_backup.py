﻿from smc_base import app
from analytics_base import get_data, HTML
from flask import render_template_string, request, jsonify
import requests


@app.route("/analytics")
def analytics_dashboard():
    (
        students,
        alerts,
        total,
        with_att,
        with_results,
        classes
    ) = get_data()

    return render_template_string(
        HTML,
        students=students,
        alerts=alerts,
        classes=classes,
        total_students=total,
        students_with_attendance=with_att,
        students_with_results=with_results,
        low_attendance=sum(
            1 for s in students
            if 0 < s["attendance"] < 75
        ),
        low_results=sum(
            1 for s in students
            if 0 < s["result"] < 50
        )
    )


@app.route("/api/analytics/ai-explain", methods=["POST"])
def analytics_ai_explain():
    data = request.get_json() or {}

    prompt = f"""
You are Shakil AI, an educational analytics assistant.

Analyze this student data for a teacher.

Student: {data.get("name", "")}
Class: {data.get("class_name", "")}
Attendance: {data.get("attendance", 0)}%
Average Result: {data.get("result", 0)}%

Provide:
1. Short performance summary.
2. Possible academic concerns.
3. Three practical teacher actions.

Do not make medical or psychological diagnoses.
Do not make high-stakes decisions automatically.
Keep the response concise and teacher-friendly.
"""

    try:
        response = requests.post(
            "http://127.0.0.1:11434/api/generate",
            json={
                "model": "llama3.2:3b",
                "prompt": prompt,
                "stream": False,
                "options": {
                    "num_ctx": 2048,
                    "num_predict": 300,
                    "temperature": 0.3
                }
            },
            timeout=60
        )

        result = response.json()

        return jsonify({
            "ok": True,
            "answer": result.get("response", "")
        })

    except Exception as e:
        return jsonify({
            "ok": False,
            "answer": "AI is currently unavailable.",
            "error": str(e)
        }), 503


if __name__ == "__main__":
    app.run(host="0.0.0.0", port=7200, debug=False)
