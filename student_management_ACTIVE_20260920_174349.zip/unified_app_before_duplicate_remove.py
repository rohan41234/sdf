from smc_base import app
from analytics_base import get_data, HTML
from flask import render_template_string, request, jsonify, send_from_directory
import sqlite3
from pathlib import Path
from datetime import date
import requests


@app.route("/analytics")
def analytics_dashboard():
    (
        students,
        alerts,
        total,
        with_att,
        with_results,
        classes
    ) = get_data()

    return render_template_string(
        HTML,
        students=students,
        alerts=alerts,
        classes=classes,
        total_students=total,
        students_with_attendance=with_att,
        students_with_results=with_results,
        low_attendance=sum(
            1 for s in students
            if 0 < s["attendance"] < 75
        ),
        low_results=sum(
            1 for s in students
            if 0 < s["result"] < 50
        )
    )


@app.route("/api/analytics/ai-explain", methods=["POST"])
def analytics_ai_explain():
    data = request.get_json() or {}

    prompt = f"""
You are Shakil AI, an educational analytics assistant.

Analyze this student data for a teacher.

Student: {data.get("name", "")}
Class: {data.get("class_name", "")}
Attendance: {data.get("attendance", 0)}%
Average Result: {data.get("result", 0)}%

Provide:
1. Short performance summary.
2. Possible academic concerns.
3. Three practical teacher actions.

Do not make medical or psychological diagnoses.
Do not make high-stakes decisions automatically.
Keep the response concise and teacher-friendly.
"""

    try:
        response = requests.post(
            "http://127.0.0.1:11434/api/generate",
            json={
                "model": "llama3.2:3b",
                "prompt": prompt,
                "stream": False,
                "options": {
                    "num_ctx": 2048,
                    "num_predict": 300,
                    "temperature": 0.3
                }
            },
            timeout=60
        )

        result = response.json()

        return jsonify({
            "ok": True,
            "answer": result.get("response", "")
        })

    except Exception as e:
        return jsonify({
            "ok": False,
            "answer": "AI is currently unavailable.",
            "error": str(e)
        }), 503



# =========================================================
# ENGLISH WINGS ACADEMY WEBSITE
# =========================================================

from flask import send_from_directory

EWA_DIR = Path(
    r"C:\Users\Md Shakil Hossain\ShakilAI\websites\student_management\english_wings_academy"
)

@app.route("/website")
@app.route("/website/")
def ewa_home():
    return send_from_directory(EWA_DIR, "index.html")


@app.route("/website/<path:path>")
def ewa_static(path):
    return send_from_directory(EWA_DIR, path)


@app.route("/api/admission", methods=["POST"])
def ewa_admission():
    f = request.form

    applicant = (f.get("applicant_name") or "").strip()[:150]
    guardian = (f.get("guardian") or "").strip()[:150]
    phone = (f.get("phone") or "").strip()[:50]
    desired = (f.get("desired_class") or "").strip()[:100]
    previous = (f.get("previous_school") or "").strip()[:200]
    program = (f.get("program") or "").strip()[:100]

    if not applicant or not phone:
        return jsonify(
            ok=False,
            message="Applicant name and phone are required."
        ), 400

    desired_value = desired
    if program:
        desired_value = f"{desired} ? {program}" if desired else program

    conn = sqlite3.connect(
        r"C:\Users\Md Shakil Hossain\ShakilAI\websites\student_management\students.db",
        timeout=10
    )

    try:
        conn.execute(
            """
            INSERT INTO admissions
            (applicant_name, guardian, phone, desired_class,
             previous_school, status, application_date)
            VALUES (?, ?, ?, ?, ?, ?, ?)
            """,
            (
                applicant,
                guardian,
                phone,
                desired_value,
                previous,
                "Pending",
                date.today().isoformat()
            )
        )
        conn.commit()

        return jsonify(
            ok=True,
            message="Application submitted."
        )

    except Exception as e:
        conn.rollback()
        return jsonify(
            ok=False,
            message=f"Database submission failed: {e}"
        ), 500

    finally:
        conn.close()




# =========================================================
# SHAKIL AI ASSISTANT
# =========================================================

AI_HTML = """
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Shakil AI Assistant</title>
<style>
body{font-family:Arial,sans-serif;background:#f4f7fb;margin:0}
.container{max-width:900px;margin:30px auto;padding:20px}
.card{background:white;border-radius:14px;padding:20px;box-shadow:0 3px 15px #0001}
h1{margin-top:0}
textarea{width:100%;box-sizing:border-box;min-height:130px;padding:14px;border:1px solid #ccd4df;border-radius:10px;font-size:16px}
button{margin-top:12px;padding:12px 22px;border:0;border-radius:8px;background:#1769aa;color:white;font-size:16px;cursor:pointer}
button:disabled{opacity:.6}
#answer{margin-top:20px;padding:18px;background:#f8fafc;border-radius:10px;white-space:pre-wrap;line-height:1.6}
.status{font-size:14px;color:#666;margin-top:8px}
</style>
</head>
<body>
<div class="container">
<div class="card">
<h1>🤖 Shakil AI Assistant</h1>
<p>Local AI powered by Ollama.</p>

<textarea id="question"
placeholder="Ask something...&#10;&#10;Example: Create a lesson plan for Class 8 English."></textarea>

<br>

<button id="btn" onclick="askAI()">Ask Shakil AI</button>

<div class="status" id="status"></div>

<div id="answer">AI answer will appear here.</div>
</div>
</div>

<script>
async function askAI(){
    const q=document.getElementById("question").value.trim();
    const btn=document.getElementById("btn");
    const answer=document.getElementById("answer");
    const status=document.getElementById("status");

    if(!q){
        answer.textContent="Please enter a question.";
        return;
    }

    btn.disabled=true;
    status.textContent="AI is thinking...";
    answer.textContent="";

    try{
        const r=await fetch("/api/ask",{
            method:"POST",
            headers:{"Content-Type":"application/json"},
            body:JSON.stringify({question:q})
        });

        const data=await r.json();

        if(data.ok){
            answer.textContent=data.answer;
            status.textContent="Ready";
        }else{
            answer.textContent=data.error || "AI request failed.";
            status.textContent="Error";
        }

    }catch(e){
        answer.textContent="Could not connect to Shakil AI server.";
        status.textContent="Connection error";
    }

    btn.disabled=false;
}
</script>

</body>
</html>
"""


@app.route("/ai")
@app.route("/ai/")
def ai_assistant():
    return AI_HTML


@app.route("/api/ask", methods=["POST"])
def ai_ask():
    data = request.get_json(silent=True) or {}

    question = str(
        data.get("question", "")
    ).strip()

    if not question:
        return jsonify(
            ok=False,
            error="Question is required."
        ), 400

    prompt = f"""
You are Shakil AI, a helpful local educational assistant.

Give clear, practical and accurate answers.

User question:
{question}
"""

    try:
        response = requests.post(
            "http://127.0.0.1:11434/api/generate",
            json={
                "model": "llama3.2:3b",
                "prompt": prompt,
                "stream": False,
                "options": {
                    "num_ctx": 2048,
                    "num_predict": 512,
                    "temperature": 0.3
                }
            },
            timeout=180
        )

        response.raise_for_status()

        result = response.json()

        answer = result.get("response", "")

        if not answer:
            answer = "Ollama returned no answer."

        return jsonify(
            ok=True,
            answer=answer
        )

    except requests.exceptions.RequestException as e:

        print("AI ERROR:", repr(e))

        return jsonify(
            ok=False,
            error="Ollama is unavailable. Make sure Ollama is running and llama3.2:3b is installed."
        ), 503

    except Exception as e:

        print("AI ERROR:", repr(e))

        return jsonify(
            ok=False,
            error="AI request failed."
        ), 500



# =========================================================
# SHAKIL AI ASSISTANT
# =========================================================

AI_HTML = """
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Shakil AI Assistant</title>
<style>
body{font-family:Arial,sans-serif;background:#f4f7fb;margin:0}
.container{max-width:900px;margin:30px auto;padding:20px}
.card{background:white;border-radius:14px;padding:20px;box-shadow:0 3px 15px #0001}
h1{margin-top:0}
textarea{width:100%;box-sizing:border-box;min-height:130px;padding:14px;border:1px solid #ccd4df;border-radius:10px;font-size:16px}
button{margin-top:12px;padding:12px 22px;border:0;border-radius:8px;background:#1769aa;color:white;font-size:16px;cursor:pointer}
button:disabled{opacity:.6}
#answer{margin-top:20px;padding:18px;background:#f8fafc;border-radius:10px;white-space:pre-wrap;line-height:1.6}
.status{font-size:14px;color:#666;margin-top:8px}
</style>
</head>
<body>
<div class="container">
<div class="card">
<h1>🤖 Shakil AI Assistant</h1>
<p>Local AI powered by Ollama.</p>

<textarea id="question"
placeholder="Ask something...&#10;&#10;Example: Create a lesson plan for Class 8 English."></textarea>

<br>

<button id="btn" onclick="askAI()">Ask Shakil AI</button>

<div class="status" id="status"></div>

<div id="answer">AI answer will appear here.</div>
</div>
</div>

<script>
async function askAI(){
    const q=document.getElementById("question").value.trim();
    const btn=document.getElementById("btn");
    const answer=document.getElementById("answer");
    const status=document.getElementById("status");

    if(!q){
        answer.textContent="Please enter a question.";
        return;
    }

    btn.disabled=true;
    status.textContent="AI is thinking...";
    answer.textContent="";

    try{
        const r=await fetch("/api/ask",{
            method:"POST",
            headers:{"Content-Type":"application/json"},
            body:JSON.stringify({question:q})
        });

        const data=await r.json();

        if(data.ok){
            answer.textContent=data.answer;
            status.textContent="Ready";
        }else{
            answer.textContent=data.error || "AI request failed.";
            status.textContent="Error";
        }

    }catch(e){
        answer.textContent="Could not connect to Shakil AI server.";
        status.textContent="Connection error";
    }

    btn.disabled=false;
}
</script>

</body>
</html>
"""


@app.route("/ai")
@app.route("/ai/")
def ai_assistant():
    return AI_HTML


@app.route("/api/ask", methods=["POST"])
def ai_ask():
    data = request.get_json(silent=True) or {}

    question = str(
        data.get("question", "")
    ).strip()

    if not question:
        return jsonify(
            ok=False,
            error="Question is required."
        ), 400

    prompt = f"""
You are Shakil AI, a helpful local educational assistant.

Give clear, practical and accurate answers.

User question:
{question}
"""

    try:
        response = requests.post(
            "http://127.0.0.1:11434/api/generate",
            json={
                "model": "llama3.2:3b",
                "prompt": prompt,
                "stream": False,
                "options": {
                    "num_ctx": 2048,
                    "num_predict": 512,
                    "temperature": 0.3
                }
            },
            timeout=180
        )

        response.raise_for_status()

        result = response.json()

        answer = result.get("response", "")

        if not answer:
            answer = "Ollama returned no answer."

        return jsonify(
            ok=True,
            answer=answer
        )

    except requests.exceptions.RequestException as e:

        print("AI ERROR:", repr(e))

        return jsonify(
            ok=False,
            error="Ollama is unavailable. Make sure Ollama is running and llama3.2:3b is installed."
        ), 503

    except Exception as e:

        print("AI ERROR:", repr(e))

        return jsonify(
            ok=False,
            error="AI request failed."
        ), 500


if __name__ == "__main__":
    app.run(host="0.0.0.0", port=7200, debug=False)
