﻿from flask import Flask, request, jsonify, send_from_directory
import sqlite3
from pathlib import Path
from datetime import date
import os

BASE = Path(__file__).resolve().parent
DB = Path(r"C:\Users\Md Shakil Hossain\ShakilAI\websites\student_management\students.db")

app = Flask(__name__, static_folder=str(BASE), static_url_path="")

def esc_text(v, max_len=500):
    v = (v or "").strip()
    return v[:max_len]

@app.get("/")
def home():
    return send_from_directory(BASE, "index.html")

@app.post("/api/admission")
def public_admission():
    f = request.form
    applicant = esc_text(f.get("applicant_name"), 150)
    guardian = esc_text(f.get("guardian"), 150)
    phone = esc_text(f.get("phone"), 50)
    desired = esc_text(f.get("desired_class"), 100)
    previous = esc_text(f.get("previous_school"), 200)
    program = esc_text(f.get("program"), 100)
    message = esc_text(f.get("message"), 500)

    if not applicant or not phone:
        return jsonify(ok=False, message="Applicant name and phone are required."), 400

    # Store the public enquiry in the existing SMC admissions table.
    # The existing schema already contains message/source fields.
    try:
        con = sqlite3.connect(DB, timeout=10)
        con.execute("""
            INSERT INTO admissions
            (applicant_name, guardian, phone, desired_class, previous_school,
             status, application_date)
            VALUES (?, ?, ?, ?, ?, ?, ?)
        """, (
            applicant,
            guardian,
            phone,
            desired if not program else f"{desired} — {program}" if desired else program,
            previous,
            "Pending",
            date.today().isoformat()
        ))
        con.commit()
        con.close()

        return jsonify(ok=True, message="Application submitted.")

    except Exception as e:
        print("ADMISSION DATABASE ERROR:", repr(e))
        return jsonify(ok=False, message=f"Database submission failed: {e}"), 500

@app.get("/<path:path>")
def static_files(path):
    return send_from_directory(BASE, path)

if __name__ == "__main__":
    host = os.environ.get("EWA_HOST", "0.0.0.0")
    port = int(os.environ.get("EWA_PORT", "8000"))
    app.run(host=host, port=port, debug=False)

