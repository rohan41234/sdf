﻿from pathlib import Path
import html

p = Path("smc_base.py")
text = p.read_text(encoding="utf-8")

if "===== SHAKIL AI PREMIUM COURSES V5 =====" in text:
    print("V5 ALREADY INSTALLED")
    raise SystemExit

marker = "# ===== END SHAKIL AI PREMIUM COURSES V4 ====="

if marker not in text:
    raise SystemExit("V4 END MARKER NOT FOUND - NO CHANGES MADE")

block = r'''
# ===== SHAKIL AI PREMIUM COURSES V5 =====

def _premium_v5_init_db():
    conn = _premium_db()

    conn.execute("""
        CREATE TABLE IF NOT EXISTS premium_tests (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            module_id INTEGER NOT NULL,
            title TEXT NOT NULL,
            description TEXT DEFAULT '',
            duration_minutes INTEGER DEFAULT 30,
            pass_percentage REAL DEFAULT 50,
            created_at TEXT NOT NULL
        )
    """)

    conn.execute("""
        CREATE TABLE IF NOT EXISTS premium_test_questions (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            test_id INTEGER NOT NULL,
            question TEXT NOT NULL,
            option_a TEXT NOT NULL,
            option_b TEXT NOT NULL,
            option_c TEXT NOT NULL,
            option_d TEXT NOT NULL,
            correct_option TEXT NOT NULL,
            marks INTEGER DEFAULT 1,
            sort_order INTEGER DEFAULT 0,
            created_at TEXT NOT NULL
        )
    """)

    conn.execute("""
        CREATE TABLE IF NOT EXISTS premium_test_attempts (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            test_id INTEGER NOT NULL,
            enrollment_id INTEGER NOT NULL,
            username TEXT NOT NULL,
            score REAL DEFAULT 0,
            total_marks REAL DEFAULT 0,
            percentage REAL DEFAULT 0,
            passed INTEGER DEFAULT 0,
            started_at TEXT NOT NULL,
            submitted_at TEXT NOT NULL
        )
    """)

    conn.execute("""
        CREATE TABLE IF NOT EXISTS premium_test_answers (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            attempt_id INTEGER NOT NULL,
            question_id INTEGER NOT NULL,
            selected_option TEXT DEFAULT '',
            is_correct INTEGER DEFAULT 0,
            marks_awarded REAL DEFAULT 0
        )
    """)

    conn.commit()
    conn.close()


@app.route("/premium-courses/admin/module/<int:module_id>/tests", methods=["GET", "POST"])
def premium_admin_tests(module_id):
    if not _premium_admin_required():
        return _premium_redirect(_premium_url_for("login"))

    _premium_v2_init_db()
    _premium_v4_init_db()
    _premium_v5_init_db()

    conn = _premium_db()

    module = conn.execute("""
        SELECT m.*, c.title AS course_title
        FROM premium_modules m
        JOIN premium_courses c ON c.id=m.course_id
        WHERE m.id=?
    """, (module_id,)).fetchone()

    if not module:
        conn.close()
        return "Module not found", 404

    if request.method == "POST":
        title = request.form.get("title", "").strip()
        description = request.form.get("description", "").strip()

        try:
            duration = int(request.form.get("duration_minutes", "30") or 30)
        except ValueError:
            duration = 30

        try:
            pass_percentage = float(
                request.form.get("pass_percentage", "50") or 50
            )
        except ValueError:
            pass_percentage = 50

        duration = max(1, duration)
        pass_percentage = min(100, max(0, pass_percentage))

        if title:
            conn.execute("""
                INSERT INTO premium_tests
                (module_id,title,description,duration_minutes,pass_percentage,created_at)
                VALUES (?,?,?,?,?,?)
            """, (
                module_id,
                title,
                description,
                duration,
                pass_percentage,
                datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            ))
            conn.commit()

        conn.close()

        return _premium_redirect(
            _premium_url_for(
                "premium_admin_tests",
                module_id=module_id
            )
        )

    tests = conn.execute("""
        SELECT
            t.*,
            COUNT(q.id) AS question_count
        FROM premium_tests t
        LEFT JOIN premium_test_questions q
            ON q.test_id=t.id
        WHERE t.module_id=?
        GROUP BY t.id
        ORDER BY t.id
    """, (module_id,)).fetchall()

    conn.close()

    rows = ""

    for t in tests:
        rows += f"""
        <tr>
          <td>{t['id']}</td>
          <td><strong>{html.escape(t['title'])}</strong></td>
          <td>{t['duration_minutes']} min</td>
          <td>{t['question_count']}</td>
          <td>{t['pass_percentage']}%</td>
          <td>
            <a class="btn"
               href="/premium-courses/admin/test/{t['id']}/questions">
               Questions
            </a>

            <form method="post"
                  action="/premium-courses/admin/test/{t['id']}/delete"
                  style="display:inline"
                  onsubmit="return confirm('Delete this test and all questions?')">
              <button class="btn" type="submit">Delete</button>
            </form>
          </td>
        </tr>
        """

    html_content = f"""
    <div class="card">
      <h2>{html.escape(module['course_title'])} → {html.escape(module['title'])}</h2>

      <h3>Create Online Test</h3>

      <form method="post">

        <p>
          <label>Test Title</label>
          <input name="title" required>
        </p>

        <p>
          <label>Description</label>
          <textarea name="description" rows="4"></textarea>
        </p>

        <p>
          <label>Duration (minutes)</label>
          <input type="number"
                 name="duration_minutes"
                 value="30"
                 min="1"
                 max="300">
        </p>

        <p>
          <label>Pass Percentage</label>
          <input type="number"
                 name="pass_percentage"
                 value="50"
                 min="0"
                 max="100"
                 step="0.1">
        </p>

        <button class="btn" type="submit">
          Create Test
        </button>

      </form>
    </div>

    <div class="card">
      <h2>Online Tests</h2>

      <div class="table-wrap">
        <table>
          <tr>
            <th>ID</th>
            <th>Test</th>
            <th>Duration</th>
            <th>Questions</th>
            <th>Pass</th>
            <th>Actions</th>
          </tr>

          {rows or '<tr><td colspan="6">No tests created yet.</td></tr>'}
        </table>
      </div>
    </div>
    """

    return page("Online Tests", html_content)


@app.route("/premium-courses/admin/test/<int:test_id>/questions", methods=["GET", "POST"])
def premium_admin_test_questions(test_id):
    if not _premium_admin_required():
        return _premium_redirect(_premium_url_for("login"))

    _premium_v2_init_db()
    _premium_v4_init_db()
    _premium_v5_init_db()

    conn = _premium_db()

    test = conn.execute("""
        SELECT t.*, m.title AS module_title, m.course_id
        FROM premium_tests t
        JOIN premium_modules m ON m.id=t.module_id
        WHERE t.id=?
    """, (test_id,)).fetchone()

    if not test:
        conn.close()
        return "Test not found", 404

    if request.method == "POST":
        question = request.form.get("question", "").strip()
        option_a = request.form.get("option_a", "").strip()
        option_b = request.form.get("option_b", "").strip()
        option_c = request.form.get("option_c", "").strip()
        option_d = request.form.get("option_d", "").strip()
        correct_option = request.form.get("correct_option", "").strip().lower()

        try:
            marks = int(request.form.get("marks", "1") or 1)
        except ValueError:
            marks = 1

        try:
            sort_order = int(request.form.get("sort_order", "0") or 0)
        except ValueError:
            sort_order = 0

        if (
            question
            and option_a
            and option_b
            and option_c
            and option_d
            and correct_option in ("a", "b", "c", "d")
        ):
            conn.execute("""
                INSERT INTO premium_test_questions
                (
                    test_id,
                    question,
                    option_a,
                    option_b,
                    option_c,
                    option_d,
                    correct_option,
                    marks,
                    sort_order,
                    created_at
                )
                VALUES (?,?,?,?,?,?,?,?,?,?)
            """, (
                test_id,
                question,
                option_a,
                option_b,
                option_c,
                option_d,
                correct_option,
                max(1, marks),
                sort_order,
                datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            ))

            conn.commit()

        conn.close()

        return _premium_redirect(
            _premium_url_for(
                "premium_admin_test_questions",
                test_id=test_id
            )
        )

    questions = conn.execute("""
        SELECT *
        FROM premium_test_questions
        WHERE test_id=?
        ORDER BY sort_order,id
    """, (test_id,)).fetchall()

    conn.close()

    rows = ""

    for q in questions:
        rows += f"""
        <tr>
          <td>{q['id']}</td>
          <td>{html.escape(q['question'])}</td>
          <td>{q['correct_option'].upper()}</td>
          <td>{q['marks']}</td>
          <td>
            <form method="post"
                  action="/premium-courses/admin/question/{q['id']}/delete"
                  onsubmit="return confirm('Delete this question?')">
              <button class="btn" type="submit">Delete</button>
            </form>
          </td>
        </tr>
        """

    html_content = f"""
    <div class="card">
      <h2>
        {html.escape(test['module_title'])}
        → {html.escape(test['title'])}
      </h2>

      <p>
        Duration: <strong>{test['duration_minutes']} minutes</strong>
        &nbsp; | &nbsp;
        Pass: <strong>{test['pass_percentage']}%</strong>
      </p>

      <h3>Add Question</h3>

      <form method="post">

        <p>
          <label>Question</label>
          <textarea name="question" rows="4" required></textarea>
        </p>

        <p>
          <label>Option A</label>
          <input name="option_a" required>
        </p>

        <p>
          <label>Option B</label>
          <input name="option_b" required>
        </p>

        <p>
          <label>Option C</label>
          <input name="option_c" required>
        </p>

        <p>
          <label>Option D</label>
          <input name="option_d" required>
        </p>

        <p>
          <label>Correct Answer</label>
          <select name="correct_option" required>
            <option value="a">A</option>
            <option value="b">B</option>
            <option value="c">C</option>
            <option value="d">D</option>
          </select>
        </p>

        <p>
          <label>Marks</label>
          <input type="number"
                 name="marks"
                 value="1"
                 min="1"
                 max="100">
        </p>

        <p>
          <label>Order</label>
          <input type="number"
                 name="sort_order"
                 value="0">
        </p>

        <button class="btn" type="submit">
          Add Question
        </button>

      </form>
    </div>

    <div class="card">
      <h2>Questions</h2>

      <div class="table-wrap">
        <table>
          <tr>
            <th>ID</th>
            <th>Question</th>
            <th>Answer</th>
            <th>Marks</th>
            <th>Action</th>
          </tr>

          {rows or '<tr><td colspan="5">No questions yet.</td></tr>'}
        </table>
      </div>
    </div>
    """

    return page("Test Questions", html_content)


@app.route("/premium-courses/admin/question/<int:question_id>/delete", methods=["POST"])
def premium_admin_question_delete(question_id):
    if not _premium_admin_required():
        return _premium_redirect(_premium_url_for("login"))

    _premium_v2_init_db()
    _premium_v4_init_db()
    _premium_v5_init_db()

    conn = _premium_db()

    q = conn.execute("""
        SELECT test_id
        FROM premium_test_questions
        WHERE id=?
    """, (question_id,)).fetchone()

    if not q:
        conn.close()
        return "Question not found", 404

    conn.execute("""
        DELETE FROM premium_test_questions
        WHERE id=?
    """, (question_id,))

    conn.commit()
    conn.close()

    return _premium_redirect(
        _premium_url_for(
            "premium_admin_test_questions",
            test_id=q["test_id"]
        )
    )


@app.route("/premium-courses/admin/test/<int:test_id>/delete", methods=["POST"])
def premium_admin_test_delete(test_id):
    if not _premium_admin_required():
        return _premium_redirect(_premium_url_for("login"))

    _premium_v2_init_db()
    _premium_v4_init_db()
    _premium_v5_init_db()

    conn = _premium_db()

    test = conn.execute("""
        SELECT module_id
        FROM premium_tests
        WHERE id=?
    """, (test_id,)).fetchone()

    if not test:
        conn.close()
        return "Test not found", 404

    attempts = conn.execute("""
        SELECT id
        FROM premium_test_attempts
        WHERE test_id=?
    """, (test_id,)).fetchall()

    for attempt in attempts:
        conn.execute("""
            DELETE FROM premium_test_answers
            WHERE attempt_id=?
        """, (attempt["id"],))

    conn.execute("""
        DELETE FROM premium_test_attempts
        WHERE test_id=?
    """, (test_id,))

    conn.execute("""
        DELETE FROM premium_test_questions
        WHERE test_id=?
    """, (test_id,))

    conn.execute("""
        DELETE FROM premium_tests
        WHERE id=?
    """, (test_id,))

    conn.commit()
    conn.close()

    return _premium_redirect(
        _premium_url_for(
            "premium_admin_tests",
            module_id=test["module_id"]
        )
    )


@app.route("/my-premium-courses/<int:enrollment_id>/test/<int:test_id>")
def premium_student_test(enrollment_id, test_id):
    if "username" not in session:
        return _premium_redirect(_premium_url_for("login"))

    _premium_v2_init_db()
    _premium_v4_init_db()
    _premium_v5_init_db()

    username = session.get("username")

    conn = _premium_db()

    enrollment = conn.execute("""
        SELECT e.*, c.title AS course_title
        FROM premium_enrollments e
        JOIN premium_courses c ON c.id=e.course_id
        WHERE e.id=? AND e.username=?
    """, (enrollment_id, username)).fetchone()

    if not enrollment:
        conn.close()
        return "Enrollment not found", 404

    test = conn.execute("""
        SELECT
            t.*,
            m.title AS module_title,
            m.course_id
        FROM premium_tests t
        JOIN premium_modules m ON m.id=t.module_id
        WHERE t.id=? AND m.course_id=?
    """, (test_id, enrollment["course_id"])).fetchone()

    if not test:
        conn.close()
        return "Test not found", 404

    questions = conn.execute("""
        SELECT *
        FROM premium_test_questions
        WHERE test_id=?
        ORDER BY sort_order,id
    """, (test_id,)).fetchall()

    conn.close()

    if not questions:
        return page(
            "Online Test",
            """
            <div class="card">
              <h2>Test Not Ready</h2>
              <p>This test does not have any questions yet.</p>
            </div>
            """
        )

    question_html = ""

    for index, q in enumerate(questions, start=1):
        question_html += f"""
        <div class="card">
          <p>
            <strong>Question {index}</strong>
            ({q['marks']} mark{'s' if q['marks'] != 1 else ''})
          </p>

          <p>{html.escape(q['question'])}</p>

          <label>
            <input type="radio"
                   name="q_{q['id']}"
                   value="a"
                   required>
            A. {html.escape(q['option_a'])}
          </label>
          <br>

          <label>
            <input type="radio"
                   name="q_{q['id']}"
                   value="b">
            B. {html.escape(q['option_b'])}
          </label>
          <br>

          <label>
            <input type="radio"
                   name="q_{q['id']}"
                   value="c">
            C. {html.escape(q['option_c'])}
          </label>
          <br>

          <label>
            <input type="radio"
                   name="q_{q['id']}"
                   value="d">
            D. {html.escape(q['option_d'])}
          </label>
        </div>
        """

    html_content = f"""
    <div class="card">
      <h1>{html.escape(test['title'])}</h1>

      <p>
        Course: {html.escape(enrollment['course_title'])}
      </p>

      <p>
        Module: {html.escape(test['module_title'])}
      </p>

      <p>
        <strong>Duration:</strong>
        {test['duration_minutes']} minutes
      </p>

      <p>
        <strong>Pass mark:</strong>
        {test['pass_percentage']}%
      </p>
    </div>

    <form method="post"
          action="/my-premium-courses/{enrollment_id}/test/{test_id}/submit">

      {question_html}

      <div class="card">
        <button class="btn"
                type="submit"
                onclick="return confirm('Submit this test now?')">
          Submit Test
        </button>
      </div>

    </form>
    """

    return page("Online Test", html_content)


@app.route(
    "/my-premium-courses/<int:enrollment_id>/test/<int:test_id>/submit",
    methods=["POST"]
)
def premium_student_test_submit(enrollment_id, test_id):
    if "username" not in session:
        return _premium_redirect(_premium_url_for("login"))

    _premium_v2_init_db()
    _premium_v4_init_db()
    _premium_v5_init_db()

    username = session.get("username")

    conn = _premium_db()

    enrollment = conn.execute("""
        SELECT e.*, c.title AS course_title
        FROM premium_enrollments e
        JOIN premium_courses c ON c.id=e.course_id
        WHERE e.id=? AND e.username=?
    """, (enrollment_id, username)).fetchone()

    if not enrollment:
        conn.close()
        return "Enrollment not found", 404

    test = conn.execute("""
        SELECT
            t.*,
            m.title AS module_title,
            m.course_id
        FROM premium_tests t
        JOIN premium_modules m ON m.id=t.module_id
        WHERE t.id=? AND m.course_id=?
    """, (test_id, enrollment["course_id"])).fetchone()

    if not test:
        conn.close()
        return "Test not found", 404

    questions = conn.execute("""
        SELECT *
        FROM premium_test_questions
        WHERE test_id=?
        ORDER BY sort_order,id
    """, (test_id,)).fetchall()

    if not questions:
        conn.close()
        return "This test has no questions.", 400

    total_marks = 0
    score = 0

    answers = []

    for q in questions:
        selected = request.form.get(
            f"q_{q['id']}",
            ""
        ).strip().lower()

        marks = float(q["marks"] or 1)
        total_marks += marks

        is_correct = (
            1
            if selected and selected == q["correct_option"].lower()
            else 0
        )

        awarded = marks if is_correct else 0
        score += awarded

        answers.append((
            q["id"],
            selected,
            is_correct,
            awarded
        ))

    percentage = (
        (score / total_marks) * 100
        if total_marks > 0
        else 0
    )

    passed = (
        1
        if percentage >= float(test["pass_percentage"] or 50)
        else 0
    )

    now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

    cursor = conn.execute("""
        INSERT INTO premium_test_attempts
        (
            test_id,
            enrollment_id,
            username,
            score,
            total_marks,
            percentage,
            passed,
            started_at,
            submitted_at
        )
        VALUES (?,?,?,?,?,?,?,?,?)
    """, (
        test_id,
        enrollment_id,
        username,
        score,
        total_marks,
        percentage,
        passed,
        now,
        now
    ))

    attempt_id = cursor.lastrowid

    for question_id, selected, is_correct, awarded in answers:
        conn.execute("""
            INSERT INTO premium_test_answers
            (
                attempt_id,
                question_id,
                selected_option,
                is_correct,
                marks_awarded
            )
            VALUES (?,?,?,?,?)
        """, (
            attempt_id,
            question_id,
            selected,
            is_correct,
            awarded
        ))

    conn.commit()
    conn.close()

    result_word = "PASSED" if passed else "NOT PASSED"

    result_class = (
        "color:#15803d;"
        if passed
        else "color:#b91c1c;"
    )

    html_content = f"""
    <div class="card" style="text-align:center">

      <h1>Test Result</h1>

      <h2 style="{result_class}">
        {result_word}
      </h2>

      <p>
        <strong>Score:</strong>
        {score:g} / {total_marks:g}
      </p>

      <p>
        <strong>Percentage:</strong>
        {percentage:.2f}%
      </p>

      <p>
        <strong>Pass Mark:</strong>
        {float(test['pass_percentage'] or 50):.2f}%
      </p>

      <p>
        Attempt ID: {attempt_id}
      </p>

      <p>
        <a class="btn"
           href="/my-premium-courses/{enrollment_id}">
          Back to My Course
        </a>
      </p>

    </div>
    """

    return page("Test Result", html_content)


@app.route("/my-premium-courses/<int:enrollment_id>/test-results")
def premium_student_test_results(enrollment_id):
    if "username" not in session:
        return _premium_redirect(_premium_url_for("login"))

    _premium_v2_init_db()
    _premium_v4_init_db()
    _premium_v5_init_db()

    username = session.get("username")

    conn = _premium_db()

    enrollment = conn.execute("""
        SELECT e.*, c.title AS course_title
        FROM premium_enrollments e
        JOIN premium_courses c ON c.id=e.course_id
        WHERE e.id=? AND e.username=?
    """, (enrollment_id, username)).fetchone()

    if not enrollment:
        conn.close()
        return "Enrollment not found", 404

    attempts = conn.execute("""
        SELECT
            a.*,
            t.title AS test_title
        FROM premium_test_attempts a
        JOIN premium_tests t ON t.id=a.test_id
        WHERE a.enrollment_id=?
        ORDER BY a.id DESC
    """, (enrollment_id,)).fetchall()

    conn.close()

    rows = ""

    for a in attempts:
        status = "Passed" if a["passed"] else "Not Passed"

        rows += f"""
        <tr>
          <td>{html.escape(a['test_title'])}</td>
          <td>{a['score']:g} / {a['total_marks']:g}</td>
          <td>{a['percentage']:.2f}%</td>
          <td>{status}</td>
          <td>{a['submitted_at']}</td>
        </tr>
        """

    html_content = f"""
    <div class="card">
      <h2>Test Results</h2>
      <p>{html.escape(enrollment['course_title'])}</p>
    </div>

    <div class="card">
      <div class="table-wrap">
        <table>
          <tr>
            <th>Test</th>
            <th>Score</th>
            <th>Percentage</th>
            <th>Status</th>
            <th>Submitted</th>
          </tr>

          {rows or '<tr><td colspan="5">No test attempts yet.</td></tr>'}
        </table>
      </div>
    </div>
    """

    return page("Test Results", html_content)


@app.route("/premium-courses/admin/test-results")
def premium_admin_test_results():
    if not _premium_admin_required():
        return _premium_redirect(_premium_url_for("login"))

    _premium_v2_init_db()
    _premium_v4_init_db()
    _premium_v5_init_db()

    conn = _premium_db()

    attempts = conn.execute("""
        SELECT
            a.*,
            t.title AS test_title
        FROM premium_test_attempts a
        JOIN premium_tests t ON t.id=a.test_id
        ORDER BY a.id DESC
    """).fetchall()

    conn.close()

    rows = ""

    for a in attempts:
        status = "Passed" if a["passed"] else "Not Passed"

        rows += f"""
        <tr>
          <td>{a['id']}</td>
          <td>{html.escape(a['username'])}</td>
          <td>{html.escape(a['test_title'])}</td>
          <td>{a['score']:g} / {a['total_marks']:g}</td>
          <td>{a['percentage']:.2f}%</td>
          <td>{status}</td>
          <td>{a['submitted_at']}</td>
        </tr>
        """

    html_content = f"""
    <div class="card">
      <h2>Premium Test Results</h2>

      <div class="table-wrap">
        <table>
          <tr>
            <th>Attempt</th>
            <th>Student</th>
            <th>Test</th>
            <th>Score</th>
            <th>Percentage</th>
            <th>Status</th>
            <th>Submitted</th>
          </tr>

          {rows or '<tr><td colspan="7">No attempts yet.</td></tr>'}
        </table>
      </div>
    </div>
    """

    return page("Premium Test Results", html_content)


# ===== END SHAKIL AI PREMIUM COURSES V5 =====
'''

text = text.replace(
    marker,
    marker + "\n" + block,
    1
)

p.write_text(text, encoding="utf-8")

print("V5 PATCH APPLIED")
