﻿from pathlib import Path

p = Path("smc_base.py")
s = p.read_text(encoding="utf-8")

old = '"students":("Academy Students",'
new = '"ielts":("IELTS",[("student_id","Student ID",1),("skill","Skill",0),("module","Module",0),("test_no","Test No.",0),("score","Score",0),("remarks","Remarks",0)]),\n"students":("Academy Students",'

if old not in s:
    print("TARGET NOT FOUND")
    raise SystemExit(1)

s = s.replace(old, new, 1)
p.write_text(s, encoding="utf-8")

print("PATCH APPLIED: IELTS module added to ACADEMY_MODULES")
