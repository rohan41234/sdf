﻿from pathlib import Path
import re

src = Path("smc_base.py")
text = src.read_text(encoding="utf-8")

MARKER = "# ===== SHAKIL AI PREMIUM COURSES V1 ====="

if MARKER in text:
    print("Premium Courses patch already exists. No changes made.")
    raise SystemExit(0)

# ---------------------------------------------------------
# Insert before the main app.run block
# ---------------------------------------------------------
anchor = 'if __name__ == "__main__":'

if anchor not in text:
    raise SystemExit("ERROR: Could not find Flask app entry point.")

block = r'''
# ===== SHAKIL AI PREMIUM COURSES V1 =====

import os as _premium_os
import sqlite3 as _premium_sqlite3
from pathlib import Path as _PremiumPath
from flask import request as _premium_request, redirect as _premium_redirect, url_for as _premium_url_for, send_from_directory as _premium_send_from_directory
from werkzeug.utils import secure_filename as _premium_secure_filename

_PREMIUM_BASE = _PremiumPath(__file__).resolve().parent
_PREMIUM_UPLOAD_DIR = _PREMIUM_BASE / "premium_uploads"
_PREMIUM_UPLOAD_DIR.mkdir(parents=True, exist_ok=True)

_PREMIUM_ALLOWED = {
    "pdf", "doc", "docx", "ppt", "pptx",
    "xls", "xlsx", "csv",
    "mp4", "webm",
    "jpg", "jpeg", "png"
}

def _premium_db():
    conn = _premium_sqlite3.connect(DATABASE)
    conn.row_factory = _premium_sqlite3.Row
    return conn

def _premium_init_db():
    conn = _premium_db()

    conn.execute("""
        CREATE TABLE IF NOT EXISTS premium_courses (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            title TEXT NOT NULL,
            category TEXT DEFAULT 'General',
            description TEXT DEFAULT '',
            instructor TEXT DEFAULT '',
            price REAL DEFAULT 0,
            duration TEXT DEFAULT '',
            status TEXT DEFAULT 'Published',
            created_at TEXT DEFAULT CURRENT_TIMESTAMP
        )
    """)

    conn.execute("""
        CREATE TABLE IF NOT EXISTS premium_course_files (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            course_id INTEGER NOT NULL,
            original_name TEXT NOT NULL,
            stored_name TEXT NOT NULL,
            file_type TEXT DEFAULT '',
            uploaded_at TEXT DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY(course_id) REFERENCES premium_courses(id)
        )
    """)

    conn.commit()
    conn.close()

_premium_init_db()

def _premium_admin_required():
    if not session.get("username"):
        return False
    return True

def _premium_page(title, content):
    return page(title, content)

@app.route("/premium-courses")
def premium_courses():
    _premium_init_db()
    conn = _premium_db()
    courses = conn.execute("""
        SELECT *
        FROM premium_courses
        WHERE status='Published'
        ORDER BY id DESC
    """).fetchall()
    conn.close()

    cards = ""

    for c in courses:
        price = c["price"] or 0

        cards += f"""
        <div class="card">
            <h2>{esc(c["title"])}</h2>
            <p><strong>Category:</strong> {esc(c["category"] or "")}</p>
            <p>{esc(c["description"] or "")}</p>
            <p>
                <strong>Instructor:</strong> {esc(c["instructor"] or "English Wings Academy")}
                &nbsp; | &nbsp;
                <strong>Duration:</strong> {esc(c["duration"] or "Flexible")}
            </p>
            <p><strong>Course Fee:</strong> {price:g}</p>
            <a class="btn btn-info"
               href="{_premium_url_for('premium_course_detail', course_id=c['id'])}">
               View Course
            </a>
        </div>
        """

    if not cards:
        cards = """
        <div class="card">
            <h2>No Premium Courses Yet</h2>
            <p>Premium courses will appear here after they are added from the admin panel.</p>
        </div>
        """

    return _premium_page(
        "Premium Courses",
        f"""
        <div class="card">
            <h1>Premium Courses</h1>
            <p>English Wings Academy — Premium Learning</p>
        </div>

        <div class="grid">
            {cards}
        </div>
        """
    )

@app.route("/premium-courses/<int:course_id>")
def premium_course_detail(course_id):
    _premium_init_db()
    conn = _premium_db()

    course = conn.execute(
        "SELECT * FROM premium_courses WHERE id=?",
        (course_id,)
    ).fetchone()

    if not course:
        conn.close()
        return _premium_page(
            "Course Not Found",
            '<div class="card"><h2>Course not found.</h2></div>'
        ), 404

    files = conn.execute("""
        SELECT *
        FROM premium_course_files
        WHERE course_id=?
        ORDER BY id DESC
    """, (course_id,)).fetchall()

    conn.close()

    file_html = ""

    for f in files:
        file_html += f"""
        <li style="margin-bottom:10px;">
            <a class="btn btn-info"
               href="{_premium_url_for('premium_course_file',
                                       file_id=f['id'])}">
               {esc(f["original_name"])}
            </a>
        </li>
        """

    if not file_html:
        file_html = "<li>No course resources uploaded yet.</li>"

    price = course["price"] or 0

    return _premium_page(
        course["title"],
        f"""
        <div class="card">
            <h1>{esc(course["title"])}</h1>
            <p><strong>Category:</strong> {esc(course["category"] or "")}</p>
            <p><strong>Instructor:</strong> {esc(course["instructor"] or "")}</p>
            <p><strong>Duration:</strong> {esc(course["duration"] or "")}</p>
            <p><strong>Fee:</strong> {price:g}</p>
            <hr>
            <p>{esc(course["description"] or "")}</p>
        </div>

        <div class="card">
            <h2>Course Resources</h2>
            <ul>
                {file_html}
            </ul>
        </div>
        """
    )

@app.route("/premium-courses/file/<int:file_id>")
def premium_course_file(file_id):
    _premium_init_db()
    conn = _premium_db()

    f = conn.execute(
        "SELECT * FROM premium_course_files WHERE id=?",
        (file_id,)
    ).fetchone()

    conn.close()

    if not f:
        return "File not found", 404

    stored = f["stored_name"]

    return _premium_send_from_directory(
        str(_PREMIUM_UPLOAD_DIR),
        stored,
        as_attachment=False,
        download_name=f["original_name"]
    )

@app.route("/premium-courses/admin")
def premium_courses_admin():
    if not _premium_admin_required():
        return _premium_redirect(_premium_url_for("login"))

    _premium_init_db()
    conn = _premium_db()

    courses = conn.execute("""
        SELECT c.*,
               COUNT(f.id) AS file_count
        FROM premium_courses c
        LEFT JOIN premium_course_files f
               ON c.id=f.course_id
        GROUP BY c.id
        ORDER BY c.id DESC
    """).fetchall()

    conn.close()

    rows = ""

    for c in courses:
        rows += f"""
        <tr>
            <td>{c["id"]}</td>
            <td>{esc(c["title"])}</td>
            <td>{esc(c["category"] or "")}</td>
            <td>{c["price"] or 0:g}</td>
            <td>{c["file_count"]}</td>
            <td>{esc(c["status"] or "")}</td>
            <td>
                <a class="btn btn-info"
                   href="{_premium_url_for('premium_course_admin_detail',
                                           course_id=c['id'])}">
                   Manage
                </a>

                <form method="post"
                      action="{_premium_url_for('premium_course_admin_delete',
                                                course_id=c['id'])}"
                      style="display:inline;"
                      onsubmit="return confirm('Delete this course?');">
                    <button class="btn btn-danger" type="submit">Delete</button>
                </form>
            </td>
        </tr>
        """

    return _premium_page(
        "Premium Course Admin",
        f"""
        <div class="card">
            <h1>Premium Course Management</h1>

            <a class="btn btn-success"
               href="{_premium_url_for('premium_course_admin_create')}">
               + Add Premium Course
            </a>
        </div>

        <div class="card table-wrap">
            <table>
                <tr>
                    <th>ID</th>
                    <th>Course</th>
                    <th>Category</th>
                    <th>Fee</th>
                    <th>Files</th>
                    <th>Status</th>
                    <th>Actions</th>
                </tr>
                {rows}
            </table>
        </div>
        """
    )

@app.route("/premium-courses/admin/create", methods=["GET", "POST"])
def premium_course_admin_create():
    if not _premium_admin_required():
        return _premium_redirect(_premium_url_for("login"))

    if _premium_request.method == "POST":
        title = _premium_request.form.get("title", "").strip()
        category = _premium_request.form.get("category", "General").strip()
        description = _premium_request.form.get("description", "").strip()
        instructor = _premium_request.form.get("instructor", "").strip()
        duration = _premium_request.form.get("duration", "").strip()
        status = _premium_request.form.get("status", "Published").strip()

        try:
            price = float(_premium_request.form.get("price", "0") or 0)
        except ValueError:
            price = 0

        if not title:
            return _premium_page(
                "Add Premium Course",
                """
                <div class="card">
                    <h2>Course title is required.</h2>
                    <a class="btn" href="/premium-courses/admin/create">Back</a>
                </div>
                """
            )

        conn = _premium_db()
        cur = conn.execute("""
            INSERT INTO premium_courses
            (title, category, description, instructor, price, duration, status)
            VALUES (?, ?, ?, ?, ?, ?, ?)
        """, (
            title, category, description, instructor,
            price, duration, status
        ))

        course_id = cur.lastrowid
        conn.commit()
        conn.close()

        return _premium_redirect(
            _premium_url_for(
                "premium_course_admin_detail",
                course_id=course_id
            )
        )

    return _premium_page(
        "Add Premium Course",
        """
        <div class="card">
            <h1>Add Premium Course</h1>

            <form method="post">

                <label>Course Title</label>
                <input name="title" required>

                <label>Category</label>
                <input name="category" value="IELTS">

                <label>Instructor</label>
                <input name="instructor" value="Md Shakil Hossain">

                <label>Duration</label>
                <input name="duration" placeholder="8 Weeks">

                <label>Course Fee</label>
                <input name="price" type="number" step="0.01" value="0">

                <label>Status</label>
                <select name="status">
                    <option>Published</option>
                    <option>Draft</option>
                </select>

                <label>Description</label>
                <textarea name="description"
                          style="width:100%;min-height:150px;padding:10px;"></textarea>

                <button class="btn btn-success" type="submit">
                    Create Course
                </button>

                <a class="btn"
                   href="/premium-courses/admin">
                   Cancel
                </a>

            </form>
        </div>
        """
    )

@app.route("/premium-courses/admin/<int:course_id>")
def premium_course_admin_detail(course_id):
    if not _premium_admin_required():
        return _premium_redirect(_premium_url_for("login"))

    _premium_init_db()
    conn = _premium_db()

    course = conn.execute(
        "SELECT * FROM premium_courses WHERE id=?",
        (course_id,)
    ).fetchone()

    files = conn.execute("""
        SELECT *
        FROM premium_course_files
        WHERE course_id=?
        ORDER BY id DESC
    """, (course_id,)).fetchall()

    conn.close()

    if not course:
        return "Course not found", 404

    files_html = ""

    for f in files:
        files_html += f"""
        <tr>
            <td>{esc(f["original_name"])}</td>
            <td>{esc(f["file_type"])}</td>
            <td>
                <a class="btn btn-info"
                   href="{_premium_url_for('premium_course_file',
                                           file_id=f['id'])}">
                   Open
                </a>

                <form method="post"
                      action="{_premium_url_for(
                          'premium_course_admin_file_delete',
                          file_id=f['id']
                      )}"
                      style="display:inline;"
                      onsubmit="return confirm('Delete this file?');">
                    <button class="btn btn-danger" type="submit">
                        Delete
                    </button>
                </form>
            </td>
        </tr>
        """

    if not files_html:
        files_html = """
        <tr>
            <td colspan="3">No resources uploaded.</td>
        </tr>
        """

    return _premium_page(
        "Manage Premium Course",
        f"""
        <div class="card">
            <h1>{esc(course["title"])}</h1>
            <p>{esc(course["description"] or "")}</p>
        </div>

        <div class="card">
            <h2>Upload Course Resource</h2>

            <form method="post"
                  enctype="multipart/form-data"
                  action="{_premium_url_for(
                      'premium_course_admin_upload',
                      course_id=course_id
                  )}">

                <input type="file"
                       name="file"
                       required>

                <button class="btn btn-success" type="submit">
                    Upload File
                </button>
            </form>

            <p>
                Allowed:
                PDF, DOC, DOCX, PPT, PPTX, XLS, XLSX, CSV,
                MP4, WEBM, JPG, JPEG, PNG
            </p>
        </div>

        <div class="card table-wrap">
            <h2>Uploaded Resources</h2>

            <table>
                <tr>
                    <th>File</th>
                    <th>Type</th>
                    <th>Action</th>
                </tr>
                {files_html}
            </table>
        </div>

        <a class="btn"
           href="/premium-courses/admin">
           ← Back to Courses
        </a>
        """
    )

@app.route("/premium-courses/admin/upload/<int:course_id>",
           methods=["POST"])
def premium_course_admin_upload(course_id):
    if not _premium_admin_required():
        return _premium_redirect(_premium_url_for("login"))

    file = _premium_request.files.get("file")

    if not file or not file.filename:
        return "No file selected", 400

    original = file.filename
    safe = _premium_secure_filename(original)

    if not safe:
        return "Invalid filename", 400

    ext = safe.rsplit(".", 1)[-1].lower() if "." in safe else ""

    if ext not in _PREMIUM_ALLOWED:
        return f"File type .{ext} is not allowed.", 400

    _premium_init_db()

    conn = _premium_db()
    course = conn.execute(
        "SELECT id FROM premium_courses WHERE id=?",
        (course_id,)
    ).fetchone()

    if not course:
        conn.close()
        return "Course not found", 404

    import uuid as _premium_uuid

    stored = (
        _premium_uuid.uuid4().hex
        + "_"
        + safe
    )

    file.save(str(_PREMIUM_UPLOAD_DIR / stored))

    conn.execute("""
        INSERT INTO premium_course_files
        (course_id, original_name, stored_name, file_type)
        VALUES (?, ?, ?, ?)
    """, (
        course_id,
        original,
        stored,
        ext
    ))

    conn.commit()
    conn.close()

    return _premium_redirect(
        _premium_url_for(
            "premium_course_admin_detail",
            course_id=course_id
        )
    )

@app.route("/premium-courses/admin/file-delete/<int:file_id>",
           methods=["POST"])
def premium_course_admin_file_delete(file_id):
    if not _premium_admin_required():
        return _premium_redirect(_premium_url_for("login"))

    _premium_init_db()
    conn = _premium_db()

    f = conn.execute(
        "SELECT * FROM premium_course_files WHERE id=?",
        (file_id,)
    ).fetchone()

    if not f:
        conn.close()
        return "File not found", 404

    course_id = f["course_id"]

    try:
        (_PREMIUM_UPLOAD_DIR / f["stored_name"]).unlink(
            missing_ok=True
        )
    except Exception:
        pass

    conn.execute(
        "DELETE FROM premium_course_files WHERE id=?",
        (file_id,)
    )

    conn.commit()
    conn.close()

    return _premium_redirect(
        _premium_url_for(
            "premium_course_admin_detail",
            course_id=course_id
        )
    )

@app.route("/premium-courses/admin/delete/<int:course_id>",
           methods=["POST"])
def premium_course_admin_delete(course_id):
    if not _premium_admin_required():
        return _premium_redirect(_premium_url_for("login"))

    _premium_init_db()
    conn = _premium_db()

    files = conn.execute("""
        SELECT stored_name
        FROM premium_course_files
        WHERE course_id=?
    """, (course_id,)).fetchall()

    for f in files:
        try:
            (_PREMIUM_UPLOAD_DIR / f["stored_name"]).unlink(
                missing_ok=True
            )
        except Exception:
            pass

    conn.execute(
        "DELETE FROM premium_course_files WHERE course_id=?",
        (course_id,)
    )

    conn.execute(
        "DELETE FROM premium_courses WHERE id=?",
        (course_id,)
    )

    conn.commit()
    conn.close()

    return _premium_redirect(
        _premium_url_for("premium_courses_admin")
    )

# ===== END SHAKIL AI PREMIUM COURSES V1 =====

'''

new_text = text.replace(anchor, block + "\n" + anchor, 1)

src.write_text(new_text, encoding="utf-8")

print("PREMIUM COURSES V1 APPLIED")
