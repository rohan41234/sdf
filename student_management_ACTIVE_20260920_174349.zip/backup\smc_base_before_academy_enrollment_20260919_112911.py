﻿import qrcode
import io
import socket
from flask import send_file
import os
import sqlite3
from functools import wraps
from datetime import date, datetime
from flask import Flask, request, redirect, url_for, session, render_template_string, flash, send_from_directory, jsonify
from werkzeug.security import generate_password_hash, check_password_hash
from werkzeug.utils import secure_filename

app = Flask(__name__)

_secret = os.environ.get("SHAKIL_AI_SECRET")

if not _secret:
    if os.environ.get("FLASK_ENV") == "development" or __name__ == "__main__":
        import secrets
        _secret = secrets.token_hex(32)
        print("WARNING: SHAKIL_AI_SECRET not set. Using a temporary random key for this run only.")

    else:
        raise RuntimeError(
            "SHAKIL_AI_SECRET environment variable is not set. Set it to a "
            "long random value before running this app."
        )

app.secret_key = _secret
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DATABASE = r"C:\Users\Md Shakil Hossain\ShakilAI\websites\student_management\students.db"
UPLOAD_DIR = os.path.join(BASE_DIR, "static", "uploads", "students")
ALLOWED_PHOTO_EXTENSIONS = {"jpg", "jpeg", "png", "webp"}

os.makedirs(UPLOAD_DIR, exist_ok=True)

ROLES = ["Admin", "Teacher", "Student", "Parent", "Accountant"]

# Additional complete-school modules are stored in the same SQLite database.



# =========================================================
# DATABASE
# =========================================================

def get_db():
    conn = sqlite3.connect(DATABASE)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON")
    return conn


def init_db():
    conn = get_db()

    conn.execute("""
        CREATE TABLE IF NOT EXISTS students (
            id TEXT PRIMARY KEY,
            name TEXT NOT NULL,
            class_name TEXT NOT NULL,
            section TEXT,
            roll TEXT,
            guardian TEXT,
            phone TEXT,
            photo TEXT
        )
    """)

    conn.execute("""
        CREATE TABLE IF NOT EXISTS attendance (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            student_id TEXT NOT NULL,
            attendance_date TEXT NOT NULL,
            status TEXT NOT NULL,
            UNIQUE(student_id, attendance_date)
        )
    """)

    conn.execute("""
        CREATE TABLE IF NOT EXISTS results (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            student_id TEXT NOT NULL,
            exam_name TEXT NOT NULL,
            subject TEXT NOT NULL,
            marks REAL NOT NULL,
            total_marks REAL NOT NULL
        )
    """)

    conn.execute("""
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT UNIQUE NOT NULL,
            password TEXT NOT NULL,
            role TEXT NOT NULL
        )
    """)

    admin = conn.execute(
        "SELECT id FROM users WHERE username=?", ("admin",)
    ).fetchone()

    if not admin:
        initial_password = os.environ.get("SHAKIL_AI_ADMIN_PASSWORD")
        if not initial_password:
            import secrets
            initial_password = secrets.token_urlsafe(9)
        conn.execute(
            "INSERT INTO users (username, password, role) VALUES (?, ?, ?)",
            ("admin", generate_password_hash(initial_password), "Admin")
        )
        print("==========================================")
        print(" First-time setup: admin account created")
        print(" Username: admin")
        print(f" Password: {initial_password}")
        print(" IMPORTANT: log in and change this password now,")
        print(" or set SHAKIL_AI_ADMIN_PASSWORD before first run next time.")
        print("==========================================")

    # Complete School Management modules
    conn.execute("""CREATE TABLE IF NOT EXISTS teachers (
        id TEXT PRIMARY KEY, name TEXT NOT NULL, subject TEXT, phone TEXT,
        email TEXT, designation TEXT, address TEXT
    )""")
    conn.execute("""CREATE TABLE IF NOT EXISTS classes (
        id INTEGER PRIMARY KEY AUTOINCREMENT, class_name TEXT NOT NULL, section TEXT,
        class_teacher TEXT, room TEXT, UNIQUE(class_name, section)
    )""")
    conn.execute("""CREATE TABLE IF NOT EXISTS fees (
        id INTEGER PRIMARY KEY AUTOINCREMENT, student_id TEXT NOT NULL, fee_type TEXT NOT NULL,
        amount REAL NOT NULL, paid REAL NOT NULL DEFAULT 0, due_date TEXT, paid_date TEXT, status TEXT NOT NULL DEFAULT 'Due'
    )""")
    conn.execute("""CREATE TABLE IF NOT EXISTS exams (
        id INTEGER PRIMARY KEY AUTOINCREMENT, exam_name TEXT NOT NULL, class_name TEXT,
        subject TEXT, exam_date TEXT, total_marks REAL DEFAULT 100
    )""")
    conn.execute("""CREATE TABLE IF NOT EXISTS notices (
        id INTEGER PRIMARY KEY AUTOINCREMENT, title TEXT NOT NULL, body TEXT NOT NULL,
        audience TEXT DEFAULT 'All', publish_date TEXT NOT NULL
    )""")
    conn.execute("""CREATE TABLE IF NOT EXISTS routines (
        id INTEGER PRIMARY KEY AUTOINCREMENT, class_name TEXT NOT NULL, section TEXT,
        day_name TEXT NOT NULL, period_no INTEGER NOT NULL, subject TEXT NOT NULL,
        teacher TEXT, room TEXT
    )""")
    conn.execute("""CREATE TABLE IF NOT EXISTS admissions (
        id INTEGER PRIMARY KEY AUTOINCREMENT, applicant_name TEXT NOT NULL, guardian TEXT,
        phone TEXT, desired_class TEXT, previous_school TEXT, status TEXT DEFAULT 'Pending',
        application_date TEXT NOT NULL
    )""")

    # Safe migration for existing student databases created before photo support.
    student_columns = {row[1] for row in conn.execute("PRAGMA table_info(students)").fetchall()}
    if "photo" not in student_columns:
        conn.execute("ALTER TABLE students ADD COLUMN photo TEXT")

    conn.commit()
    conn.close()


# =========================================================
# AUTH
# =========================================================

def login_required(f):
    @wraps(f)
    def decorated(*args, **kwargs):
        if "user_id" not in session:
            return redirect(url_for("login"))
        return f(*args, **kwargs)
    return decorated


def admin_required(f):
    @wraps(f)
    def decorated(*args, **kwargs):
        if "user_id" not in session:
            return redirect(url_for("login"))
        if session.get("role") != "Admin":
            flash("Only administrators can access this page.")
            return redirect(url_for("home"))
        return f(*args, **kwargs)
    return decorated


# =========================================================
# HELPERS
# =========================================================

def esc(value):
    """Small HTML escape helper for values inserted into generated HTML."""
    if value is None:
        return ""
    return (str(value).replace("&", "&amp;").replace("<", "&lt;")
            .replace(">", "&gt;").replace('"', "&quot;").replace("'", "&#39;"))


def grade_from_percentage(p):
    if p >= 80:
        return "A+"
    if p >= 70:
        return "A"
    if p >= 60:
        return "A-"
    if p >= 50:
        return "B"
    if p >= 40:
        return "C"
    if p >= 33:
        return "D"
    return "F"


def grade_point(p):
    if p >= 80: return 5.00
    if p >= 70: return 4.00
    if p >= 60: return 3.50
    if p >= 50: return 3.00
    if p >= 40: return 2.00
    if p >= 33: return 1.00
    return 0.00


def page(title, content, print_css=""):
    if title != "Login" and "window.print()" not in content:
        content = """<div class="no-print" style="display:flex;justify-content:flex-end;margin-bottom:12px;">
        <button type="button" class="btn btn-success" onclick="window.print()">ðŸ–¨ Print / Save PDF</button>
        </div>""" + content

    return render_template_string(
        BASE_HTML,
        title=title,
        content=content,
        print_css=print_css
    )


# =========================================================
# HTML / CSS
# =========================================================

BASE_HTML = r"""
<!doctype html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>{{ title }}</title>
<style>
*{box-sizing:border-box}
html{scroll-behavior:smooth}
body{margin:0;font-family:Arial,Helvetica,sans-serif;background:#f3f6f9;color:#17202a;min-width:0}
body.nav-open{overflow:hidden}
a,button,input,select,textarea{touch-action:manipulation}
nav{box-shadow:0 2px 10px rgba(0,0,0,.08)}
.nav-toggle{display:none;background:#fff;color:#17202a;border:1px solid #ccd3d9;font-size:22px;padding:7px 11px;border-radius:7px;cursor:pointer}
.nav-links{display:flex;flex-wrap:wrap;align-items:center;gap:4px}
.nav-links a{white-space:nowrap}
.table-wrap{width:100%;overflow-x:auto;-webkit-overflow-scrolling:touch}
.table-wrap table{min-width:720px}
.live-status{font-size:13px;color:#667085;margin-left:auto}
.toast{position:fixed;right:18px;bottom:18px;z-index:100;background:#17202a;color:#fff;padding:12px 16px;border-radius:8px;box-shadow:0 4px 18px rgba(0,0,0,.2);display:none}
.toast.show{display:block}
.search-input{min-width:220px}
nav{background:#17202a;color:#fff;padding:14px 20px;position:sticky;top:0;z-index:10}
nav .brand{font-weight:700;font-size:18px;margin-right:20px}
nav a{color:#fff;text-decoration:none;margin:0 7px;font-size:14px}
nav a:hover{text-decoration:underline}
.container{max-width:1250px;margin:24px auto;padding:0 15px}
.card{background:#fff;border-radius:12px;padding:20px;margin-bottom:20px;box-shadow:0 2px 10px rgba(0,0,0,.07)}
.grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(210px,1fr));gap:18px}
.stat{background:#fff;padding:22px;border-radius:12px;text-align:center;box-shadow:0 2px 10px rgba(0,0,0,.07)}
.stat h2{font-size:32px;margin:7px 0}
table{width:100%;border-collapse:collapse;background:#fff}
th,td{padding:10px;border:1px solid #dfe4e8;text-align:left;vertical-align:top}
th{background:#17202a;color:#fff}
input,select{width:100%;padding:10px;margin:5px 0 12px;border:1px solid #ccd3d9;border-radius:6px}
button,.btn{display:inline-block;padding:9px 14px;border:0;border-radius:6px;background:#17202a;color:#fff;text-decoration:none;cursor:pointer}
.btn-success{background:#218c74}.btn-danger{background:#c0392b}.btn-info{background:#2980b9}
.btn-warning{background:#d68910}.actions a{margin:2px 4px 2px 0}
.flash{padding:12px;margin-bottom:15px;border-radius:6px;background:#dff9fb}
.error{color:#c0392b}.muted{color:#667085}.center{text-align:center}
.profile{display:grid;grid-template-columns:180px 1fr;gap:20px}
.avatar{height:180px;border-radius:12px;background:#eaf0f5;display:flex;align-items:center;justify-content:center;font-size:54px;font-weight:bold;color:#5b6b7a}
.student-thumb{width:42px;height:42px;border-radius:50%;object-fit:cover;display:inline-block;vertical-align:middle}.avatar-mini{display:flex;align-items:center;justify-content:center;font-weight:700;background:#e9eef3}.student-photo-preview{width:120px;height:120px;object-fit:cover;border-radius:8px;display:block;margin-bottom:10px}.student-photo-profile{width:110px;height:110px;object-fit:cover;border-radius:50%;display:block}.profile{display:flex;gap:20px;align-items:center}

.badge{display:inline-block;padding:4px 9px;border-radius:20px;background:#eef2f6}
.good{color:#16805d;font-weight:bold}.bad{color:#c0392b;font-weight:bold}
.toolbar{display:flex;gap:10px;flex-wrap:wrap;align-items:center}
.toolbar form{flex:1;min-width:220px}
.toolbar input{margin-bottom:0}
.report-card{background:#fff;padding:28px;border:1px solid #ccd3d9}
.report-head{text-align:center;border-bottom:2px solid #17202a;padding-bottom:15px;margin-bottom:20px}
.report-meta{display:grid;grid-template-columns:repeat(2,1fr);gap:8px;margin-bottom:20px}
.summary{display:grid;grid-template-columns:repeat(4,1fr);gap:10px;margin-top:18px}
.summary div{border:1px solid #ccd3d9;padding:12px;text-align:center}
.login-box{width:380px;max-width:95%;margin:70px auto;background:#fff;padding:30px;border-radius:12px;box-shadow:0 3px 15px rgba(0,0,0,.15)}
@media(max-width:800px){
  .profile{grid-template-columns:1fr}
  .summary{grid-template-columns:repeat(2,1fr)}
  table{font-size:13px}
  nav a{display:inline-block;margin-bottom:7px}
}
@media(max-width:800px){
  nav{padding:10px 12px}
  nav .brand{font-size:16px;margin-right:8px}
  .nav-toggle{display:block;float:right}
  .nav-links{display:none;clear:both;padding-top:10px;max-height:75vh;overflow-y:auto}
  nav.mobile-open .nav-links{display:block}
  .nav-links a,.nav-links .badge{display:block;margin:0;padding:11px 8px;border-bottom:1px solid rgba(255,255,255,.08)}
  .nav-links .badge{background:transparent;color:#d7dee8}
  .container{margin:14px auto;padding:0 10px}
  .grid{grid-template-columns:1fr 1fr!important;gap:10px}
  .stat{padding:15px 10px}
  .stat h2{font-size:25px}
  .card{padding:14px;border-radius:10px}
  table{font-size:12px}
  th,td{padding:8px}
  .toolbar{align-items:stretch}
  .toolbar form{min-width:100%}
  .toolbar .btn{width:100%;text-align:center}
  input,select,textarea{font-size:16px!important}
  button,.btn{min-height:44px}
  .profile{display:flex;flex-direction:column;align-items:flex-start!important}
  .student-photo-profile,.avatar{width:100px;height:100px}
}
@media(max-width:430px){
  .grid{grid-template-columns:1fr!important}
  .summary{grid-template-columns:1fr!important}
}
@media print{
  nav,.no-print,.flash{display:none!important}
  body{background:#fff}
  .container{max-width:none;margin:0;padding:0}
  .card{box-shadow:none;border:0}
  .report-card{border:0}
  {{ print_css|safe }}
}

/* ===== SHAKIL AI SMC MODERN DASHBOARD DESIGN ===== */
:root{--brand:#2563eb;--brand-dark:#1e3a8a;--ink:#17202a;--muted:#64748b;--bg:#f4f7fb;--card:#ffffff;--border:#e2e8f0;--shadow:0 8px 24px rgba(15,23,42,.07)}
body{font-family:Inter,Segoe UI,Arial,Helvetica,sans-serif;background:var(--bg);color:var(--ink);line-height:1.55}
nav{background:linear-gradient(135deg,#0f172a,#1e3a8a);box-shadow:0 4px 18px rgba(15,23,42,.16);border:0}
nav .brand{font-weight:800;letter-spacing:.2px}
.nav-links{gap:5px}
.nav-links a{padding:9px 11px;border-radius:8px;text-decoration:none;transition:background .2s ease,color .2s ease,transform .2s ease}
.nav-links a:hover{background:rgba(255,255,255,.12);color:#fff;text-decoration:none;transform:translateY(-1px)}
.nav-toggle{border:1px solid rgba(255,255,255,.25);background:rgba(255,255,255,.08);color:#fff}
.container{max-width:1280px;margin:28px auto;padding:0 20px}
.card{background:var(--card);border:1px solid var(--border);border-radius:16px;padding:22px;margin-bottom:22px;box-shadow:var(--shadow);transition:transform .2s ease,box-shadow .2s ease,border-color .2s ease}
.card:hover{transform:translateY(-2px);box-shadow:0 12px 30px rgba(15,23,42,.10);border-color:#cbd5e1}
.grid{gap:20px}
.stat{background:linear-gradient(180deg,#fff,#f8fafc);border:1px solid var(--border);border-radius:16px;padding:24px 18px;text-align:center;box-shadow:var(--shadow);transition:transform .2s ease,box-shadow .2s ease,border-color .2s ease}
.stat:hover{transform:translateY(-3px);box-shadow:0 14px 30px rgba(37,99,235,.12);border-color:#bfdbfe}
.stat h2{font-size:34px;margin:7px 0;color:var(--brand-dark);font-weight:800}
h1,h2,h3{letter-spacing:-.2px}
h1{font-weight:800}
h2{font-weight:750}
button,.btn,input[type=submit]{border-radius:9px;transition:transform .15s ease,box-shadow .15s ease,opacity .15s ease}
button:hover,.btn:hover,input[type=submit]:hover{transform:translateY(-1px);box-shadow:0 6px 16px rgba(37,99,235,.18)}
input,select,textarea{border:1px solid #cbd5e1;border-radius:9px;padding:9px 11px;background:#fff;transition:border-color .2s ease,box-shadow .2s ease}
input:focus,select:focus,textarea:focus{outline:none;border-color:#60a5fa;box-shadow:0 0 0 3px rgba(37,99,235,.12)}
table{border-radius:12px;overflow:hidden}
th{background:#f8fafc;font-weight:700;color:#334155}
th,td{border-color:var(--border)}
.summary div{border:1px solid var(--border);border-radius:10px;background:#f8fafc;padding:14px}
.login-box{border:1px solid var(--border);border-radius:18px;box-shadow:0 14px 40px rgba(15,23,42,.12)}
.flash{border-radius:10px}
@media(max-width:800px){
  nav{padding:10px 12px}
  .nav-links a{border-bottom:1px solid rgba(255,255,255,.08);border-radius:6px}
  .container{margin:18px auto;padding:0 12px}
  .card{padding:17px;border-radius:14px}
  .stat{padding:18px 12px;border-radius:14px}
  .stat h2{font-size:27px}
}
@media(max-width:430px){
  .container{padding:0 9px}
  .card{padding:14px}
  .stat{padding:16px 10px}
}
/* ===== END MODERN DASHBOARD DESIGN ===== */

/* ===== SHAKIL AI DASHBOARD V2 ===== */
body{background:#f5f7fb;color:#172033}
nav{background:linear-gradient(135deg,#111827 0%,#1e3a8a 55%,#2563eb 100%);padding:13px 18px;position:sticky;top:0;z-index:1000}
nav .brand{font-size:20px;font-weight:800;color:#fff}
.nav-links{gap:6px}
.nav-links a{font-size:14px;padding:9px 12px;color:#e5e7eb;border-radius:8px}
.nav-links a:hover{background:rgba(255,255,255,.14);color:#fff;transform:translateY(-1px)}
.badge{border-radius:999px;padding:5px 10px;font-size:12px;font-weight:700}
.container{max-width:1320px;margin:30px auto;padding:0 22px}
.container>h1{font-size:34px;margin:0 0 5px;color:#111827}
.container>p{color:#64748b;margin:0 0 25px}

.grid{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:18px}
.stat{position:relative;overflow:hidden;min-height:125px;padding:22px 20px;border:1px solid #e5e7eb;border-radius:16px;background:#fff;box-shadow:0 5px 18px rgba(15,23,42,.06);transition:all .2s ease}
.stat:before{content:"";position:absolute;left:0;top:0;width:4px;height:100%;background:#2563eb}
.stat:hover{transform:translateY(-4px);box-shadow:0 14px 30px rgba(37,99,235,.12)}
.stat h3{margin:0;color:#64748b;font-size:14px;font-weight:700;text-transform:uppercase;letter-spacing:.4px}
.stat h2{margin:12px 0 0;font-size:36px;line-height:1;color:#172554;font-weight:800}

.card{border:1px solid #e5e7eb;border-radius:18px;background:#fff;box-shadow:0 6px 20px rgba(15,23,42,.06);padding:24px;margin-bottom:24px}
.card h2{font-size:21px;color:#111827;margin-top:0;margin-bottom:18px}
.card .grid{grid-template-columns:repeat(4,minmax(0,1fr))}
.card .stat{min-height:105px;padding:19px}

.card:has(a.btn){background:linear-gradient(135deg,#ffffff,#f8fbff)}
.btn{border:0;border-radius:9px;padding:10px 15px;font-weight:700;text-decoration:none;display:inline-block;margin:4px;transition:all .18s ease}
.btn:hover{transform:translateY(-2px);box-shadow:0 7px 18px rgba(37,99,235,.18)}

table{border:1px solid #e5e7eb;border-radius:12px;overflow:hidden}
th{background:#f8fafc;color:#334155;font-weight:750}
tr:hover td{background:#f8fbff}

@media(max-width:1000px){
  .grid{grid-template-columns:repeat(2,minmax(0,1fr))}
}
@media(max-width:800px){
  nav{position:relative;padding:10px 12px}
  .container{margin:18px auto;padding:0 12px}
  .container>h1{font-size:28px}
  .grid,.card .grid{grid-template-columns:repeat(2,minmax(0,1fr))!important;gap:12px}
  .stat{min-height:105px;padding:18px 14px}
  .stat h2{font-size:29px}
  .card{padding:17px;border-radius:14px}
}
@media(max-width:430px){
  .grid,.card .grid{grid-template-columns:1fr!important}
  .stat h2{font-size:27px}
}
/* ===== END SHAKIL AI DASHBOARD V2 ===== */

/* ===== SHAKIL AI DASHBOARD V3 ===== */

.dashboard-hero{
  display:flex;
  justify-content:space-between;
  align-items:center;
  gap:24px;
  margin-bottom:24px;
  padding:30px 32px;
  border-radius:22px;
  background:linear-gradient(135deg,#111827 0%,#1e3a8a 55%,#2563eb 100%);
  color:#fff;
  box-shadow:0 14px 35px rgba(15,23,42,.16);
}

.dashboard-kicker{
  font-size:12px;
  font-weight:800;
  letter-spacing:1.5px;
  opacity:.78;
  margin-bottom:8px;
}

.dashboard-hero h1{
  margin:0;
  font-size:34px;
  font-weight:800;
  letter-spacing:-.6px;
}

.dashboard-hero p{
  margin:9px 0 0;
  color:#dbeafe;
  font-size:15px;
}

.dashboard-user{
  min-width:190px;
  padding:16px 18px;
  border:1px solid rgba(255,255,255,.18);
  border-radius:14px;
  background:rgba(255,255,255,.10);
  backdrop-filter:blur(8px);
}

.dashboard-user span:first-child{
  display:block;
  font-size:11px;
  color:#bfdbfe;
  margin-bottom:4px;
}

.dashboard-user strong{
  display:block;
  font-size:17px;
  margin-bottom:8px;
}

.dashboard-user .badge{
  background:rgba(255,255,255,.16);
  color:#fff;
}

.grid>.stat{
  cursor:default;
}

.grid>.stat:nth-child(2):before{background:#7c3aed}
.grid>.stat:nth-child(3):before{background:#0891b2}
.grid>.stat:nth-child(4):before{background:#059669}
.grid>.stat:nth-child(5):before{background:#d97706}
.grid>.stat:nth-child(6):before{background:#dc2626}
.grid>.stat:nth-child(7):before{background:#db2777}
.grid>.stat:nth-child(8):before{background:#4f46e5}

.grid>.stat h3{
  font-size:12px;
}

.grid>.stat h2{
  font-size:38px;
}

.card>h2{
  display:flex;
  align-items:center;
  gap:10px;
}

.card>h2:after{
  content:"";
  flex:1;
  height:1px;
  background:#e5e7eb;
}

.card:has(a.btn){
  position:relative;
}

.card:has(a.btn) .btn{
  min-width:130px;
  text-align:center;
}

.card:last-child{
  background:linear-gradient(135deg,#f8fbff,#eef5ff);
}

.card:last-child .btn{
  border:1px solid #dbeafe;
  background:#fff;
}

@media(max-width:800px){
  .dashboard-hero{
    flex-direction:column;
    align-items:flex-start;
    padding:23px 20px;
  }

  .dashboard-hero h1{
    font-size:27px;
  }

  .dashboard-user{
    width:100%;
    min-width:0;
  }
}

@media(max-width:430px){
  .dashboard-hero{
    padding:20px 17px;
    border-radius:16px;
  }

  .dashboard-hero h1{
    font-size:24px;
  }

  .dashboard-hero p{
    font-size:13px;
  }
}

/* ===== END SHAKIL AI DASHBOARD V3 ===== */

/* ===== ENGLISH WINGS SERVICES BUTTON FIX ===== */

.card:last-child{
  background:linear-gradient(135deg,#f8fbff,#eef5ff);
}

.card:last-child > h2{
  color:#17202a;
  font-size:22px;
  font-weight:800;
  margin-bottom:18px;
}

.card:last-child > h2:after{
  background:#cbd5e1;
}

.card:last-child .btn{
  display:inline-block;
  margin:4px 6px 4px 0;
  min-width:145px;
  padding:10px 16px;
  border:0;
  border-radius:9px;
  background:#2563eb;
  color:#fff;
  font-weight:700;
  text-decoration:none;
  box-shadow:0 3px 8px rgba(37,99,235,.18);
}

.card:last-child .btn:hover{
  background:#1d4ed8;
  color:#fff;
  text-decoration:none;
  transform:translateY(-1px);
}

@media(max-width:800px){
  .card:last-child .btn{
    min-width:130px;
    margin-bottom:7px;
  }
}

/* ===== END ENGLISH WINGS SERVICES BUTTON FIX ===== */

/* ===== ENGLISH WINGS ACADEMY SERVICES FINAL ===== */

.academy-services-card{
  background:#ffffff !important;
  border:1px solid #e2e8f0;
}

.academy-services-title{
  display:block;
  color:#17202a;
  font-size:23px;
  font-weight:800;
  line-height:1.3;
  margin-bottom:18px;
}

.academy-services-buttons{
  display:flex;
  flex-wrap:wrap;
  gap:12px;
}

.academy-service-btn{
  display:inline-flex;
  align-items:center;
  justify-content:center;
  min-width:155px;
  padding:12px 18px;
  border-radius:10px;
  background:#2563eb !important;
  color:#ffffff !important;
  border:1px solid #2563eb !important;
  font-weight:700;
  text-decoration:none !important;
  box-shadow:0 3px 8px rgba(37,99,235,.18);
  transition:all .2s ease;
}

.academy-service-btn:hover{
  background:#1d4ed8 !important;
  border-color:#1d4ed8 !important;
  color:#ffffff !important;
  transform:translateY(-2px);
  box-shadow:0 6px 14px rgba(37,99,235,.25);
}

@media(max-width:800px){
  .academy-services-buttons{
    display:grid;
    grid-template-columns:1fr 1fr;
  }

  .academy-service-btn{
    min-width:0;
  }
}

@media(max-width:430px){
  .academy-services-buttons{
    grid-template-columns:1fr;
  }

  .academy-services-title{
    font-size:20px;
  }
}

/* ===== END ENGLISH WINGS ACADEMY SERVICES FINAL ===== */




</style>
</head>
<body>
{% if session.get("user_id") %}
<nav id="mainNav">
<button class="nav-toggle" type="button" aria-label="Open menu" aria-expanded="false"
        onclick="toggleMobileNav()">Ã¢ËœÂ°</button>
<span class="brand">Shakil AI SMC</span>
<div class="nav-links" id="navLinks">
<a href="{{ url_for('home') }}">Dashboard</a>
<a href="{{ url_for('students') }}">Students</a>
<a href="{{ url_for('attendance') }}">Attendance</a>
<a href="{{ url_for('results') }}">Results</a>
<a href="{{ url_for('performance') }}">Performance</a>
<a href="{{ url_for('attendance_analytics') }}">Attendance Analytics</a>
<a href="{{ url_for('teachers') }}">Teachers</a>
<a href="{{ url_for('classes_page') }}">Classes</a>
<a href="{{ url_for('fees') }}">Fees</a>
<a href="{{ url_for('exams') }}">Exams</a>
<a href="{{ url_for('routine') }}">Routine</a>
<a href="{{ url_for('notices') }}">Notices</a>
<a href="{{ url_for('admissions') }}">Admission</a>
<a href="{{ url_for('reports') }}">Reports</a>
{% if session.get("role") == "Admin" %}<a href="{{ url_for('backup_db') }}">Backup</a>{% endif %}
{% if session.get("role") == "Admin" %}<a href="{{ url_for('users') }}">Users</a>{% endif %}
<span class="badge">Academy</span>
<a href="{{ url_for('academy_module',module='students') }}">Academy Students</a>
<a href="{{ url_for('academy_module',module='notes') }}">Notes</a>
<a href="{{ url_for('academy_module',module='vocabulary') }}">Vocabulary</a>
<a href="{{ url_for('academy_module',module='ielts_papers') }}">IELTS Papers</a>
<a href="{{ url_for('academy_module',module='answer_keys') }}">Answer Keys</a>
<a href="{{ url_for('academy_module',module='tests') }}">Tests</a>
<a href="{{ url_for('academy_module',module='results') }}">Results</a>
<a href="{{ url_for('academy_module',module='progress') }}">Progress</a>
<a href="{{ url_for('academy_module',module='certificates') }}">Certificates</a>
<span class="badge">Consultancy</span>
<a href="{{ url_for('consultancy_module',module='clients') }}">Clients</a>
<a href="{{ url_for('consultancy_module',module='shortlist') }}">Shortlist</a>
<a href="{{ url_for('consultancy_module',module='scholarships') }}">Scholarships</a>
<a href="{{ url_for('consultancy_module',module='applications') }}">Applications</a>
<a href="{{ url_for('consultancy_module',module='checklist') }}">Checklist</a>
<a href="{{ url_for('consultancy_module',module='deadlines') }}">Deadlines</a>
<a href="{{ url_for('consultancy_module',module='offers_visa') }}">Offers/Visa</a>
<a href="{{ url_for('consultancy_module',module='invoices') }}">Invoices</a>
<a href="{{ url_for('change_password') }}">Change Password</a>
<a href="{{ url_for('logout') }}">Logout</a>
</div>
</nav>
{% endif %}
<div class="container">
{% with messages=get_flashed_messages() %}
{% for message in messages %}<div class="flash">{{ message }}</div>{% endfor %}
{% endwith %}
{{ content|safe }}
</div>
<script>
function toggleMobileNav(){
  const nav=document.getElementById('mainNav');
  const btn=nav && nav.querySelector('.nav-toggle');
  if(!nav) return;
  const open=nav.classList.toggle('mobile-open');
  document.body.classList.toggle('nav-open',open);
  if(btn){btn.setAttribute('aria-expanded',open?'true':'false');btn.textContent=open?'Ã¢Å“â€¢':'Ã¢ËœÂ°';}
}
document.addEventListener('click',function(e){
  const nav=document.getElementById('mainNav');
  if(nav && nav.classList.contains('mobile-open') && !nav.contains(e.target)) toggleMobileNav();
});
function showToast(message){
  let t=document.querySelector('.toast');
  if(!t){t=document.createElement('div');t.className='toast';document.body.appendChild(t);}
  t.textContent=message;t.classList.add('show');
  setTimeout(()=>t.classList.remove('show'),2200);
}
async function fetchJSON(url, options={}){
  const r=await fetch(url,{headers:{'X-Requested-With':'XMLHttpRequest','Accept':'application/json',...(options.headers||{})},...options});
  if(!r.ok) throw new Error((await r.text())||('HTTP '+r.status));
  return r.json();
}
</script>

<script>
(function(){
  const $ = (s) => document.querySelector(s);

  function escapeHtml(v){
    return String(v ?? '').replace(/[&<>"']/g, c => ({
      '&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'
    }[c]));
  }

  function studentPhoto(s){
    if(s.photo){
      return '<img class="student-thumb" src="/student-photo/'+encodeURIComponent(s.photo)+'" alt="Photo">';
    }
    return '<div class="student-thumb avatar-mini">'+escapeHtml((s.name||'S').slice(0,1).toUpperCase())+'</div>';
  }

  function studentRow(s){
    const id=encodeURIComponent(s.id||'');
    return '<tr>'+
      '<td>'+studentPhoto(s)+'</td>'+
      '<td>'+escapeHtml(s.id)+'</td>'+
      '<td><strong>'+escapeHtml(s.name)+'</strong></td>'+
      '<td>'+escapeHtml(s.class_name)+'</td>'+
      '<td>'+escapeHtml(s.section)+'</td>'+
      '<td>'+escapeHtml(s.roll)+'</td>'+
      '<td>'+escapeHtml(s.guardian)+'</td>'+
      '<td>'+escapeHtml(s.phone)+'</td>'+
      '<td class="actions">'+
      '<a class="btn btn-info" href="/students/'+id+'">Profile</a> '+
      '<a class="btn" href="/students/edit/'+id+'">Edit</a></td>'+
      '</tr>';
  }

  // Live student search: server-rendered page remains the fallback.
  const studentSearch=$('#studentLiveSearch');
  const studentBody=$('#studentsTableBody');
  if(studentSearch && studentBody){
    let timer=null;
    async function liveStudents(){
      const status=$('#studentLiveStatus');
      const classSelect=document.querySelector('select[name="class_name"]');
      const q=studentSearch.value.trim();
      const cls=classSelect ? classSelect.value : '';
      if(status) status.textContent='Searchingâ€¦';
      try{
        const data=await fetchJSON('/api/students?search='+encodeURIComponent(q)+'&class_name='+encodeURIComponent(cls));
        studentBody.innerHTML=data.length
          ? data.map(studentRow).join('')
          : '<tr><td colspan="9" class="center">No students found.</td></tr>';
        if(status) status.textContent=data.length+' student'+(data.length===1?'':'s')+' found';
      }catch(e){
        if(status) status.textContent='Live search unavailable';
      }
    }
    studentSearch.addEventListener('input',function(){
      clearTimeout(timer); timer=setTimeout(liveStudents,250);
    });
  }

  // Dynamic dashboard refresh.
  if($('#dashStudents')){
    async function refreshDashboard(){
      try{
        const d=await fetchJSON('/api/dashboard');
        $('#dashStudents').textContent=d.students;
        $('#dashAttendance').textContent=d.attendance_records;
        $('#dashResults').textContent=d.result_records;
        $('#dashUsers').textContent=d.users;
        $('#dashPresent').textContent=d.today.present;
        $('#dashAbsent').textContent=d.today.absent;
        $('#dashLate').textContent=d.today.late;
        $('#dashLeave').textContent=d.today.leave;
      }catch(e){}
    }
    refreshDashboard();
    setInterval(refreshDashboard,30000);
  }

  // Attendance save/update without a full-page reload.
  const attendanceForm=$('#attendanceForm');
  if(attendanceForm){
    const dateInput=$('#attendanceDate');
    const statusLabel=$('#attendanceLiveStatus');
    const saveBtn=$('#saveAttendanceBtn');

    async function loadAttendance(){
      if(!dateInput) return;
      try{
        const d=await fetchJSON('/api/attendance?date='+encodeURIComponent(dateInput.value));
        document.querySelectorAll('#attendanceTable select[name^="status_"]').forEach(sel=>{
          const sid=sel.name.substring(7);
          if(d.statuses[sid]) sel.value=d.statuses[sid];
        });
        if(statusLabel) statusLabel.textContent='Attendance loaded';
      }catch(e){}
    }

    dateInput && dateInput.addEventListener('change',loadAttendance);

    attendanceForm.addEventListener('submit',async function(e){
      e.preventDefault();
      const items=[];
      document.querySelectorAll('#attendanceTable select[name^="status_"]').forEach(sel=>{
        items.push({student_id:sel.name.substring(7),status:sel.value});
      });
      if(!items.length){ showToast('No students to save.'); return; }
      if(saveBtn){saveBtn.disabled=true; saveBtn.textContent='Savingâ€¦';}
      if(statusLabel) statusLabel.textContent='Savingâ€¦';
      try{
        const d=await fetchJSON('/api/attendance?date='+encodeURIComponent(dateInput.value),{
          method:'POST',
          headers:{'Content-Type':'application/json'},
          body:JSON.stringify({items})
        });
        if(d.ok){
          showToast('Attendance saved: '+d.saved);
          if(statusLabel) statusLabel.textContent='Saved '+d.saved+' records';
        }else{
          throw new Error(d.error||'Save failed');
        }
      }catch(e){
        showToast('Could not save attendance');
        if(statusLabel) statusLabel.textContent='Save failed';
      }finally{
        if(saveBtn){saveBtn.disabled=false;saveBtn.textContent='Save Attendance';}
      }
    });
  }
})();
</script>
</body>
</html>
"""


# =========================================================
# LOGIN
# =========================================================

@app.route("/login", methods=["GET", "POST"])
def login():
    error = ""
    if request.method == "POST":
        username = request.form.get("username", "").strip()
        password = request.form.get("password", "")

        conn = get_db()

        user = conn.execute(
            "SELECT * FROM users WHERE username=?", (username,)
        ).fetchone()
        conn.close()

        valid = False
        if user:
            try:
                valid = check_password_hash(user["password"], password)
            except Exception:
                valid = False

        if valid:
            session.clear()
            session["user_id"] = user["id"]
            session["username"] = user["username"]
            session["role"] = user["role"]
            return redirect(url_for("home"))

        error = "Invalid username or password."

    html = f"""
    <div class="login-box">
      <h2 class="center">Student Management Login</h2>
      <p class="error">{esc(error)}</p>
      <form method="post">
        <label>Username</label>
        <input name="username" required>
        <label>Password</label>
        <input type="password" name="password" required>
        <button type="submit">Login</button>
      </form>
    </div>
    """
    return page("Login", html)


@app.route("/mobile_qr")
def mobile_qr():

    ip = request.host.split(":")[0]

    url = f"http://{ip}:5001"

    qr = qrcode.QRCode(
        version=1,
        box_size=10,
        border=5
    )

    qr.add_data(url)
    qr.make(fit=True)

    img = qr.make_image()

    buffer = io.BytesIO()
    img.save(buffer, "PNG")
    buffer.seek(0)

    return send_file(
        buffer,
        mimetype="image/png"
    )


@app.route("/logout")
def logout():
    session.clear()
    return redirect(url_for("login"))


@app.route("/change-password", methods=["GET", "POST"])
@login_required
def change_password():
    error = ""
    if request.method == "POST":
        current = request.form.get("current_password", "")
        new = request.form.get("new_password", "")
        confirm = request.form.get("confirm_password", "")

        conn = get_db()
        user = conn.execute(
            "SELECT * FROM users WHERE id=?", (session["user_id"],)
        ).fetchone()

        if not user or not check_password_hash(user["password"], current):
            error = "Current password is incorrect."
        elif len(new) < 8:
            error = "New password must be at least 8 characters."
        elif new != confirm:
            error = "New password and confirmation do not match."
        else:
            conn.execute(
                "UPDATE users SET password=? WHERE id=?",
                (generate_password_hash(new), session["user_id"])
            )
            conn.commit()
            conn.close()
            flash("Password updated successfully.")
            return redirect(url_for("home"))
        conn.close()

    html = f"""
    <div class="card" style="max-width:420px;margin:40px auto">
      <h2 class="center">Change Password</h2>
      <p class="error">{esc(error)}</p>
      <form method="post">
        <label>Current Password</label>
        <input type="password" name="current_password" required>
        <label>New Password</label>
        <input type="password" name="new_password" required minlength="8">
        <label>Confirm New Password</label>
        <input type="password" name="confirm_password" required minlength="8">
        <button type="submit">Update Password</button>
      </form>
    </div>
    """
    return page("Change Password", html)


# =========================================================
# DASHBOARD
# =========================================================

@app.route("/")
@login_required
def home():
    conn = get_db()
    student_count = conn.execute("SELECT COUNT(*) c FROM students").fetchone()["c"]
    attendance_count = conn.execute("SELECT COUNT(*) c FROM attendance").fetchone()["c"]
    result_count = conn.execute("SELECT COUNT(*) c FROM results").fetchone()["c"]
    user_count = conn.execute("SELECT COUNT(*) c FROM users").fetchone()["c"]
    teacher_count = conn.execute("SELECT COUNT(*) c FROM teachers").fetchone()["c"]
    fee_count = conn.execute("SELECT COUNT(*) c FROM fees").fetchone()["c"]
    exam_count = conn.execute("SELECT COUNT(*) c FROM exams").fetchone()["c"]
    admission_count = conn.execute("SELECT COUNT(*) c FROM admissions").fetchone()["c"]

    today = date.today().isoformat()
    today_stats = conn.execute("""
        SELECT
          SUM(CASE WHEN status='Present' THEN 1 ELSE 0 END) present,
          SUM(CASE WHEN status='Absent' THEN 1 ELSE 0 END) absent,
          SUM(CASE WHEN status='Late' THEN 1 ELSE 0 END) late,
          SUM(CASE WHEN status='Leave' THEN 1 ELSE 0 END) leave_count
        FROM attendance WHERE attendance_date=?
    """, (today,)).fetchone()

    conn.close()

    html = f"""
    <div class="dashboard-hero">
      <div>
        <div class="dashboard-kicker">ENGLISH WINGS ACADEMY</div>
        <h1>Welcome to Shakil AI SMC</h1>
        <p>School Management â€¢ Academy â€¢ Consultancy</p>
      </div>
      <div class="dashboard-user">
        <span>Signed in as</span>
        <strong>{esc(session.get('username'))}</strong>
        <span class="badge">{esc(session.get('role'))}</span>
      </div>
    </div>

    <div class="grid">
      <div class="stat"><h3>Students</h3><h2 id="dashStudents">{student_count}</h2></div>
      <div class="stat"><h3>Teachers</h3><h2>{teacher_count}</h2></div>
      <div class="stat"><h3>Attendance Records</h3><h2 id="dashAttendance">{attendance_count}</h2></div>
      <div class="stat"><h3>Result Records</h3><h2 id="dashResults">{result_count}</h2></div>
      <div class="stat"><h3>Fees</h3><h2>{fee_count}</h2></div>
      <div class="stat"><h3>Exams</h3><h2>{exam_count}</h2></div>
      <div class="stat"><h3>Admissions</h3><h2>{admission_count}</h2></div>
      <div class="stat"><h3>Users</h3><h2 id="dashUsers">{user_count}</h2></div>
    </div>

    <div class="card">
      <h2>Today's Attendance â€” {today}</h2>
      <div class="grid">
        <div class="stat"><h3>Present</h3><h2 id="dashPresent">{today_stats['present'] or 0}</h2></div>
        <div class="stat"><h3>Absent</h3><h2 id="dashAbsent">{today_stats['absent'] or 0}</h2></div>
        <div class="stat"><h3>Late</h3><h2 id="dashLate">{today_stats['late'] or 0}</h2></div>
        <div class="stat"><h3>Leave</h3><h2 id="dashLeave">{today_stats['leave_count'] or 0}</h2></div>
      </div>
    </div>

    <div class="card">
      <h2>Quick Actions</h2>
      <a class="btn btn-success" href="{url_for('add_student')}">+ Add Student</a>
      <a class="btn btn-info" href="{url_for('attendance')}">Attendance</a>
      <a class="btn" href="{url_for('add_result')}">Add Result</a> <a class="btn" href="/ai" target="_blank">ðŸ¤– Shakil AI</a>
    </div>

    <div class="card academy-services-card">
      <div class="academy-services-title">English Wings Academy Services</div>
      <div class="academy-services-buttons">
        <a class="academy-service-btn" href="/portal">Unified Portal</a>
        <a class="academy-service-btn" href="/website/" target="_blank">Academy Website</a>
        <a class="academy-service-btn" href="/analytics" target="_blank">AI Analytics</a>
      </div>
    </div>
    """
    return page("Dashboard", html)


# =========================================================
# DYNAMIC JSON APIs
# =========================================================

@app.route("/api/dashboard")
@login_required
def api_dashboard():
    conn = get_db()
    today = date.today().isoformat()
    stats = {
        "students": conn.execute("SELECT COUNT(*) c FROM students").fetchone()["c"],
        "attendance_records": conn.execute("SELECT COUNT(*) c FROM attendance").fetchone()["c"],
        "result_records": conn.execute("SELECT COUNT(*) c FROM results").fetchone()["c"],
        "users": conn.execute("SELECT COUNT(*) c FROM users").fetchone()["c"],
    }
    a = conn.execute("""
        SELECT
          COALESCE(SUM(CASE WHEN status='Present' THEN 1 ELSE 0 END),0) present,
          COALESCE(SUM(CASE WHEN status='Absent' THEN 1 ELSE 0 END),0) absent,
          COALESCE(SUM(CASE WHEN status='Late' THEN 1 ELSE 0 END),0) late,
          COALESCE(SUM(CASE WHEN status='Leave' THEN 1 ELSE 0 END),0) leave_count
        FROM attendance WHERE attendance_date=?
    """, (today,)).fetchone()
    conn.close()
    stats["today"] = {
        "date": today,
        "present": a["present"] or 0,
        "absent": a["absent"] or 0,
        "late": a["late"] or 0,
        "leave": a["leave_count"] or 0,
    }
    return jsonify(stats)


@app.route("/api/students")
@login_required
def api_students():
    search = request.args.get("search", "").strip()
    class_filter = request.args.get("class_name", "").strip()
    conn = get_db()
    query = "SELECT id,name,class_name,section,roll,guardian,phone,photo FROM students WHERE 1=1"
    params = []
    if search:
        query += " AND (id LIKE ? OR name LIKE ? OR roll LIKE ? OR guardian LIKE ? OR phone LIKE ?)"
        s = f"%{search}%"
        params += [s, s, s, s, s]
    if class_filter:
        query += " AND class_name=?"
        params.append(class_filter)
    query += " ORDER BY class_name, roll, name"
    rows = conn.execute(query, params).fetchall()
    conn.close()
    return jsonify([dict(r) for r in rows])


@app.route("/api/attendance", methods=["GET", "POST"])
@login_required
def api_attendance():
    selected_date = request.args.get("date", date.today().isoformat())
    conn = get_db()
    if request.method == "GET":
        rows = conn.execute(
            "SELECT student_id,status FROM attendance WHERE attendance_date=?",
            (selected_date,)
        ).fetchall()
        conn.close()
        return jsonify({
            "date": selected_date,
            "statuses": {r["student_id"]: r["status"] for r in rows}
        })

    payload = request.get_json(silent=True) or {}
    items = payload.get("items", [])
    if not isinstance(items, list):
        conn.close()
        return jsonify({"ok": False, "error": "Invalid attendance payload."}), 400

    allowed = {"Present", "Absent", "Late", "Leave"}
    saved = 0
    try:
        for item in items:
            student_id = str(item.get("student_id", "")).strip()
            status = str(item.get("status", "Absent")).strip()
            if not student_id or status not in allowed:
                continue
            conn.execute("""
                INSERT INTO attendance(student_id,attendance_date,status)
                VALUES (?,?,?)
                ON CONFLICT(student_id,attendance_date)
                DO UPDATE SET status=excluded.status
            """, (student_id, selected_date, status))
            saved += 1
        conn.commit()
    except Exception as exc:
        conn.rollback()
        conn.close()
        return jsonify({"ok": False, "error": str(exc)}), 500
    conn.close()
    return jsonify({"ok": True, "date": selected_date, "saved": saved})


# =========================================================
# PHOTO UPLOAD HELPERS
# =========================================================

def allowed_photo(filename):
    return bool(filename and "." in filename and filename.rsplit(".", 1)[1].lower() in ALLOWED_PHOTO_EXTENSIONS)


def save_student_photo(file_storage, student_id):
    if not file_storage or not file_storage.filename:
        return None
    if not allowed_photo(file_storage.filename):
        raise ValueError("Photo must be JPG, JPEG, PNG or WEBP.")
    ext = file_storage.filename.rsplit(".", 1)[1].lower()
    filename = f"{secure_filename(student_id)}_{datetime.now().strftime('%Y%m%d%H%M%S%f')}.{ext}"
    file_storage.save(os.path.join(UPLOAD_DIR, filename))
    return filename


def delete_student_photo(filename):
    if not filename:
        return
    path = os.path.join(UPLOAD_DIR, os.path.basename(filename))
    if os.path.isfile(path):
        try:
            os.remove(path)
        except OSError:
            pass


@app.route("/student-photo/<path:filename>")
def student_photo(filename):
    return send_from_directory(UPLOAD_DIR, os.path.basename(filename))


# =========================================================
# STUDENTS
# =========================================================

@app.route("/students")
@login_required
def students():
    search = request.args.get("search", "").strip()
    class_filter = request.args.get("class_name", "").strip()

    conn = get_db()
    classes = conn.execute(
        "SELECT DISTINCT class_name FROM students ORDER BY class_name"
    ).fetchall()

    query = "SELECT * FROM students WHERE 1=1"
    params = []

    if search:
        query += " AND (id LIKE ? OR name LIKE ? OR roll LIKE ? OR guardian LIKE ? OR phone LIKE ?)"
        s = f"%{search}%"
        params += [s, s, s, s, s]

    if class_filter:
        query += " AND class_name=?"
        params.append(class_filter)

    query += " ORDER BY class_name, roll, name"
    rows = conn.execute(query, params).fetchall()
    conn.close()

    trs = ""
    for s in rows:
        trs += f"""
        <tr>
          <td>{('<img class="student-thumb" src="'+url_for('student_photo', filename=s['photo'])+'">') if s['photo'] else '<div class="student-thumb avatar-mini">'+esc(s['name'][:1].upper())+'</div>'}</td>
          <td>{esc(s['id'])}</td>
          <td><strong>{esc(s['name'])}</strong></td>
          <td>{esc(s['class_name'])}</td>
          <td>{esc(s['section'])}</td>
          <td>{esc(s['roll'])}</td>
          <td>{esc(s['guardian'])}</td>
          <td>{esc(s['phone'])}</td>
          <td class="actions">
            <a class="btn btn-info" href="{url_for('student_profile', student_id=s['id'])}">Profile</a>
            <a class="btn" href="{url_for('edit_student', student_id=s['id'])}">Edit</a>
            <a class="btn btn-danger" href="{url_for('delete_student', student_id=s['id'])}"
               onclick="return confirm('Delete this student and related records?')">Delete</a>
          </td>
        </tr>
        """

    options = "".join(
        f"<option value='{esc(c['class_name'])}' {'selected' if c['class_name']==class_filter else ''}>{esc(c['class_name'])}</option>"
        for c in classes
    )

    html = f"""
    <h1>Students</h1>
    <div class="card">
      <strong>Student Records:</strong> {len(rows)}
      <span class="badge">Showing current filter results</span>
    </div>
    <div class="card toolbar">
      <form method="get">
        <input id="studentLiveSearch" class="search-input" name="search" value="{esc(search)}"
               placeholder="Search ID, name, roll, guardian or phone" autocomplete="off">
      </form>
      <form method="get">
        <select name="class_name" onchange="this.form.submit()">
          <option value="">All Classes</option>{options}
        </select>
      </form>
      <a class="btn btn-success" href="{url_for('add_student')}">+ Add Student</a>
    </div>
    <div class="card">
      <div class="table-wrap"><table id="studentsTable">
        <thead><tr><th>Photo</th><th>ID</th><th>Name</th><th>Class</th><th>Section</th><th>Roll</th>
            <th>Guardian</th><th>Phone</th><th>Actions</th></tr></thead>
        <tbody id="studentsTableBody">{trs if trs else '<tr><td colspan="9" class="center">No students found.</td></tr>'}</tbody>
      </table></div>
      <div id="studentLiveStatus" class="live-status">Live search ready</div>
    </div>
    """
    return page("Students", html)


@app.route("/students/add", methods=["GET", "POST"])
@login_required
def add_student():
    if request.method == "POST":
        data = {
            "id": request.form.get("id", "").strip(),
            "name": request.form.get("name", "").strip(),
            "class_name": request.form.get("class_name", "").strip(),
            "section": request.form.get("section", "").strip(),
            "roll": request.form.get("roll", "").strip(),
            "guardian": request.form.get("guardian", "").strip(),
            "phone": request.form.get("phone", "").strip(),
        }

        if not data["id"] or not data["name"] or not data["class_name"]:
            flash("Student ID, name and class are required.")
            return redirect(url_for("add_student"))

        photo_filename = None
        try:
            photo_filename = save_student_photo(request.files.get("photo"), data["id"])
        except ValueError as e:
            flash(str(e))
            return redirect(url_for("add_student"))

        conn = get_db()
        try:
            conn.execute("""
                INSERT INTO students
                (id,name,class_name,section,roll,guardian,phone,photo)
                VALUES (?,?,?,?,?,?,?,?)
            """, tuple(data.values()) + (photo_filename,))
            conn.commit()
            flash("Student added successfully.")
            target = data["id"]
        except sqlite3.IntegrityError:
            if photo_filename:
                delete_student_photo(photo_filename)
            flash("Student ID already exists.")
            target = None
        finally:
            conn.close()

        return redirect(url_for("student_profile", student_id=target)) if target else redirect(url_for("students"))

    html = """
    <h1>Add Student</h1>
    <div class="card">
    <form method="post" enctype="multipart/form-data">
      <label>Student Photo</label><input type="file" name="photo" accept=".jpg,.jpeg,.png,.webp">
      <small class="muted">JPG, JPEG, PNG or WEBP. Recommended: clear passport-size photo.</small>
      <label>Student ID *</label><input name="id" required>
      <label>Name *</label><input name="name" required>
      <label>Class *</label><input name="class_name" required>
      <label>Section</label><input name="section">
      <label>Roll</label><input name="roll">
      <label>Guardian</label><input name="guardian">
      <label>Phone</label><input name="phone">
      <button class="btn-success" type="submit">Save Student</button>
    </form>
    </div>
    """
    return page("Add Student", html)


@app.route("/students/edit/<student_id>", methods=["GET", "POST"])
@login_required
def edit_student(student_id):
    conn = get_db()
    student = conn.execute("SELECT * FROM students WHERE id=?", (student_id,)).fetchone()

    if not student:
        conn.close()
        return "Student not found.", 404

    if request.method == "POST":
        new_photo = None
        try:
            new_photo = save_student_photo(request.files.get("photo"), student_id)
        except ValueError as e:
            conn.close()
            flash(str(e))
            return redirect(url_for("edit_student", student_id=student_id))

        old_photo = student["photo"]
        values = (
            request.form.get("name", "").strip(),
            request.form.get("class_name", "").strip(),
            request.form.get("section", "").strip(),
            request.form.get("roll", "").strip(),
            request.form.get("guardian", "").strip(),
            request.form.get("phone", "").strip(),
            new_photo if new_photo else old_photo,
            student_id
        )
        conn.execute("""
            UPDATE students SET name=?, class_name=?, section=?, roll=?, guardian=?, phone=?, photo=?
            WHERE id=?
        """, values)
        conn.commit()
        conn.close()
        if new_photo and old_photo:
            delete_student_photo(old_photo)
        flash("Student updated successfully.")
        return redirect(url_for("student_profile", student_id=student_id))

    conn.close()
    html = f"""
    <h1>Edit Student</h1>
    <div class="card">
    <form method="post" enctype="multipart/form-data">
      <label>Student Photo</label>
      {('<img class="student-photo-preview" src="'+url_for('student_photo', filename=student['photo'])+'">') if student['photo'] else '<div class="muted">No photo uploaded.</div>'}
      <input type="file" name="photo" accept=".jpg,.jpeg,.png,.webp">
      <small class="muted">Choose a new photo only if you want to replace the current one.</small>
      <label>Student ID</label><input value="{esc(student['id'])}" disabled>
      <label>Name</label><input name="name" value="{esc(student['name'])}" required>
      <label>Class</label><input name="class_name" value="{esc(student['class_name'])}" required>
      <label>Section</label><input name="section" value="{esc(student['section'])}">
      <label>Roll</label><input name="roll" value="{esc(student['roll'])}">
      <label>Guardian</label><input name="guardian" value="{esc(student['guardian'])}">
      <label>Phone</label><input name="phone" value="{esc(student['phone'])}">
      <button type="submit">Update Student</button>
    </form>
    </div>
    """
    return page("Edit Student", html)


@app.route("/students/delete/<student_id>")
@login_required
def delete_student(student_id):
    conn = get_db()
    conn.execute("DELETE FROM attendance WHERE student_id=?", (student_id,))
    conn.execute("DELETE FROM results WHERE student_id=?", (student_id,))
    student = conn.execute("SELECT photo FROM students WHERE id=?", (student_id,)).fetchone()
    old_photo = student["photo"] if student else None
    conn.execute("DELETE FROM students WHERE id=?", (student_id,))
    conn.commit()
    conn.close()
    delete_student_photo(old_photo)
    flash("Student and related records deleted.")
    return redirect(url_for("students"))


# =========================================================
# STUDENT PROFILE
# =========================================================

@app.route("/students/<student_id>")
@login_required
def student_profile(student_id):
    conn = get_db()
    student = conn.execute("SELECT * FROM students WHERE id=?", (student_id,)).fetchone()
    if not student:
        conn.close()
        return "Student not found.", 404

    attendance_rows = conn.execute("""
        SELECT attendance_date, status
        FROM attendance WHERE student_id=?
        ORDER BY attendance_date DESC LIMIT 30
    """, (student_id,)).fetchall()

    att = conn.execute("""
        SELECT
          SUM(CASE WHEN status='Present' THEN 1 ELSE 0 END) present,
          SUM(CASE WHEN status='Absent' THEN 1 ELSE 0 END) absent,
          SUM(CASE WHEN status='Late' THEN 1 ELSE 0 END) late,
          SUM(CASE WHEN status='Leave' THEN 1 ELSE 0 END) leave_count
        FROM attendance WHERE student_id=?
    """, (student_id,)).fetchone()

    result_rows = conn.execute("""
        SELECT * FROM results WHERE student_id=?
        ORDER BY exam_name, subject
    """, (student_id,)).fetchall()

    conn.close()

    present = att["present"] or 0
    absent = att["absent"] or 0
    late = att["late"] or 0
    leave_count = att["leave_count"] or 0
    total_att = present + absent + late + leave_count
    attendance_pct = (present / total_att * 100) if total_att else 0

    att_html = "".join(
        f"<tr><td>{esc(a['attendance_date'])}</td><td>{esc(a['status'])}</td></tr>"
        for a in attendance_rows
    ) or '<tr><td colspan="2">No attendance records.</td></tr>'

    result_html = ""
    for r in result_rows:
        pct = (r["marks"] / r["total_marks"] * 100) if r["total_marks"] else 0
        result_html += f"""
        <tr>
          <td>{esc(r['exam_name'])}</td><td>{esc(r['subject'])}</td>
          <td>{r['marks']:.2f}</td><td>{r['total_marks']:.2f}</td>
          <td>{pct:.2f}%</td><td>{grade_from_percentage(pct)}</td>
        </tr>"""
    if not result_html:
        result_html = '<tr><td colspan="6">No result records.</td></tr>'

    # Profile intelligence summary
    result_count = len(result_rows)
    valid_results = [r for r in result_rows if r["total_marks"]]
    avg_result_pct = (
        sum((r["marks"] / r["total_marks"] * 100) for r in valid_results)
        / len(valid_results)
    ) if valid_results else 0

    pass_count = sum(
        1 for r in valid_results
        if (r["marks"] / r["total_marks"] * 100) >= 40
    )
    fail_count = len(valid_results) - pass_count

    alerts = []

    if total_att == 0:
        alerts.append("No attendance records available")
    elif attendance_pct < 75:
        alerts.append("Attendance is below 75%")

    if result_count == 0:
        alerts.append("No result records available")
    elif avg_result_pct < 50:
        alerts.append("Average result is below 50%")

    alert_html = "".join(
        f"<li>{esc(a)}</li>" for a in alerts
    ) if alerts else "<li>No major alerts detected</li>"

    initial = esc(student["name"][:1].upper()) if student["name"] else "S"

    html = f"""
    <div class="toolbar no-print">
      <a class="btn" href="{url_for('students')}">Ã¢â€ Â Students</a>
      <a class="btn" href="{url_for('edit_student', student_id=student_id)}">Edit</a>
      <a class="btn btn-info" href="{url_for('report_card', student_id=student_id)}">Report Card</a>
    </div>

    <div class="card">
      <div class="profile">
        {('<img class="student-photo-profile" src="'+url_for('student_photo', filename=student['photo'])+'">') if student['photo'] else '<div class="avatar">'+initial+'</div>'}
        <div>
          <h1>{esc(student['name'])}</h1>
          <p class="muted">Student ID: <strong>{esc(student['id'])}</strong></p>
          <p>Class: <strong>{esc(student['class_name'])}</strong>
             &nbsp; Section: <strong>{esc(student['section'])}</strong>
             &nbsp; Roll: <strong>{esc(student['roll'])}</strong></p>
          <p>Guardian: <strong>{esc(student['guardian'])}</strong>
             &nbsp; Phone: <strong>{esc(student['phone'])}</strong></p>
        </div>
      </div>
    </div>

    <div class="grid">
      <div class="stat"><h3>Present</h3><h2>{present}</h2></div>
      <div class="stat"><h3>Absent</h3><h2>{absent}</h2></div>
      <div class="stat"><h3>Late</h3><h2>{late}</h2></div>
      <div class="stat"><h3>Attendance</h3><h2>{attendance_pct:.1f}%</h2></div>
      <div class="stat"><h3>Total Results</h3><h2>{result_count}</h2></div>
      <div class="stat"><h3>Average Result</h3><h2>{avg_result_pct:.1f}%</h2></div>
      <div class="stat"><h3>Passed</h3><h2>{pass_count}</h2></div>
      <div class="stat"><h3>Failed</h3><h2>{fail_count}</h2></div>
    </div>

    <div class="card">
      <h2>Student Overview &amp; Alerts</h2>
      <ul>{alert_html}</ul>
    </div>

    <div class="card">
      <h2>Recent Attendance</h2>
      <table><tr><th>Date</th><th>Status</th></tr>{att_html}</table>
    </div>

    <div class="card">
      <h2>Results</h2>
      <table>
        <tr><th>Exam</th><th>Subject</th><th>Marks</th><th>Total</th><th>%</th><th>Grade</th><th>Actions</th></tr>
        {result_html}
      </table>
    </div>
    """
    return page("Student Profile", html)


# =========================================================
# ATTENDANCE
# =========================================================

@app.route("/attendance", methods=["GET", "POST"])
@login_required
def attendance():
    selected_date = request.form.get(
        "attendance_date",
        request.args.get("date", date.today().isoformat())
    )

    conn = get_db()
    students_list = conn.execute(
        "SELECT * FROM students ORDER BY class_name, roll, name"
    ).fetchall()

    if request.method == "POST":
        for student in students_list:
            status = request.form.get(f"status_{student['id']}", "Absent")
            conn.execute("""
                INSERT INTO attendance(student_id,attendance_date,status)
                VALUES (?,?,?)
                ON CONFLICT(student_id,attendance_date)
                DO UPDATE SET status=excluded.status
            """, (student["id"], selected_date, status))
        conn.commit()
        conn.close()
        flash(f"Attendance saved for {selected_date}.")
        return redirect(url_for("attendance", date=selected_date))

    existing = conn.execute(
        "SELECT student_id,status FROM attendance WHERE attendance_date=?",
        (selected_date,)
    ).fetchall()
    existing_status = {r["student_id"]: r["status"] for r in existing}
    conn.close()

    rows = ""
    for s in students_list:
        status = existing_status.get(s["id"], "Present")
        options = "".join(
            f"<option value='{x}' {'selected' if x==status else ''}>{x}</option>"
            for x in ["Present", "Absent", "Late", "Leave"]
        )
        rows += f"""
        <tr><td>{esc(s['id'])}</td><td>{esc(s['name'])}</td>
        <td>{esc(s['class_name'])}</td><td>{esc(s['roll'])}</td>
        <td><select name="status_{esc(s['id'])}">{options}</select></td></tr>
        """

    # Attendance intelligence for selected date
    present_count = sum(1 for x in existing_status.values() if x == "Present")
    absent_count = sum(1 for x in existing_status.values() if x == "Absent")
    late_count = sum(1 for x in existing_status.values() if x == "Late")
    leave_count = sum(1 for x in existing_status.values() if x == "Leave")
    total_students = len(students_list)
    marked_count = len(existing_status)
    completion_pct = (marked_count / total_students * 100) if total_students else 0

    html = f"""
    <h1>Daily Attendance</h1>

    <div class="grid">
      <div class="stat"><h3>Present</h3><h2>{present_count}</h2></div>
      <div class="stat"><h3>Absent</h3><h2>{absent_count}</h2></div>
      <div class="stat"><h3>Late</h3><h2>{late_count}</h2></div>
      <div class="stat"><h3>Leave</h3><h2>{leave_count}</h2></div>
    </div>

    <div class="card">
      <strong>Attendance Completion:</strong>
      {marked_count}/{total_students} students marked
      ({completion_pct:.1f}%)
    </div>
    <div class="card">
      <form id="attendanceForm" method="post">
        <label>Date</label>
        <input id="attendanceDate" type="date" name="attendance_date" value="{selected_date}" required>
        <div class="table-wrap"><table id="attendanceTable">
          <thead><tr><th>ID</th><th>Name</th><th>Class</th><th>Roll</th><th>Status</th></tr></thead>
          <tbody>{rows if rows else '<tr><td colspan="5">No students.</td></tr>'}</tbody>
        </table></div><br>
        <button id="saveAttendanceBtn" class="btn-success" type="submit">Save Attendance</button>
        <span id="attendanceLiveStatus" class="live-status"></span>
      </form>
    </div>
    """
    return page("Attendance", html)


# =========================================================
# RESULTS
# =========================================================

@app.route("/results")
@login_required
def results():
    exam_filter = request.args.get("exam", "").strip()
    conn = get_db()
    exams = conn.execute(
        "SELECT DISTINCT exam_name FROM results ORDER BY exam_name"
    ).fetchall()

    query = """
        SELECT results.*, students.name student_name
        FROM results LEFT JOIN students ON results.student_id=students.id
        WHERE 1=1
    """
    params = []
    if exam_filter:
        query += " AND results.exam_name=?"
        params.append(exam_filter)
    query += " ORDER BY results.exam_name, students.name, results.subject"

    rows = conn.execute(query, params).fetchall()
    conn.close()

    trs = ""
    for r in rows:
        pct = (r["marks"] / r["total_marks"] * 100) if r["total_marks"] else 0
        trs += f"""
        <tr><td>{esc(r['student_id'])}</td><td>{esc(r['student_name'])}</td>
        <td>{esc(r['exam_name'])}</td><td>{esc(r['subject'])}</td>
        <td>{r['marks']:.2f}</td><td>{r['total_marks']:.2f}</td>
        <td>{pct:.2f}%</td><td>{grade_from_percentage(pct)}</td>
        <td><a class="btn" href="{url_for('edit_result', result_id=r['id'])}">Edit</a> <a class="btn btn-danger" href="{url_for('delete_result', result_id=r['id'])}" onclick="return confirm('Delete this result?')">Delete</a></td></tr>
        """

    options = "".join(
        f"<option value='{esc(e['exam_name'])}' {'selected' if e['exam_name']==exam_filter else ''}>{esc(e['exam_name'])}</option>"
        for e in exams
    )

    # Results intelligence summary
    total_results = len(rows)

    valid_results = [
        r for r in rows
        if r["total_marks"] and r["marks"] is not None
    ]

    percentages = [
        (r["marks"] / r["total_marks"] * 100)
        for r in valid_results
    ]

    average_percentage = (
        sum(percentages) / len(percentages)
        if percentages else 0
    )

    pass_count = sum(
        1 for pct in percentages if pct >= 40
    )

    fail_count = len(percentages) - pass_count

    pass_rate = (
        pass_count / len(percentages) * 100
        if percentages else 0
    )

    html = f"""
    <h1>Results</h1>

    <div class="grid">
      <div class="stat"><h3>Total Results</h3><h2>{total_results}</h2></div>
      <div class="stat"><h3>Average</h3><h2>{average_percentage:.1f}%</h2></div>
      <div class="stat"><h3>Passed</h3><h2>{pass_count}</h2></div>
      <div class="stat"><h3>Failed</h3><h2>{fail_count}</h2></div>
      <div class="stat"><h3>Pass Rate</h3><h2>{pass_rate:.1f}%</h2></div>
    </div>

    <div class="card">
      <strong>Performance Summary:</strong>
      {pass_count} passed, {fail_count} failed
      from {len(percentages)} graded results.
    </div>
    <div class="card toolbar">
      <form method="get">
        <select name="exam" onchange="this.form.submit()">
          <option value="">All Exams</option>{options}
        </select>
      </form>
      <a class="btn btn-success" href="{url_for('add_result')}">+ Add Result</a>
    </div>
    <div class="card">
      <table>
        <tr><th>Student ID</th><th>Name</th><th>Exam</th><th>Subject</th>
        <th>Marks</th><th>Total</th><th>%</th><th>Grade</th></tr>
        {trs if trs else '<tr><td colspan="9">No results found.</td></tr>'}
      </table>
    </div>
    """
    return page("Results", html)


@app.route("/results/add", methods=["GET", "POST"])
@login_required
def add_result():
    conn = get_db()
    students_list = conn.execute(
        "SELECT * FROM students ORDER BY name"
    ).fetchall()

    if request.method == "POST":
        student_id = request.form.get("student_id", "")
        exam_name = request.form.get("exam_name", "").strip()
        subject = request.form.get("subject", "").strip()

        try:
            marks = float(request.form.get("marks", 0))
            total_marks = float(request.form.get("total_marks", 100))
        except ValueError:
            conn.close()
            flash("Marks must be numbers.")
            return redirect(url_for("add_result"))

        if total_marks <= 0 or marks < 0 or marks > total_marks:
            conn.close()
            flash("Marks must be between 0 and Total Marks.")
            return redirect(url_for("add_result"))

        conn.execute("""
            INSERT INTO results(student_id,exam_name,subject,marks,total_marks)
            VALUES (?,?,?,?,?)
        """, (student_id, exam_name, subject, marks, total_marks))
        conn.commit()
        conn.close()
        flash("Result added successfully.")
        return redirect(url_for("student_profile", student_id=student_id))

    options = "".join(
        f"<option value='{esc(s['id'])}'>{esc(s['id'])} - {esc(s['name'])}</option>"
        for s in students_list
    )
    conn.close()

    html = f"""
    <h1>Add Result</h1>
    <div class="card">
    <form method="post">
      <label>Student</label>
      <select name="student_id" required><option value="">Select Student</option>{options}</select>
      <label>Exam Name</label><input name="exam_name" placeholder="Half-Yearly" required>
      <label>Subject</label><input name="subject" placeholder="English" required>
      <label>Marks</label><input type="number" step="0.01" min="0" name="marks" required>
      <label>Total Marks</label><input type="number" step="0.01" min="1" name="total_marks" value="100" required>
      <button class="btn-success" type="submit">Save Result</button>
    </form>
    </div>
    """
    return page("Add Result", html)


@app.route("/results/edit/<int:result_id>", methods=["GET", "POST"])
@login_required
def edit_result(result_id):
    conn=get_db(); r=conn.execute("SELECT * FROM results WHERE id=?",(result_id,)).fetchone(); students_list=conn.execute("SELECT * FROM students ORDER BY name").fetchall()
    if not r: conn.close(); return "Result not found.",404
    if request.method=="POST":
        try: marks=float(request.form.get('marks') or 0); total=float(request.form.get('total_marks') or 100)
        except ValueError: conn.close(); flash("Marks and total marks must be numbers."); return redirect(url_for('edit_result',result_id=result_id))
        if total<=0 or marks<0 or marks>total: conn.close(); flash("Marks must be between 0 and Total Marks."); return redirect(url_for('edit_result',result_id=result_id))
        conn.execute("UPDATE results SET student_id=?,exam_name=?,subject=?,marks=?,total_marks=? WHERE id=?",(request.form.get('student_id'),request.form.get('exam_name'),request.form.get('subject'),marks,total,result_id)); conn.commit(); conn.close(); flash("Result updated."); return redirect(url_for('results'))
    opts=''.join(f"<option value='{esc(x['id'])}' {'selected' if x['id']==r['student_id'] else ''}>{esc(x['id'])} - {esc(x['name'])}</option>" for x in students_list)
    html=f"""<h1>Edit Result</h1><div class="card"><form method="post"><label>Student</label><select name="student_id" required>{opts}</select><label>Exam Name</label><input name="exam_name" value="{esc(r['exam_name'])}" required><label>Subject</label><input name="subject" value="{esc(r['subject'])}" required><label>Marks</label><input name="marks" type="number" step="0.01" value="{r['marks']}" required><label>Total Marks</label><input name="total_marks" type="number" step="0.01" value="{r['total_marks']}" required><button class="btn-success">Update Result</button></form></div>"""
    conn.close(); return page("Edit Result",html)

@app.route("/results/delete/<int:result_id>")
@admin_required
def delete_result(result_id):
    conn=get_db(); conn.execute("DELETE FROM results WHERE id=?",(result_id,)); conn.commit(); conn.close(); flash("Result deleted."); return redirect(url_for('results'))


# =========================================================
# REPORT CARD
# =========================================================

@app.route("/students/<student_id>/report-card")
@login_required
def report_card(student_id):
    exam_name = request.args.get("exam", "").strip()

    conn = get_db()
    student = conn.execute(
        "SELECT * FROM students WHERE id=?", (student_id,)
    ).fetchone()
    if not student:
        conn.close()
        return "Student not found.", 404

    exams = conn.execute(
        "SELECT DISTINCT exam_name FROM results WHERE student_id=? ORDER BY exam_name",
        (student_id,)
    ).fetchall()

    if not exam_name and exams:
        exam_name = exams[-1]["exam_name"]

    rows = conn.execute("""
        SELECT subject, marks, total_marks
        FROM results
        WHERE student_id=? AND exam_name=?
        ORDER BY subject
    """, (student_id, exam_name)).fetchall()

    conn.close()

    trs = ""
    total = possible = 0
    for r in rows:
        pct = (r["marks"] / r["total_marks"] * 100) if r["total_marks"] else 0
        total += r["marks"]
        possible += r["total_marks"]
        trs += f"""
        <tr><td>{esc(r['subject'])}</td><td>{r['marks']:.2f}</td>
        <td>{r['total_marks']:.2f}</td><td>{pct:.2f}%</td>
        <td>{grade_from_percentage(pct)}</td><td>{grade_point(pct):.2f}</td></tr>
        """

    overall = (total / possible * 100) if possible else 0
    overall_grade = grade_from_percentage(overall)
    overall_gp = grade_point(overall)

    exam_options = "".join(
        f"<option value='{esc(e['exam_name'])}' {'selected' if e['exam_name']==exam_name else ''}>{esc(e['exam_name'])}</option>"
        for e in exams
    )

    html = f"""
    <div class="no-print toolbar">
      <a class="btn" href="{url_for('student_profile', student_id=student_id)}">Ã¢â€ Â Profile</a>
      <form method="get" action="{url_for('report_card', student_id=student_id)}">
        <select name="exam" onchange="this.form.submit()">
          {exam_options or '<option>No exam available</option>'}
        </select>
      </form>
      <button onclick="window.print()">Print Report Card</button>
    </div>

    <div class="report-card">
      <div class="report-head">
        <h1>STUDENT REPORT CARD</h1>
        <h2>Shakil AI Student Management System</h2>
        <p>{esc(exam_name) if exam_name else 'No Examination Selected'}</p>
      </div>

      <div class="report-meta">
        <div><strong>Student ID:</strong> {esc(student['id'])}</div>
        <div><strong>Name:</strong> {esc(student['name'])}</div>
        <div><strong>Class:</strong> {esc(student['class_name'])}</div>
        <div><strong>Section:</strong> {esc(student['section'])}</div>
        <div><strong>Roll:</strong> {esc(student['roll'])}</div>
        <div><strong>Guardian:</strong> {esc(student['guardian'])}</div>
      </div>

      <table>
        <tr><th>Subject</th><th>Marks</th><th>Total</th><th>Percentage</th><th>Grade</th><th>GP</th></tr>
        {trs if trs else '<tr><td colspan="6" class="center">No results for this exam.</td></tr>'}
      </table>

      <div class="summary">
        <div><strong>Total</strong><br>{total:.2f} / {possible:.2f}</div>
        <div><strong>Percentage</strong><br>{overall:.2f}%</div>
        <div><strong>Grade</strong><br>{overall_grade}</div>
        <div><strong>Grade Point</strong><br>{overall_gp:.2f}</div>
      </div>

      <br><br>
      <div style="display:flex;justify-content:space-between">
        <span>Class Teacher</span><span>Head Teacher / Principal</span>
      </div>
    </div>
    """
    return page("Report Card", html, ".report-card{box-shadow:none!important}")


# =========================================================
# PERFORMANCE ANALYTICS
# =========================================================

@app.route("/performance")
@login_required
def performance():
    conn = get_db()
    rows = conn.execute("""
        SELECT students.id, students.name,
               COUNT(results.id) subjects,
               COALESCE(SUM(results.marks),0) total_marks,
               COALESCE(SUM(results.total_marks),0) total_possible
        FROM students
        LEFT JOIN results ON students.id=results.student_id
        GROUP BY students.id
        ORDER BY students.class_name, students.roll, students.name
    """).fetchall()
    conn.close()

    trs = ""
    for r in rows:
        pct = (r["total_marks"] / r["total_possible"] * 100) if r["total_possible"] else 0
        cls = "good" if pct >= 50 else ("bad" if r["subjects"] else "")
        trs += f"""
        <tr><td>{esc(r['id'])}</td><td>{esc(r['name'])}</td>
        <td>{r['subjects']}</td><td>{r['total_marks']:.2f}</td>
        <td>{r['total_possible']:.2f}</td><td class="{cls}">{pct:.2f}%</td>
        <td>{grade_from_percentage(pct) if r['subjects'] else '-'}</td></tr>
        """

    html = f"""
    <h1>Performance Analytics</h1>
    <div class="card">
      <table>
        <tr><th>ID</th><th>Name</th><th>Subjects</th><th>Total Marks</th>
        <th>Total Possible</th><th>Percentage</th><th>Grade</th></tr>
        {trs if trs else '<tr><td colspan="7">No students.</td></tr>'}
      </table>
    </div>
    """
    return page("Performance", html)


# =========================================================
# ATTENDANCE ANALYTICS
# =========================================================

@app.route("/attendance-analytics")
@login_required
def attendance_analytics():
    conn = get_db()
    rows = conn.execute("""
        SELECT students.id, students.name,
          SUM(CASE WHEN attendance.status='Present' THEN 1 ELSE 0 END) present,
          SUM(CASE WHEN attendance.status='Absent' THEN 1 ELSE 0 END) absent,
          SUM(CASE WHEN attendance.status='Late' THEN 1 ELSE 0 END) late,
          SUM(CASE WHEN attendance.status='Leave' THEN 1 ELSE 0 END) leave_count
        FROM students
        LEFT JOIN attendance ON students.id=attendance.student_id
        GROUP BY students.id
        ORDER BY students.class_name, students.roll, students.name
    """).fetchall()
    conn.close()

    trs = ""
    for r in rows:
        present = r["present"] or 0
        absent = r["absent"] or 0
        late = r["late"] or 0
        leave_count = r["leave_count"] or 0
        total = present + absent + late + leave_count
        pct = present / total * 100 if total else 0
        cls = "good" if pct >= 80 else ("bad" if total and pct < 60 else "")
        trs += f"""
        <tr><td>{esc(r['id'])}</td><td>{esc(r['name'])}</td>
        <td>{present}</td><td>{absent}</td><td>{late}</td><td>{leave_count}</td>
        <td class="{cls}">{pct:.2f}%</td></tr>
        """

    html = f"""
    <h1>Attendance Analytics</h1>
    <div class="card">
      <table>
        <tr><th>ID</th><th>Name</th><th>Present</th><th>Absent</th>
        <th>Late</th><th>Leave</th><th>Attendance %</th></tr>
        {trs if trs else '<tr><td colspan="7">No records.</td></tr>'}
      </table>
    </div>
    """
    return page("Attendance Analytics", html)


# =========================================================
# USER MANAGEMENT
# =========================================================

@app.route("/users")
@admin_required
def users():
    conn = get_db()
    rows = conn.execute("SELECT * FROM users ORDER BY username").fetchall()
    conn.close()

    trs = ""
    for u in rows:
        action = f'<a class="btn" href="{url_for("edit_user", user_id=u["id"])}">Edit</a>'
        if u["username"] != "admin":
            action += f""" <a class="btn btn-danger" href="{url_for('delete_user', user_id=u['id'])}" onclick="return confirm('Delete this user?')">Delete</a>"""
        trs += f"<tr><td>{u['id']}</td><td>{esc(u['username'])}</td><td>{esc(u['role'])}</td><td>{action}</td></tr>"

    html = f"""
    <h1>User Management</h1>
    <div class="card"><a class="btn btn-success" href="{url_for('add_user')}">+ Add User</a></div>
    <div class="card">
      <table><tr><th>ID</th><th>Username</th><th>Role</th><th>Action</th></tr>{trs}</table>
    </div>
    """
    return page("Users", html)


@app.route("/users/add", methods=["GET", "POST"])
@admin_required
def add_user():
    if request.method == "POST":
        username = request.form.get("username", "").strip()
        password = request.form.get("password", "")
        role = request.form.get("role", "Teacher")

        if not username or not password or role not in ROLES:
            flash("Username, password and valid role are required.")
            return redirect(url_for("add_user"))

        conn = get_db()
        try:
            conn.execute(
                "INSERT INTO users(username,password,role) VALUES (?,?,?)",
                (username, generate_password_hash(password), role)
            )
            conn.commit()
            flash("User created successfully.")
        except sqlite3.IntegrityError:
            flash("Username already exists.")
        finally:
            conn.close()
        return redirect(url_for("users"))

    options = "".join(f"<option>{r}</option>" for r in ROLES)
    html = f"""
    <h1>Add User</h1>
    <div class="card">
    <form method="post">
      <label>Username</label><input name="username" required>
      <label>Password</label><input type="password" name="password" required>
      <label>Role</label><select name="role">{options}</select>
      <button class="btn-success" type="submit">Create User</button>
    </form>
    </div>
    """
    return page("Add User", html)


@app.route("/users/edit/<int:user_id>", methods=["GET", "POST"])
@admin_required
def edit_user(user_id):
    conn=get_db(); u=conn.execute("SELECT * FROM users WHERE id=?",(user_id,)).fetchone()
    if not u: conn.close(); return "User not found.",404
    if request.method=="POST":
        username=request.form.get("username","").strip(); role=request.form.get("role","Teacher"); password=request.form.get("password","")
        if not username or role not in ROLES: conn.close(); flash("Username and valid role are required."); return redirect(url_for("edit_user",user_id=user_id))
        try:
            if password: conn.execute("UPDATE users SET username=?,password=?,role=? WHERE id=?",(username,generate_password_hash(password),role,user_id))
            else: conn.execute("UPDATE users SET username=?,role=? WHERE id=?",(username,role,user_id))
            conn.commit(); flash("User updated successfully.")
        except sqlite3.IntegrityError: flash("Username already exists.")
        finally: conn.close()
        return redirect(url_for("users"))
    opts="".join(f"<option {'selected' if r==u['role'] else ''}>{r}</option>" for r in ROLES)
    html=f"""<h1>Edit User</h1><div class="card"><form method="post"><label>Username</label><input name="username" value="{esc(u['username'])}" required><label>New Password <span class="muted">(leave blank to keep current)</span></label><input type="password" name="password"><label>Role</label><select name="role">{opts}</select><button class="btn-success">Update User</button></form></div>"""
    conn.close(); return page("Edit User",html)

@app.route("/users/delete/<int:user_id>")
@admin_required
def delete_user(user_id):
    conn = get_db()
    user = conn.execute("SELECT username FROM users WHERE id=?", (user_id,)).fetchone()
    if user and user["username"] != "admin":
        conn.execute("DELETE FROM users WHERE id=?", (user_id,))
        conn.commit()
        flash("User deleted.")
    conn.close()
    return redirect(url_for("users"))




# =========================================================
# COMPLETE SCHOOL MODULES
# =========================================================

def role_admin_teacher():
    return session.get("role") in ("Admin", "Teacher")


def module_guard():
    if "user_id" not in session:
        return redirect(url_for("login"))
    return None


@app.route("/teachers")
@login_required
def teachers():
    conn=get_db(); rows=conn.execute("SELECT * FROM teachers ORDER BY name").fetchall(); conn.close()
    trs="".join(f"<tr><td>{esc(r['id'])}</td><td><strong>{esc(r['name'])}</strong></td><td>{esc(r['subject'])}</td><td>{esc(r['designation'])}</td><td>{esc(r['phone'])}</td><td>{esc(r['email'])}</td><td><a class='btn' href='{url_for('edit_teacher', teacher_id=r['id'])}'>Edit</a> <a class='btn btn-danger' href='{url_for('delete_teacher', teacher_id=r['id'])}' onclick=\"return confirm('Delete teacher?')\">Delete</a></td></tr>" for r in rows)
    html=f'''<h1>Teacher Management</h1><div class="card"><a class="btn btn-success" href="{url_for('add_teacher')}">+ Add Teacher</a></div><div class="card"><table><tr><th>ID</th><th>Name</th><th>Subject</th><th>Designation</th><th>Phone</th><th>Email</th><th>Action</th></tr>{trs or '<tr><td colspan="7">No teachers found.</td></tr>'}</table></div>'''
    return page("Teachers",html)

@app.route("/teachers/add", methods=["GET","POST"])
@login_required
def add_teacher():
    if request.method=="POST":
        d=[request.form.get(k,"").strip() for k in ["id","name","subject","phone","email","designation","address"]]
        if not d[0] or not d[1]: flash("Teacher ID and name are required."); return redirect(url_for("add_teacher"))
        conn=get_db()
        try:
            conn.execute("INSERT INTO teachers(id,name,subject,phone,email,designation,address) VALUES(?,?,?,?,?,?,?)",d); conn.commit(); flash("Teacher added.")
        except sqlite3.IntegrityError: flash("Teacher ID already exists.")
        finally: conn.close()
        return redirect(url_for("teachers"))
    html='''<h1>Add Teacher</h1><div class="card"><form method="post"><label>Teacher ID *</label><input name="id" required><label>Name *</label><input name="name" required><label>Subject</label><input name="subject"><label>Phone</label><input name="phone"><label>Email</label><input name="email" type="email"><label>Designation</label><input name="designation"><label>Address</label><input name="address"><button class="btn-success">Save Teacher</button></form></div>'''
    return page("Add Teacher",html)

@app.route("/teachers/edit/<teacher_id>", methods=["GET","POST"])
@login_required
def edit_teacher(teacher_id):
    conn=get_db(); t=conn.execute("SELECT * FROM teachers WHERE id=?",(teacher_id,)).fetchone()
    if not t: conn.close(); return "Teacher not found",404
    if request.method=="POST":
        vals=[request.form.get(k,"").strip() for k in ["name","subject","phone","email","designation","address"]]
        conn.execute("UPDATE teachers SET name=?,subject=?,phone=?,email=?,designation=?,address=? WHERE id=?",(*vals,teacher_id)); conn.commit(); conn.close(); flash("Teacher updated."); return redirect(url_for("teachers"))
    conn.close()
    html=f'''<h1>Edit Teacher</h1><div class="card"><form method="post"><label>ID</label><input value="{esc(t['id'])}" disabled><label>Name</label><input name="name" value="{esc(t['name'])}" required><label>Subject</label><input name="subject" value="{esc(t['subject'])}"><label>Phone</label><input name="phone" value="{esc(t['phone'])}"><label>Email</label><input name="email" value="{esc(t['email'])}"><label>Designation</label><input name="designation" value="{esc(t['designation'])}"><label>Address</label><input name="address" value="{esc(t['address'])}"><button class="btn-success">Update</button></form></div>'''
    return page("Edit Teacher",html)

@app.route("/teachers/delete/<teacher_id>")
@admin_required
def delete_teacher(teacher_id):
    conn=get_db(); conn.execute("DELETE FROM teachers WHERE id=?",(teacher_id,)); conn.commit(); conn.close(); flash("Teacher deleted."); return redirect(url_for("teachers"))

@app.route("/classes")
@login_required
def classes_page():
    conn=get_db(); rows=conn.execute("SELECT * FROM classes ORDER BY class_name,section").fetchall(); conn.close()
    trs="".join(f"<tr><td>{r['id']}</td><td>{esc(r['class_name'])}</td><td>{esc(r['section'])}</td><td>{esc(r['class_teacher'])}</td><td>{esc(r['room'])}</td><td><a class='btn' href='{url_for('edit_class', class_id=r['id'])}'>Edit</a> <a class='btn btn-danger' href='{url_for('delete_class', class_id=r['id'])}' onclick=\"return confirm('Delete class?')\">Delete</a></td></tr>" for r in rows)
    html=f'''<h1>Classes & Sections</h1><div class="card"><form method="post" action="{url_for('add_class')}"><div class="grid"><div><label>Class *</label><input name="class_name" required></div><div><label>Section</label><input name="section"></div><div><label>Class Teacher</label><input name="class_teacher"></div><div><label>Room</label><input name="room"></div></div><button class="btn-success">Add Class</button></form></div><div class="card"><table><tr><th>ID</th><th>Class</th><th>Section</th><th>Class Teacher</th><th>Room</th><th>Action</th></tr>{trs or '<tr><td colspan="6">No classes.</td></tr>'}</table></div>'''
    return page("Classes",html)

@app.route("/classes/add",methods=["POST"])
@login_required
def add_class():
    conn=get_db()
    try:
        conn.execute("INSERT INTO classes(class_name,section,class_teacher,room) VALUES(?,?,?,?)",(request.form.get('class_name','').strip(),request.form.get('section','').strip(),request.form.get('class_teacher','').strip(),request.form.get('room','').strip())); conn.commit(); flash("Class added.")
    except sqlite3.IntegrityError: flash("This class and section already exists.")
    finally: conn.close()
    return redirect(url_for("classes_page"))

@app.route("/classes/edit/<int:class_id>", methods=["GET", "POST"])
@login_required
def edit_class(class_id):
    conn=get_db(); r=conn.execute("SELECT * FROM classes WHERE id=?",(class_id,)).fetchone()
    if not r: conn.close(); return "Class not found.",404
    if request.method=="POST":
        try:
            conn.execute("UPDATE classes SET class_name=?,section=?,class_teacher=?,room=? WHERE id=?",(request.form.get('class_name'),request.form.get('section'),request.form.get('class_teacher'),request.form.get('room'),class_id)); conn.commit(); flash("Class updated.")
        except sqlite3.IntegrityError: flash("This class and section already exists.")
        finally: conn.close()
        return redirect(url_for("classes_page"))
    html=f"""<h1>Edit Class</h1><div class="card"><form method="post"><label>Class *</label><input name="class_name" value="{esc(r['class_name'])}" required><label>Section</label><input name="section" value="{esc(r['section'])}"><label>Class Teacher</label><input name="class_teacher" value="{esc(r['class_teacher'])}"><label>Room</label><input name="room" value="{esc(r['room'])}"><button class="btn-success">Update Class</button></form></div>"""
    conn.close(); return page("Edit Class",html)

@app.route("/classes/delete/<int:class_id>")
@admin_required
def delete_class(class_id):
    conn=get_db(); conn.execute("DELETE FROM classes WHERE id=?",(class_id,)); conn.commit(); conn.close(); flash("Class deleted."); return redirect(url_for("classes_page"))

@app.route("/fees")
@login_required
def fees():
    conn=get_db(); rows=conn.execute("SELECT f.*,s.name FROM fees f LEFT JOIN students s ON s.id=f.student_id ORDER BY f.id DESC").fetchall(); students_list=conn.execute("SELECT id,name FROM students ORDER BY name").fetchall(); conn.close()
    trs="".join(f"<tr><td>{r['id']}</td><td>{esc(r['student_id'])}</td><td>{esc(r['name'])}</td><td>{esc(r['fee_type'])}</td><td>{float(r['amount']):.2f}</td><td>{float(r['paid']):.2f}</td><td>{max(float(r['amount'])-float(r['paid']),0):.2f}</td><td>{esc(r['status'])}</td><td>{esc(r['due_date'])}</td><td><a class='btn' href='{url_for('edit_fee', fee_id=r['id'])}'>Edit</a> <a class='btn btn-danger' href='{url_for('delete_fee', fee_id=r['id'])}' onclick=\"return confirm('Delete this fee record?')\">Delete</a></td></tr>" for r in rows)
    opts=''.join(f"<option value='{esc(s['id'])}'>{esc(s['id'])} - {esc(s['name'])}</option>" for s in students_list)
    # Fees intelligence summary
    total_fee_records = len(rows)
    total_amount = sum(float(r["amount"] or 0) for r in rows)
    paid_amount = sum(float(r["paid"] or 0) for r in rows)
    due_amount = max(total_amount - paid_amount, 0)
    collection_rate = (
        paid_amount / total_amount * 100
        if total_amount else 0
    )

    fee_summary = f'''
    <div class="grid">
      <div class="stat"><h3>Fee Records</h3><h2>{total_fee_records}</h2></div>
      <div class="stat"><h3>Total Amount</h3><h2>{total_amount:,.2f}</h2></div>
      <div class="stat"><h3>Paid Amount</h3><h2>{paid_amount:,.2f}</h2></div>
      <div class="stat"><h3>Due Amount</h3><h2>{due_amount:,.2f}</h2></div>
      <div class="stat"><h3>Collection Rate</h3><h2>{collection_rate:.1f}%</h2></div>
    </div>
    <div class="card">
      <strong>Fee Collection Summary:</strong>
      Paid {paid_amount:,.2f} out of {total_amount:,.2f}.
      Outstanding amount: {due_amount:,.2f}.
    </div>
    '''

    html=f'''<h1>Fees & Accounts</h1>{fee_summary}<div class="card"><form method="post" action="{url_for('add_fee')}"><div class="grid"><div><label>Student *</label><select name="student_id" required>{opts}</select></div><div><label>Fee Type</label><input name="fee_type" placeholder="Monthly/Exam/Admission"></div><div><label>Amount</label><input name="amount" type="number" step="0.01" required></div><div><label>Paid</label><input name="paid" type="number" step="0.01" value="0"></div><div><label>Due Date</label><input name="due_date" type="date"></div><div><label>Paid Date</label><input name="paid_date" type="date"></div></div><button class="btn-success">Save Fee</button></form></div><div class="card"><table><tr><th>#</th><th>Student ID</th><th>Name</th><th>Type</th><th>Amount</th><th>Paid</th><th>Due</th><th>Status</th><th>Due Date</th><th>Actions</th></tr>{trs or '<tr><td colspan="10">No fee records.</td></tr>'}</table></div>'''
    return page("Fees",html)

@app.route("/fees/add",methods=["POST"])
@login_required
def add_fee():
    amount=float(request.form.get('amount') or 0); paid=float(request.form.get('paid') or 0); status='Paid' if paid>=amount and amount>0 else ('Partial' if paid>0 else 'Due')
    conn=get_db(); conn.execute("INSERT INTO fees(student_id,fee_type,amount,paid,due_date,paid_date,status) VALUES(?,?,?,?,?,?,?)",(request.form.get('student_id'),request.form.get('fee_type'),amount,paid,request.form.get('due_date'),request.form.get('paid_date'),status)); conn.commit(); conn.close(); flash("Fee record saved."); return redirect(url_for("fees"))

@app.route("/fees/edit/<int:fee_id>", methods=["GET", "POST"])
@login_required
def edit_fee(fee_id):
    conn=get_db(); f=conn.execute("SELECT * FROM fees WHERE id=?",(fee_id,)).fetchone(); students_list=conn.execute("SELECT id,name FROM students ORDER BY name").fetchall()
    if not f: conn.close(); return "Fee record not found.",404
    if request.method=="POST":
        try: amount=float(request.form.get('amount') or 0); paid=float(request.form.get('paid') or 0)
        except ValueError: conn.close(); flash("Amount and paid must be numbers."); return redirect(url_for('edit_fee',fee_id=fee_id))
        status='Paid' if paid>=amount and amount>0 else ('Partial' if paid>0 else 'Due')
        conn.execute("UPDATE fees SET student_id=?,fee_type=?,amount=?,paid=?,due_date=?,paid_date=?,status=? WHERE id=?",(request.form.get('student_id'),request.form.get('fee_type'),amount,paid,request.form.get('due_date'),request.form.get('paid_date'),status,fee_id)); conn.commit(); conn.close(); flash("Fee record updated."); return redirect(url_for('fees'))
    opts=''.join(f"<option value='{esc(x['id'])}' {'selected' if x['id']==f['student_id'] else ''}>{esc(x['id'])} - {esc(x['name'])}</option>" for x in students_list)
    html=f"""<h1>Edit Fee</h1><div class="card"><form method="post"><label>Student</label><select name="student_id" required>{opts}</select><label>Fee Type</label><input name="fee_type" value="{esc(f['fee_type'])}"><label>Amount</label><input name="amount" type="number" step="0.01" value="{f['amount']}" required><label>Paid</label><input name="paid" type="number" step="0.01" value="{f['paid']}" required><label>Due Date</label><input name="due_date" type="date" value="{esc(f['due_date'])}"><label>Paid Date</label><input name="paid_date" type="date" value="{esc(f['paid_date'])}"><button class="btn-success">Update Fee</button></form></div>"""
    conn.close(); return page("Edit Fee",html)

@app.route("/fees/delete/<int:fee_id>")
@admin_required
def delete_fee(fee_id):
    conn=get_db(); conn.execute("DELETE FROM fees WHERE id=?",(fee_id,)); conn.commit(); conn.close(); flash("Fee record deleted."); return redirect(url_for('fees'))

@app.route("/exams")
@login_required
def exams():
    conn=get_db(); rows=conn.execute("SELECT * FROM exams ORDER BY exam_date DESC,id DESC").fetchall(); conn.close()
    trs="".join(f"<tr><td>{r['id']}</td><td>{esc(r['exam_name'])}</td><td>{esc(r['class_name'])}</td><td>{esc(r['subject'])}</td><td>{esc(r['exam_date'])}</td><td>{r['total_marks']}</td><td><a class='btn' href='{url_for('edit_exam', exam_id=r['id'])}'>Edit</a> <a class='btn btn-danger' href='{url_for('delete_exam', exam_id=r['id'])}' onclick=\"return confirm('Delete this exam?')\">Delete</a></td></tr>" for r in rows)
    # Exams intelligence summary
    total_exams = len(rows)

    subjects = {
        str(r["subject"]).strip()
        for r in rows
        if r["subject"]
    }

    classes = {
        str(r["class_name"]).strip()
        for r in rows
        if r["class_name"]
    }

    total_marks_values = [
        float(r["total_marks"] or 0)
        for r in rows
        if r["total_marks"] is not None
    ]

    average_total_marks = (
        sum(total_marks_values) / len(total_marks_values)
        if total_marks_values else 0
    )

    today = date.today().isoformat()

    upcoming_exams = sum(
        1 for r in rows
        if r["exam_date"] and str(r["exam_date"]) >= today
    )

    exam_summary = f'''
    <div class="grid">
      <div class="stat"><h3>Total Exams</h3><h2>{total_exams}</h2></div>
      <div class="stat"><h3>Subjects</h3><h2>{len(subjects)}</h2></div>
      <div class="stat"><h3>Classes</h3><h2>{len(classes)}</h2></div>
      <div class="stat"><h3>Avg Total Marks</h3><h2>{average_total_marks:.1f}</h2></div>
      <div class="stat"><h3>Upcoming Exams</h3><h2>{upcoming_exams}</h2></div>
    </div>
    '''

    html=f'''<h1>Exam Management</h1>{exam_summary}<div class="card"><form method="post" action="{url_for('add_exam')}"><div class="grid"><div><label>Exam Name</label><input name="exam_name" required></div><div><label>Class</label><input name="class_name"></div><div><label>Subject</label><input name="subject"></div><div><label>Date</label><input name="exam_date" type="date"></div><div><label>Total Marks</label><input name="total_marks" type="number" value="100"></div></div><button class="btn-success">Create Exam</button></form></div><div class="card"><table><tr><th>ID</th><th>Exam</th><th>Class</th><th>Subject</th><th>Date</th><th>Total</th><th>Actions</th></tr>{trs or '<tr><td colspan="7">No exams.</td></tr>'}</table></div>'''
    return page("Exams",html)

@app.route("/exams/add",methods=["POST"])
@login_required
def add_exam():
    conn=get_db(); conn.execute("INSERT INTO exams(exam_name,class_name,subject,exam_date,total_marks) VALUES(?,?,?,?,?)",(request.form.get('exam_name'),request.form.get('class_name'),request.form.get('subject'),request.form.get('exam_date'),float(request.form.get('total_marks') or 100))); conn.commit(); conn.close(); flash("Exam created."); return redirect(url_for("exams"))

@app.route("/exams/edit/<int:exam_id>", methods=["GET", "POST"])
@login_required
def edit_exam(exam_id):
    conn=get_db(); r=conn.execute("SELECT * FROM exams WHERE id=?",(exam_id,)).fetchone()
    if not r: conn.close(); return "Exam not found.",404
    if request.method=="POST":
        try: total=float(request.form.get('total_marks') or 100)
        except ValueError: conn.close(); flash("Total marks must be a number."); return redirect(url_for('edit_exam',exam_id=exam_id))
        conn.execute("UPDATE exams SET exam_name=?,class_name=?,subject=?,exam_date=?,total_marks=? WHERE id=?",(request.form.get('exam_name'),request.form.get('class_name'),request.form.get('subject'),request.form.get('exam_date'),total,exam_id)); conn.commit(); conn.close(); flash("Exam updated."); return redirect(url_for('exams'))
    html=f"""<h1>Edit Exam</h1><div class="card"><form method="post"><label>Exam Name</label><input name="exam_name" value="{esc(r['exam_name'])}" required><label>Class</label><input name="class_name" value="{esc(r['class_name'])}"><label>Subject</label><input name="subject" value="{esc(r['subject'])}"><label>Date</label><input name="exam_date" type="date" value="{esc(r['exam_date'])}"><label>Total Marks</label><input name="total_marks" type="number" step="0.01" value="{r['total_marks']}"><button class="btn-success">Update Exam</button></form></div>"""
    conn.close(); return page("Edit Exam",html)

@app.route("/exams/delete/<int:exam_id>")
@admin_required
def delete_exam(exam_id):
    conn=get_db(); conn.execute("DELETE FROM exams WHERE id=?",(exam_id,)); conn.commit(); conn.close(); flash("Exam deleted."); return redirect(url_for('exams'))

@app.route("/routine")
@login_required
def routine():
    conn=get_db(); rows=conn.execute("SELECT * FROM routines ORDER BY class_name,section,CASE day_name WHEN 'Saturday' THEN 1 WHEN 'Sunday' THEN 2 WHEN 'Monday' THEN 3 WHEN 'Tuesday' THEN 4 WHEN 'Wednesday' THEN 5 WHEN 'Thursday' THEN 6 WHEN 'Friday' THEN 7 ELSE 8 END,period_no").fetchall(); conn.close()
    trs="".join(f"<tr><td>{esc(r['class_name'])}</td><td>{esc(r['section'])}</td><td>{esc(r['day_name'])}</td><td>{r['period_no']}</td><td>{esc(r['subject'])}</td><td>{esc(r['teacher'])}</td><td>{esc(r['room'])}</td><td><a class='btn' href='{url_for('edit_routine', routine_id=r['id'])}'>Edit</a> <a class='btn btn-danger' href='{url_for('delete_routine', routine_id=r['id'])}' onclick=\"return confirm('Delete this routine entry?')\">Delete</a></td></tr>" for r in rows)
    days=''.join(f'<option>{d}</option>' for d in ['Saturday','Sunday','Monday','Tuesday','Wednesday','Thursday','Friday'])
    html=f'''<h1>Class Routine</h1><div class="card"><form method="post" action="{url_for('add_routine')}"><div class="grid"><div><label>Class</label><input name="class_name" required></div><div><label>Section</label><input name="section"></div><div><label>Day</label><select name="day_name">{days}</select></div><div><label>Period</label><input name="period_no" type="number" min="1" required></div><div><label>Subject</label><input name="subject" required></div><div><label>Teacher</label><input name="teacher"></div><div><label>Room</label><input name="room"></div></div><button class="btn-success">Add Routine</button></form></div><div class="card"><table><tr><th>Class</th><th>Section</th><th>Day</th><th>Period</th><th>Subject</th><th>Teacher</th><th>Room</th><th>Actions</th></tr>{trs or '<tr><td colspan="8">No routine entries.</td></tr>'}</table></div>'''
    return page("Routine",html)

@app.route("/routine/add",methods=["POST"])
@login_required
def add_routine():
    conn=get_db(); conn.execute("INSERT INTO routines(class_name,section,day_name,period_no,subject,teacher,room) VALUES(?,?,?,?,?,?,?)",(request.form.get('class_name'),request.form.get('section'),request.form.get('day_name'),int(request.form.get('period_no') or 1),request.form.get('subject'),request.form.get('teacher'),request.form.get('room'))); conn.commit(); conn.close(); flash("Routine added."); return redirect(url_for("routine"))

@app.route("/routine/edit/<int:routine_id>", methods=["GET", "POST"])
@login_required
def edit_routine(routine_id):
    conn=get_db(); r=conn.execute("SELECT * FROM routines WHERE id=?",(routine_id,)).fetchone()
    if not r: conn.close(); return "Routine entry not found.",404
    days=['Saturday','Sunday','Monday','Tuesday','Wednesday','Thursday','Friday']
    if request.method=="POST":
        conn.execute("UPDATE routines SET class_name=?,section=?,day_name=?,period_no=?,subject=?,teacher=?,room=? WHERE id=?",(request.form.get('class_name'),request.form.get('section'),request.form.get('day_name'),int(request.form.get('period_no') or 1),request.form.get('subject'),request.form.get('teacher'),request.form.get('room'),routine_id)); conn.commit(); conn.close(); flash("Routine updated."); return redirect(url_for('routine'))
    opts=''.join(f"<option {'selected' if d==r['day_name'] else ''}>{d}</option>" for d in days)
    html=f"""<h1>Edit Routine</h1><div class="card"><form method="post"><label>Class</label><input name="class_name" value="{esc(r['class_name'])}" required><label>Section</label><input name="section" value="{esc(r['section'])}"><label>Day</label><select name="day_name">{opts}</select><label>Period</label><input name="period_no" type="number" min="1" value="{r['period_no']}" required><label>Subject</label><input name="subject" value="{esc(r['subject'])}" required><label>Teacher</label><input name="teacher" value="{esc(r['teacher'])}"><label>Room</label><input name="room" value="{esc(r['room'])}"><button class="btn-success">Update Routine</button></form></div>"""
    conn.close(); return page("Edit Routine",html)

@app.route("/routine/delete/<int:routine_id>")
@admin_required
def delete_routine(routine_id):
    conn=get_db(); conn.execute("DELETE FROM routines WHERE id=?",(routine_id,)); conn.commit(); conn.close(); flash("Routine entry deleted."); return redirect(url_for('routine'))

@app.route("/notices")
@login_required
def notices():
    conn=get_db(); rows=conn.execute("SELECT * FROM notices ORDER BY publish_date DESC,id DESC").fetchall(); conn.close()
    cards=''.join(f"<div class='card'><h2>{esc(r['title'])}</h2><p class='muted'>{esc(r['publish_date'])} Â· {esc(r['audience'])}</p><p>{esc(r['body']).replace(chr(10),'<br>')}</p><a class='btn' href='{url_for('edit_notice', notice_id=r['id'])}'>Edit</a> <a class='btn btn-danger' href='{url_for('delete_notice', notice_id=r['id'])}' onclick=\"return confirm('Delete this notice?')\">Delete</a></div>" for r in rows)
    html=f'''<h1>Notice Board</h1><div class="card"><form method="post" action="{url_for('add_notice')}"><label>Title</label><input name="title" required><label>Audience</label><select name="audience"><option>All</option><option>Students</option><option>Parents</option><option>Teachers</option></select><label>Notice</label><textarea name="body" rows="5" style="width:100%;padding:10px;border:1px solid #ccd3d9;border-radius:6px" required></textarea><button class="btn-success">Publish Notice</button></form></div>{cards or '<div class="card">No notices.</div>'}'''
    return page("Notices",html)

@app.route("/notices/add",methods=["POST"])
@login_required
def add_notice():
    conn=get_db(); conn.execute("INSERT INTO notices(title,body,audience,publish_date) VALUES(?,?,?,?)",(request.form.get('title'),request.form.get('body'),request.form.get('audience'),date.today().isoformat())); conn.commit(); conn.close(); flash("Notice published."); return redirect(url_for("notices"))

@app.route("/notices/edit/<int:notice_id>", methods=["GET", "POST"])
@login_required
def edit_notice(notice_id):
    conn=get_db(); r=conn.execute("SELECT * FROM notices WHERE id=?",(notice_id,)).fetchone()
    if not r: conn.close(); return "Notice not found.",404
    audiences=['All','Students','Parents','Teachers']
    if request.method=="POST":
        conn.execute("UPDATE notices SET title=?,body=?,audience=? WHERE id=?",(request.form.get('title'),request.form.get('body'),request.form.get('audience'),notice_id)); conn.commit(); conn.close(); flash("Notice updated."); return redirect(url_for('notices'))
    opts=''.join(f"<option {'selected' if a==r['audience'] else ''}>{a}</option>" for a in audiences)
    html=f"""<h1>Edit Notice</h1><div class="card"><form method="post"><label>Title</label><input name="title" value="{esc(r['title'])}" required><label>Audience</label><select name="audience">{opts}</select><label>Notice</label><textarea name="body" rows="7" style="width:100%;padding:10px;border:1px solid #ccd3d9;border-radius:6px" required>{esc(r['body'])}</textarea><button class="btn-success">Update Notice</button></form></div>"""
    conn.close(); return page("Edit Notice",html)

@app.route("/notices/delete/<int:notice_id>")
@admin_required
def delete_notice(notice_id):
    conn=get_db(); conn.execute("DELETE FROM notices WHERE id=?",(notice_id,)); conn.commit(); conn.close(); flash("Notice deleted."); return redirect(url_for('notices'))

@app.route("/admissions")
@login_required
def admissions():
    conn=get_db(); rows=conn.execute("SELECT * FROM admissions ORDER BY id DESC").fetchall(); conn.close()
    trs="".join(f"<tr><td>{r['id']}</td><td>{esc(r['applicant_name'])}</td><td>{esc(r['guardian'])}</td><td>{esc(r['phone'])}</td><td>{esc(r['desired_class'])}</td><td>{esc(r['previous_school'])}</td><td>{esc(r['status'])}</td><td>{esc(r['application_date'])}</td><td><a class='btn' href='{url_for('edit_admission', admission_id=r['id'])}'>Edit</a> <a class='btn btn-danger' href='{url_for('delete_admission', admission_id=r['id'])}' onclick=\"return confirm('Delete this application?')\">Delete</a></td></tr>" for r in rows)
    html=f'''<h1>Online Admission Register</h1><div class="card"><form method="post" action="{url_for('add_admission')}"><div class="grid"><div><label>Applicant Name *</label><input name="applicant_name" required></div><div><label>Guardian</label><input name="guardian"></div><div><label>Phone</label><input name="phone"></div><div><label>Desired Class</label><input name="desired_class"></div><div><label>Previous School</label><input name="previous_school"></div></div><button class="btn-success">Submit Application</button></form></div><div class="card"><table><tr><th>#</th><th>Applicant</th><th>Guardian</th><th>Phone</th><th>Class</th><th>Previous School</th><th>Status</th><th>Date</th><th>Actions</th></tr>{trs or '<tr><td colspan="9">No applications.</td></tr>'}</table></div>'''
    return page("Admission",html)

@app.route("/admissions/add",methods=["POST"])
@login_required
def add_admission():
    conn=get_db(); conn.execute("INSERT INTO admissions(applicant_name,guardian,phone,desired_class,previous_school,status,application_date) VALUES(?,?,?,?,?,?,?)",(request.form.get('applicant_name'),request.form.get('guardian'),request.form.get('phone'),request.form.get('desired_class'),request.form.get('previous_school'),'Pending',date.today().isoformat())); conn.commit(); conn.close(); flash("Admission application recorded."); return redirect(url_for("admissions"))

@app.route("/admissions/edit/<int:admission_id>", methods=["GET", "POST"])
@login_required
def edit_admission(admission_id):
    conn=get_db(); r=conn.execute("SELECT * FROM admissions WHERE id=?",(admission_id,)).fetchone()
    if not r: conn.close(); return "Admission not found.",404
    statuses=['Pending','Approved','Rejected','Admitted']
    if request.method=="POST":
        conn.execute("UPDATE admissions SET applicant_name=?,guardian=?,phone=?,desired_class=?,previous_school=?,status=? WHERE id=?",(request.form.get('applicant_name'),request.form.get('guardian'),request.form.get('phone'),request.form.get('desired_class'),request.form.get('previous_school'),request.form.get('status'),admission_id)); conn.commit(); conn.close(); flash("Admission application updated."); return redirect(url_for('admissions'))
    opts=''.join(f"<option {'selected' if st==r['status'] else ''}>{st}</option>" for st in statuses)
    html=f"""<h1>Edit Admission</h1><div class="card"><form method="post"><label>Applicant Name</label><input name="applicant_name" value="{esc(r['applicant_name'])}" required><label>Guardian</label><input name="guardian" value="{esc(r['guardian'])}"><label>Phone</label><input name="phone" value="{esc(r['phone'])}"><label>Desired Class</label><input name="desired_class" value="{esc(r['desired_class'])}"><label>Previous School</label><input name="previous_school" value="{esc(r['previous_school'])}"><label>Status</label><select name="status">{opts}</select><button class="btn-success">Update Application</button></form></div>"""
    conn.close(); return page("Edit Admission",html)

@app.route("/admissions/delete/<int:admission_id>")
@admin_required
def delete_admission(admission_id):
    conn=get_db(); conn.execute("DELETE FROM admissions WHERE id=?",(admission_id,)); conn.commit(); conn.close(); flash("Admission application deleted."); return redirect(url_for('admissions'))

@app.route("/reports")
@login_required
def reports():
    conn=get_db(); students_count=conn.execute("SELECT COUNT(*) c FROM students").fetchone()['c']; teachers_count=conn.execute("SELECT COUNT(*) c FROM teachers").fetchone()['c']; fees_total=conn.execute("SELECT COALESCE(SUM(amount),0) x FROM fees").fetchone()['x']; fees_paid=conn.execute("SELECT COALESCE(SUM(paid),0) x FROM fees").fetchone()['x']; admissions_count=conn.execute("SELECT COUNT(*) c FROM admissions").fetchone()['c']; conn.close()
    html=f'''<h1>Reports & Summary</h1><div class="grid"><div class="stat"><h3>Students</h3><h2>{students_count}</h2></div><div class="stat"><h3>Teachers</h3><h2>{teachers_count}</h2></div><div class="stat"><h3>Total Fees</h3><h2>{float(fees_total):.2f}</h2></div><div class="stat"><h3>Fees Collected</h3><h2>{float(fees_paid):.2f}</h2></div><div class="stat"><h3>Applications</h3><h2>{admissions_count}</h2></div></div><div class="card"><button onclick="window.print()">Print Summary</button></div>'''
    return page("Reports",html)

@app.route("/backup")
@admin_required
def backup_db():
    import shutil
    stamp=datetime.now().strftime('%Y%m%d_%H%M%S'); target=os.path.join(BASE_DIR,f"students_backup_{stamp}.db"); shutil.copy2(DATABASE,target); flash(f"Database backup created: {os.path.basename(target)}"); return redirect(url_for('home'))


# ===== ENGLISH WINGS ACADEMY + EDUCATION CONSULTANCY CRUD =====
ACADEMY_MODULES={
"students":("Academy Students",[("name","Student Name",1),("phone","Phone",0),("guardian","Guardian",0),("course","Course",0),("batch","Batch",0)]),
"notes":("Notes",[("title","Title",1),("subject","Subject",0),("level","Level",0),("content","Content",0),("status","Status",0)]),
"vocabulary":("Vocabulary",[("word","Word",1),("pronunciation","Pronunciation",0),("meaning","Meaning",0),("example","Example",0),("level","Level",0)]),
"ielts_papers":("IELTS Papers",[("paper_name","Paper Name",1),("skill","Skill",0),("test_no","Test No.",0),("source","Source",0),("status","Status",0)]),
"answer_keys":("Answer Keys",[("paper_name","Paper Name",1),("skill","Skill",0),("answers","Answers",0),("notes","Notes",0)]),
"tests":("Academy Tests",[("test_name","Test Name",1),("course","Course",0),("test_date","Test Date",0),("total_marks","Total Marks",0)]),
"results":("Academy Results",[("student_id","Student ID",1),("test_name","Test Name",0),("subject","Subject",0),("marks","Marks",0),("total_marks","Total Marks",0)]),
"progress":("Academy Progress",[("student_id","Student ID",1),("month","Month",0),("attendance","Attendance",0),("performance","Performance",0),("remarks","Remarks",0)]),
"certificates":("Academy Certificates",[("student_id","Student ID",1),("title","Title",0),("achievement_text","Achievement",0),("issue_date","Issue Date",0)])
}

CONSULTANCY_MODULES={
"clients":("Clients",[("name","Client Name",1),("phone","Phone",0),("email","Email",0),("service_type","Service Type",0),("target_country","Target Country",0)]),
"shortlist":("Shortlist",[("client_id","Client ID",1),("university","University",0),("program","Program",0),("country","Country",0),("priority","Priority",0),("notes","Notes",0)]),
"scholarships":("Scholarships",[("client_id","Client ID",1),("scholarship_name","Scholarship Name",0),("provider","Provider",0),("amount","Amount",0),("status","Status",0),("award_date","Award Date",0),("remarks","Remarks",0)]),
"applications":("Applications",[("client_id","Client ID",1),("university","University",0),("program","Program",0),("application_type","Application Type",0),("status","Status",0),("submitted_date","Submitted Date",0)]),
"checklist":("Checklist",[("client_id","Client ID",1),("document_name","Document Name",0),("status","Status",0),("notes","Notes",0)]),
"deadlines":("Deadlines",[("client_id","Client ID",1),("task","Task",1),("deadline_date","Deadline Date",0),("status","Status",0)]),
"offers_visa":("Offers / Visa",[("client_name","Client Name",1),("university","University",0),("offer_status","Offer Status",0),("visa_status","Visa Status",0),("notes","Notes",0)]),
"invoices":("Consultancy Invoices",[("client_id","Client ID",1),("description","Description",0),("amount","Amount",0),("paid","Paid",0),("status","Status",0),("invoice_date","Invoice Date",0)])
}
EXTENDED={**ACADEMY_MODULES,**CONSULTANCY_MODULES}
def init_extended_modules_db():
 conn=get_db()
 for key,(title,fields) in EXTENDED.items():
  table=("academy_" if key in ACADEMY_MODULES else "consultancy_")+key
  cols="id INTEGER PRIMARY KEY AUTOINCREMENT,"+",".join(f"{k} TEXT" for k,_,_ in fields)+",created_at TEXT"
  conn.execute(f"CREATE TABLE IF NOT EXISTS {table} ({cols})")
 conn.commit();conn.close()
def xcfg(area,module): return (ACADEMY_MODULES if area=="academy" else CONSULTANCY_MODULES).get(module)
def xlist(area,module):
 cfg=xcfg(area,module)
 if not cfg:return redirect(url_for("home"))
 title,fields=cfg; table=("academy_" if area=="academy" else "consultancy_")+module
 conn=get_db();rows=conn.execute(f"SELECT * FROM {table} ORDER BY id DESC").fetchall();conn.close()
 heads="".join(f"<th>{esc(label)}</th>" for _,label,_ in fields); body=""
 for r in rows:
   body+="<tr>"+"".join(f"<td>{esc(r[k] if k in r.keys() else '')}</td>" for k,_,_ in fields)+f"<td><a class='btn btn-info' href='{f"/extended/{area}/{module}/{r['id']}/edit" }'>Edit</a> <a class='btn btn-danger' href='{f"/extended/{area}/{module}/{r['id']}/delete" }' onclick=\"return confirm('Delete this record?');\">Delete</a></td></tr>"
 if not body:body=f"<tr><td colspan='{len(fields)+1}'>No records yet.</td></tr>"
 return page(title,f"<div class='toolbar'><h1 style='flex:1'>{esc(title)}</h1><a class='btn btn-success' href='{url_for('xadd',area=area,module=module)}'>+ Add</a></div><div class='card'><table><tr>{heads}<th>Actions</th></tr>{body}</table></div>")
@app.route('/academy/<module>')
@login_required
def academy_module(module): return xlist('academy',module)
@app.route('/consultancy/<module>')
@login_required
def consultancy_module(module): return xlist('consultancy',module)
def xform(area,module,row=None):
 title,fields=xcfg(area,module); fs=""
 for k,label,req in fields:
  v=esc(row[k]) if row else "";fs+=f"<label>{esc(label)}</label><textarea name='{k}' rows='3' style='width:100%;padding:10px;margin:5px 0 12px' {'required' if req else ''}>{v}</textarea>"
 act='Update' if row else 'Save';return page(f'{act} {title}',f"<h1>{act} â€” {esc(title)}</h1><div class='card'><form method='post'>{fs}<button class='btn btn-success'>{act}</button> <a class='btn' href='{url_for('xlist_route',area=area,module=module)}'>Cancel</a></form></div>")
@app.route('/extended/<area>/<module>')
@login_required
def xlist_route(area,module): return xlist(area,module)
@app.route('/extended/<area>/<module>/add',methods=['GET','POST'])
@login_required
def xadd(area,module):
 cfg=xcfg(area,module)
 if not cfg:return redirect(url_for('home'))
 if request.method=='POST':
  title,fields=cfg;vals=[request.form.get(k,'').strip() for k,_,_ in fields];table=('academy_' if area=='academy' else 'consultancy_')+module;cols=','.join(k for k,_,_ in fields);ph=','.join('?' for _ in vals);conn=get_db();conn.execute(f'INSERT INTO {table} ({cols},created_at) VALUES ({ph},?)',vals+[datetime.now().isoformat(timespec='seconds')]);conn.commit();conn.close();flash(f'{title} record added successfully.');return redirect(url_for('xlist_route',area=area,module=module))
 return xform(area,module)
@app.route('/extended/<area>/<module>/<int:item_id>/edit',methods=['GET','POST'])
@login_required
def xedit(area,module,item_id):
 cfg=xcfg(area,module)
 if not cfg:return redirect(url_for('home'))
 title,fields=cfg;table=('academy_' if area=='academy' else 'consultancy_')+module;conn=get_db();row=conn.execute(f'SELECT * FROM {table} WHERE id=?',(item_id,)).fetchone()
 if not row:conn.close();flash('Record not found.');return redirect(url_for('xlist_route',area=area,module=module))
 if request.method=='POST':
  vals=[request.form.get(k,'').strip() for k,_,_ in fields];sets=','.join(f'{k}=?' for k,_,_ in fields);conn.execute(f'UPDATE {table} SET {sets} WHERE id=?',vals+[item_id]);conn.commit();conn.close();flash(f'{title} record updated successfully.');return redirect(url_for('xlist_route',area=area,module=module))
 conn.close();return xform(area,module,row)
@app.route('/extended/<area>/<module>/<int:item_id>/delete')
@login_required
def xdelete(area,module,item_id):
 cfg=xcfg(area,module)
 if not cfg:return redirect(url_for('home'))
 table=('academy_' if area=='academy' else 'consultancy_')+module;conn=get_db();conn.execute(f'DELETE FROM {table} WHERE id=?',(item_id,));conn.commit();conn.close();flash('Record deleted successfully.');return redirect(url_for('xlist_route',area=area,module=module))
init_extended_modules_db()

# =========================================================
# START
# =========================================================

init_db()


# ===== SHAKIL AI PREMIUM COURSES V1 =====

import os as _premium_os
import sqlite3 as _premium_sqlite3
from pathlib import Path as _PremiumPath
from flask import request as _premium_request, redirect as _premium_redirect, url_for as _premium_url_for, send_from_directory as _premium_send_from_directory
from werkzeug.utils import secure_filename as _premium_secure_filename

_PREMIUM_BASE = _PremiumPath(__file__).resolve().parent
_PREMIUM_UPLOAD_DIR = _PREMIUM_BASE / "premium_uploads"
_PREMIUM_UPLOAD_DIR.mkdir(parents=True, exist_ok=True)

_PREMIUM_ALLOWED = {
    "pdf", "doc", "docx", "ppt", "pptx",
    "xls", "xlsx", "csv",
    "mp4", "webm",
    "jpg", "jpeg", "png"
}

def _premium_db():
    conn = _premium_sqlite3.connect(DATABASE)
    conn.row_factory = _premium_sqlite3.Row
    return conn

def _premium_init_db():
    conn = _premium_db()

    conn.execute("""
        CREATE TABLE IF NOT EXISTS premium_courses (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            title TEXT NOT NULL,
            category TEXT DEFAULT 'General',
            description TEXT DEFAULT '',
            instructor TEXT DEFAULT '',
            price REAL DEFAULT 0,
            duration TEXT DEFAULT '',
            status TEXT DEFAULT 'Published',
            created_at TEXT DEFAULT CURRENT_TIMESTAMP
        )
    """)

    conn.execute("""
        CREATE TABLE IF NOT EXISTS premium_course_files (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            course_id INTEGER NOT NULL,
            original_name TEXT NOT NULL,
            stored_name TEXT NOT NULL,
            file_type TEXT DEFAULT '',
            uploaded_at TEXT DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY(course_id) REFERENCES premium_courses(id)
        )
    """)

    conn.commit()
    conn.close()

_premium_init_db()

def _premium_admin_required():
    if not session.get("username"):
        return False
    return True

def _premium_page(title, content):
    return page(title, content)

@app.route("/premium-courses")
def premium_courses():
    _premium_init_db()
    conn = _premium_db()
    courses = conn.execute("""
        SELECT *
        FROM premium_courses
        WHERE status='Published'
        ORDER BY id DESC
    """).fetchall()
    conn.close()

    cards = ""

    for c in courses:
        price = c["price"] or 0

        cards += f"""
        <div class="card">
            <h2>{esc(c["title"])}</h2>
            <p><strong>Category:</strong> {esc(c["category"] or "")}</p>
            <p>{esc(c["description"] or "")}</p>
            <p>
                <strong>Instructor:</strong> {esc(c["instructor"] or "English Wings Academy")}
                &nbsp; | &nbsp;
                <strong>Duration:</strong> {esc(c["duration"] or "Flexible")}
            </p>
            <p><strong>Course Fee:</strong> {price:g}</p>
            <a class="btn btn-info"
               href="{_premium_url_for('premium_course_detail', course_id=c['id'])}">
               View Course
            </a>
        </div>
        """

    if not cards:
        cards = """
        <div class="card">
            <h2>No Premium Courses Yet</h2>
            <p>Premium courses will appear here after they are added from the admin panel.</p>
        </div>
        """

    return _premium_page(
        "Premium Courses",
        f"""
        <div class="card">
            <h1>Premium Courses</h1>
            <p>English Wings Academy â€” Premium Learning</p>
        </div>

        <div class="grid">
            {cards}
        </div>
        """
    )

@app.route("/premium-courses/<int:course_id>")
def premium_course_detail(course_id):
    _premium_init_db()
    conn = _premium_db()

    course = conn.execute(
        "SELECT * FROM premium_courses WHERE id=?",
        (course_id,)
    ).fetchone()

    if not course:
        conn.close()
        return _premium_page(
            "Course Not Found",
            '<div class="card"><h2>Course not found.</h2></div>'
        ), 404

    files = conn.execute("""
        SELECT *
        FROM premium_course_files
        WHERE course_id=?
        ORDER BY id DESC
    """, (course_id,)).fetchall()

    conn.close()

    file_html = ""

    for f in files:
        file_html += f"""
        <li style="margin-bottom:10px;">
            <a class="btn btn-info"
               href="{_premium_url_for('premium_course_file',
                                       file_id=f['id'])}">
               {esc(f["original_name"])}
            </a>
        </li>
        """

    if not file_html:
        file_html = "<li>No course resources uploaded yet.</li>"

    price = course["price"] or 0

    return _premium_page(
        course["title"],
        f"""
        <div class="card">
            <h1>{esc(course["title"])}</h1>
            <p><strong>Category:</strong> {esc(course["category"] or "")}</p>
            <p><strong>Instructor:</strong> {esc(course["instructor"] or "")}</p>
            <p><strong>Duration:</strong> {esc(course["duration"] or "")}</p>
            <p><strong>Fee:</strong> {price:g}</p>
            <hr>
            <p>{esc(course["description"] or "")}</p>
        </div>

        <div class="card">
            <h2>Course Resources</h2>
            <ul>
                {file_html}
            </ul>
        </div>
        """
    )

@app.route("/premium-courses/file/<int:file_id>")
def premium_course_file(file_id):
    _premium_init_db()
    conn = _premium_db()

    f = conn.execute(
        "SELECT * FROM premium_course_files WHERE id=?",
        (file_id,)
    ).fetchone()

    conn.close()

    if not f:
        return "File not found", 404

    stored = f["stored_name"]

    return _premium_send_from_directory(
        str(_PREMIUM_UPLOAD_DIR),
        stored,
        as_attachment=False,
        download_name=f["original_name"]
    )

@app.route("/premium-courses/admin")
def premium_courses_admin():
    if not _premium_admin_required():
        return _premium_redirect(_premium_url_for("login"))

    _premium_init_db()
    conn = _premium_db()

    courses = conn.execute("""
        SELECT c.*,
               COUNT(f.id) AS file_count
        FROM premium_courses c
        LEFT JOIN premium_course_files f
               ON c.id=f.course_id
        GROUP BY c.id
        ORDER BY c.id DESC
    """).fetchall()

    conn.close()

    rows = ""

    for c in courses:
        rows += f"""
        <tr>
            <td>{c["id"]}</td>
            <td>{esc(c["title"])}</td>
            <td>{esc(c["category"] or "")}</td>
            <td>{c["price"] or 0:g}</td>
            <td>{c["file_count"]}</td>
            <td>{esc(c["status"] or "")}</td>
            <td>
                <a class="btn btn-info"
                   href="{_premium_url_for('premium_course_admin_detail',
                                           course_id=c['id'])}">
                   Manage
                </a>

                <form method="post"
                      action="{_premium_url_for('premium_course_admin_delete',
                                                course_id=c['id'])}"
                      style="display:inline;"
                      onsubmit="return confirm('Delete this course?');">
                    <button class="btn btn-danger" type="submit">Delete</button>
                </form>
            </td>
        </tr>
        """

    return _premium_page(
        "Premium Course Admin",
        f"""
        <div class="card">
            <h1>Premium Course Management</h1>

            <a class="btn btn-success"
               href="{_premium_url_for('premium_course_admin_create')}">
               + Add Premium Course
            </a>
        </div>

        <div class="card table-wrap">
            <table>
                <tr>
                    <th>ID</th>
                    <th>Course</th>
                    <th>Category</th>
                    <th>Fee</th>
                    <th>Files</th>
                    <th>Status</th>
                    <th>Actions</th>
                </tr>
                {rows}
            </table>
        </div>
        """
    )

@app.route("/premium-courses/admin/create", methods=["GET", "POST"])
def premium_course_admin_create():
    if not _premium_admin_required():
        return _premium_redirect(_premium_url_for("login"))

    if _premium_request.method == "POST":
        title = _premium_request.form.get("title", "").strip()
        category = _premium_request.form.get("category", "General").strip()
        description = _premium_request.form.get("description", "").strip()
        instructor = _premium_request.form.get("instructor", "").strip()
        duration = _premium_request.form.get("duration", "").strip()
        status = _premium_request.form.get("status", "Published").strip()

        try:
            price = float(_premium_request.form.get("price", "0") or 0)
        except ValueError:
            price = 0

        if not title:
            return _premium_page(
                "Add Premium Course",
                """
                <div class="card">
                    <h2>Course title is required.</h2>
                    <a class="btn" href="/premium-courses/admin/create">Back</a>
                </div>
                """
            )

        conn = _premium_db()
        cur = conn.execute("""
            INSERT INTO premium_courses
            (title, category, description, instructor, price, duration, status)
            VALUES (?, ?, ?, ?, ?, ?, ?)
        """, (
            title, category, description, instructor,
            price, duration, status
        ))

        course_id = cur.lastrowid
        conn.commit()
        conn.close()

        return _premium_redirect(
            _premium_url_for(
                "premium_course_admin_detail",
                course_id=course_id
            )
        )

    return _premium_page(
        "Add Premium Course",
        """
        <div class="card">
            <h1>Add Premium Course</h1>

            <form method="post">

                <label>Course Title</label>
                <input name="title" required>

                <label>Category</label>
                <input name="category" value="IELTS">

                <label>Instructor</label>
                <input name="instructor" value="Md Shakil Hossain">

                <label>Duration</label>
                <input name="duration" placeholder="8 Weeks">

                <label>Course Fee</label>
                <input name="price" type="number" step="0.01" value="0">

                <label>Status</label>
                <select name="status">
                    <option>Published</option>
                    <option>Draft</option>
                </select>

                <label>Description</label>
                <textarea name="description"
                          style="width:100%;min-height:150px;padding:10px;"></textarea>

                <button class="btn btn-success" type="submit">
                    Create Course
                </button>

                <a class="btn"
                   href="/premium-courses/admin">
                   Cancel
                </a>

            </form>
        </div>
        """
    )

@app.route("/premium-courses/admin/<int:course_id>")
def premium_course_admin_detail(course_id):
    if not _premium_admin_required():
        return _premium_redirect(_premium_url_for("login"))

    _premium_init_db()
    conn = _premium_db()

    course = conn.execute(
        "SELECT * FROM premium_courses WHERE id=?",
        (course_id,)
    ).fetchone()

    files = conn.execute("""
        SELECT *
        FROM premium_course_files
        WHERE course_id=?
        ORDER BY id DESC
    """, (course_id,)).fetchall()

    conn.close()

    if not course:
        return "Course not found", 404

    files_html = ""

    for f in files:
        files_html += f"""
        <tr>
            <td>{esc(f["original_name"])}</td>
            <td>{esc(f["file_type"])}</td>
            <td>
                <a class="btn btn-info"
                   href="{_premium_url_for('premium_course_file',
                                           file_id=f['id'])}">
                   Open
                </a>

                <form method="post"
                      action="{_premium_url_for(
                          'premium_course_admin_file_delete',
                          file_id=f['id']
                      )}"
                      style="display:inline;"
                      onsubmit="return confirm('Delete this file?');">
                    <button class="btn btn-danger" type="submit">
                        Delete
                    </button>
                </form>
            </td>
        </tr>
        """

    if not files_html:
        files_html = """
        <tr>
            <td colspan="3">No resources uploaded.</td>
        </tr>
        """

    return _premium_page(
        "Manage Premium Course",
        f"""
        <div class="card">
            <h1>{esc(course["title"])}</h1>
            <p>{esc(course["description"] or "")}</p>
        </div>

        <div class="card">
            <h2>Upload Course Resource</h2>

            <form method="post"
                  enctype="multipart/form-data"
                  action="{_premium_url_for(
                      'premium_course_admin_upload',
                      course_id=course_id
                  )}">

                <input type="file"
                       name="file"
                       required>

                <button class="btn btn-success" type="submit">
                    Upload File
                </button>
            </form>

            <p>
                Allowed:
                PDF, DOC, DOCX, PPT, PPTX, XLS, XLSX, CSV,
                MP4, WEBM, JPG, JPEG, PNG
            </p>
        </div>

        <div class="card table-wrap">
            <h2>Uploaded Resources</h2>

            <table>
                <tr>
                    <th>File</th>
                    <th>Type</th>
                    <th>Action</th>
                </tr>
                {files_html}
            </table>
        </div>

        <a class="btn"
           href="/premium-courses/admin">
           â† Back to Courses
        </a>
        """
    )

@app.route("/premium-courses/admin/upload/<int:course_id>",
           methods=["POST"])
def premium_course_admin_upload(course_id):
    if not _premium_admin_required():
        return _premium_redirect(_premium_url_for("login"))

    file = _premium_request.files.get("file")

    if not file or not file.filename:
        return "No file selected", 400

    original = file.filename
    safe = _premium_secure_filename(original)

    if not safe:
        return "Invalid filename", 400

    ext = safe.rsplit(".", 1)[-1].lower() if "." in safe else ""

    if ext not in _PREMIUM_ALLOWED:
        return f"File type .{ext} is not allowed.", 400

    _premium_init_db()

    conn = _premium_db()
    course = conn.execute(
        "SELECT id FROM premium_courses WHERE id=?",
        (course_id,)
    ).fetchone()

    if not course:
        conn.close()
        return "Course not found", 404

    import uuid as _premium_uuid

    stored = (
        _premium_uuid.uuid4().hex
        + "_"
        + safe
    )

    file.save(str(_PREMIUM_UPLOAD_DIR / stored))

    conn.execute("""
        INSERT INTO premium_course_files
        (course_id, original_name, stored_name, file_type)
        VALUES (?, ?, ?, ?)
    """, (
        course_id,
        original,
        stored,
        ext
    ))

    conn.commit()
    conn.close()

    return _premium_redirect(
        _premium_url_for(
            "premium_course_admin_detail",
            course_id=course_id
        )
    )

@app.route("/premium-courses/admin/file-delete/<int:file_id>",
           methods=["POST"])
def premium_course_admin_file_delete(file_id):
    if not _premium_admin_required():
        return _premium_redirect(_premium_url_for("login"))

    _premium_init_db()
    conn = _premium_db()

    f = conn.execute(
        "SELECT * FROM premium_course_files WHERE id=?",
        (file_id,)
    ).fetchone()

    if not f:
        conn.close()
        return "File not found", 404

    course_id = f["course_id"]

    try:
        (_PREMIUM_UPLOAD_DIR / f["stored_name"]).unlink(
            missing_ok=True
        )
    except Exception:
        pass

    conn.execute(
        "DELETE FROM premium_course_files WHERE id=?",
        (file_id,)
    )

    conn.commit()
    conn.close()

    return _premium_redirect(
        _premium_url_for(
            "premium_course_admin_detail",
            course_id=course_id
        )
    )

@app.route("/premium-courses/admin/delete/<int:course_id>",
           methods=["POST"])
def premium_course_admin_delete(course_id):
    if not _premium_admin_required():
        return _premium_redirect(_premium_url_for("login"))

    _premium_init_db()
    conn = _premium_db()

    files = conn.execute("""
        SELECT stored_name
        FROM premium_course_files
        WHERE course_id=?
    """, (course_id,)).fetchall()

    for f in files:
        try:
            (_PREMIUM_UPLOAD_DIR / f["stored_name"]).unlink(
                missing_ok=True
            )
        except Exception:
            pass

    conn.execute(
        "DELETE FROM premium_course_files WHERE course_id=?",
        (course_id,)
    )

    conn.execute(
        "DELETE FROM premium_courses WHERE id=?",
        (course_id,)
    )

    conn.commit()
    conn.close()

    return _premium_redirect(
        _premium_url_for("premium_courses_admin")
    )

# ===== END SHAKIL AI PREMIUM COURSES V1 =====


# ===== SHAKIL AI PREMIUM COURSES V2 =====

def _premium_v2_init_db():
    conn = _premium_db()

    conn.execute("""
        CREATE TABLE IF NOT EXISTS premium_enrollments (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            course_id INTEGER NOT NULL,
            username TEXT NOT NULL,
            status TEXT DEFAULT 'Active',
            enrolled_at TEXT DEFAULT CURRENT_TIMESTAMP,
            UNIQUE(course_id, username)
        )
    """)

    conn.execute("""
        CREATE TABLE IF NOT EXISTS premium_progress (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            enrollment_id INTEGER NOT NULL,
            resource_id INTEGER,
            completed INTEGER DEFAULT 0,
            completed_at TEXT,
            UNIQUE(enrollment_id, resource_id)
        )
    """)

    conn.commit()
    conn.close()

_premium_v2_init_db()


@app.route("/premium-courses/enroll/<int:course_id>", methods=["POST"])
def premium_course_enroll(course_id):
    if not session.get("username"):
        return _premium_redirect(_premium_url_for("login"))

    _premium_v2_init_db()

    username = str(session.get("username"))

    conn = _premium_db()

    course = conn.execute(
        "SELECT id FROM premium_courses WHERE id=? AND status='Published'",
        (course_id,)
    ).fetchone()

    if not course:
        conn.close()
        return "Course not found", 404

    conn.execute("""
        INSERT OR IGNORE INTO premium_enrollments
        (course_id, username, status)
        VALUES (?, ?, 'Active')
    """, (course_id, username))

    conn.commit()
    conn.close()

    return _premium_redirect(
        _premium_url_for(
            "premium_my_courses"
        )
    )


@app.route("/my-premium-courses")
def premium_my_courses():
    if not session.get("username"):
        return _premium_redirect(_premium_url_for("login"))

    _premium_v2_init_db()

    username = str(session.get("username"))

    conn = _premium_db()

    rows = conn.execute("""
        SELECT
            e.id AS enrollment_id,
            e.status AS enrollment_status,
            e.enrolled_at,
            c.*
        FROM premium_enrollments e
        JOIN premium_courses c
          ON c.id=e.course_id
        WHERE e.username=?
        ORDER BY e.id DESC
    """, (username,)).fetchall()

    cards = ""

    for row in rows:

        total = conn.execute("""
            SELECT COUNT(*)
            FROM premium_course_files
            WHERE course_id=?
        """, (row["id"],)).fetchone()[0]

        completed = conn.execute("""
            SELECT COUNT(*)
            FROM premium_progress p
            JOIN premium_course_files f
              ON f.id=p.resource_id
            WHERE p.enrollment_id=?
              AND p.completed=1
              AND f.course_id=?
        """, (
            row["enrollment_id"],
            row["id"]
        )).fetchone()[0]

        progress = 0

        if total:
            progress = round((completed / total) * 100)

        cards += f"""
        <div class="card">
            <h2>{esc(row["title"])}</h2>

            <p>
                <strong>Category:</strong>
                {esc(row["category"] or "")}
            </p>

            <p>
                <strong>Status:</strong>
                {esc(row["enrollment_status"] or "")}
            </p>

            <div style="
                background:#e5e7eb;
                border-radius:10px;
                height:16px;
                overflow:hidden;
                margin:15px 0;
            ">
                <div style="
                    width:{progress}%;
                    height:100%;
                    background:#2563eb;
                "></div>
            </div>

            <p>
                <strong>Progress:</strong> {progress}%
            </p>

            <a class="btn btn-info"
               href="{_premium_url_for(
                   'premium_my_course_detail',
                   enrollment_id=row['enrollment_id']
               )}">
               Open Course
            </a>
        </div>
        """

    conn.close()

    if not cards:
        cards = """
        <div class="card">
            <h2>No Enrolled Courses</h2>
            <p>You have not enrolled in any premium course yet.</p>
            <a class="btn btn-info"
               href="/premium-courses">
               Browse Premium Courses
            </a>
        </div>
        """

    return _premium_page(
        "My Premium Courses",
        f"""
        <div class="card">
            <h1>My Premium Courses</h1>
            <p>Welcome, {esc(username)}</p>
        </div>

        <div class="grid">
            {cards}
        </div>
        """
    )


@app.route("/my-premium-courses/<int:enrollment_id>")
def premium_my_course_detail(enrollment_id):
    if not session.get("username"):
        return _premium_redirect(_premium_url_for("login"))

    _premium_v2_init_db()

    username = str(session.get("username"))

    conn = _premium_db()

    enrollment = conn.execute("""
        SELECT
            e.*,
            c.title,
            c.description,
            c.category,
            c.instructor,
            c.duration
        FROM premium_enrollments e
        JOIN premium_courses c
          ON c.id=e.course_id
        WHERE e.id=?
          AND e.username=?
    """, (
        enrollment_id,
        username
    )).fetchone()

    if not enrollment:
        conn.close()
        return "Enrollment not found", 404

    resources = conn.execute("""
        SELECT *
        FROM premium_course_files
        WHERE course_id=?
        ORDER BY id
    """, (enrollment["course_id"],)).fetchall()

    items = ""

    for r in resources:

        p = conn.execute("""
            SELECT completed
            FROM premium_progress
            WHERE enrollment_id=?
              AND resource_id=?
        """, (
            enrollment_id,
            r["id"]
        )).fetchone()

        completed = bool(p["completed"]) if p else False

        status = "Completed" if completed else "Not completed"

        action = ""

        if completed:
            action = """
            <span style="color:#218c74;font-weight:700;">
                âœ“ Completed
            </span>
            """
        else:
            action = f"""
            <form method="post"
                  action="{_premium_url_for(
                      'premium_mark_resource_complete',
                      enrollment_id=enrollment_id,
                      resource_id=r['id']
                  )}">
                <button class="btn btn-success" type="submit">
                    Mark Complete
                </button>
            </form>
            """

        items += f"""
        <tr>
            <td>{esc(r["original_name"])}</td>
            <td>{esc(r["file_type"])}</td>
            <td>{status}</td>
            <td>
                <a class="btn btn-info"
                   href="{_premium_url_for(
                       'premium_course_file',
                       file_id=r['id']
                   )}">
                   Open
                </a>
                {action}
            </td>
        </tr>
        """

    total = len(resources)

    completed_count = conn.execute("""
        SELECT COUNT(*)
        FROM premium_progress
        WHERE enrollment_id=?
          AND completed=1
    """, (enrollment_id,)).fetchone()[0]

    progress = round(
        (completed_count / total) * 100
    ) if total else 0

    conn.close()

    return _premium_page(
        enrollment["title"],
        f"""
        <div class="card">
            <h1>{esc(enrollment["title"])}</h1>

            <p>{esc(enrollment["description"] or "")}</p>

            <p>
                <strong>Instructor:</strong>
                {esc(enrollment["instructor"] or "")}
            </p>

            <p>
                <strong>Duration:</strong>
                {esc(enrollment["duration"] or "")}
            </p>

            <div style="
                background:#e5e7eb;
                border-radius:10px;
                height:18px;
                overflow:hidden;
                margin:18px 0;
            ">
                <div style="
                    width:{progress}%;
                    height:100%;
                    background:#218c74;
                "></div>
            </div>

            <h2>Course Progress: {progress}%</h2>
        </div>

        <div class="card table-wrap">
            <h2>Course Resources</h2>

            <table>
                <tr>
                    <th>Resource</th>
                    <th>Type</th>
                    <th>Status</th>
                    <th>Action</th>
                </tr>

                {items}
            </table>
        </div>

        <a class="btn"
           href="/my-premium-courses">
           â† My Courses
        </a>
        """
    )


@app.route(
    "/my-premium-courses/<int:enrollment_id>/complete/<int:resource_id>",
    methods=["POST"]
)
def premium_mark_resource_complete(
    enrollment_id,
    resource_id
):
    if not session.get("username"):
        return _premium_redirect(_premium_url_for("login"))

    _premium_v2_init_db()

    username = str(session.get("username"))

    conn = _premium_db()

    valid = conn.execute("""
        SELECT e.id
        FROM premium_enrollments e
        JOIN premium_course_files f
          ON f.course_id=e.course_id
        WHERE e.id=?
          AND e.username=?
          AND f.id=?
    """, (
        enrollment_id,
        username,
        resource_id
    )).fetchone()

    if not valid:
        conn.close()
        return "Invalid enrollment/resource", 403

    conn.execute("""
        INSERT INTO premium_progress
        (enrollment_id, resource_id, completed, completed_at)
        VALUES (?, ?, 1, CURRENT_TIMESTAMP)
        ON CONFLICT(enrollment_id, resource_id)
        DO UPDATE SET
            completed=1,
            completed_at=CURRENT_TIMESTAMP
    """, (
        enrollment_id,
        resource_id
    ))

    conn.commit()
    conn.close()

    return _premium_redirect(
        _premium_url_for(
            "premium_my_course_detail",
            enrollment_id=enrollment_id
        )
    )


@app.route("/premium-courses/admin/enrollments")
def premium_admin_enrollments():
    if not _premium_admin_required():
        return _premium_redirect(_premium_url_for("login"))

    _premium_v2_init_db()

    conn = _premium_db()

    rows = conn.execute("""
        SELECT
            e.id,
            e.username,
            e.status,
            e.enrolled_at,
            c.title,
            (
                SELECT COUNT(*)
                FROM premium_course_files f
                WHERE f.course_id=c.id
            ) AS total_resources,
            (
                SELECT COUNT(*)
                FROM premium_progress p
                JOIN premium_course_files f2
                  ON f2.id=p.resource_id
                WHERE p.enrollment_id=e.id
                  AND p.completed=1
                  AND f2.course_id=c.id
            ) AS completed_resources
        FROM premium_enrollments e
        JOIN premium_courses c
          ON c.id=e.course_id
        ORDER BY e.id DESC
    """).fetchall()

    conn.close()

    rows_html = ""

    for r in rows:

        total = r["total_resources"] or 0
        completed = r["completed_resources"] or 0

        progress = round(
            completed / total * 100
        ) if total else 0

        rows_html += f"""
        <tr>
            <td>{r["id"]}</td>
            <td>{esc(r["username"])}</td>
            <td>{esc(r["title"])}</td>
            <td>{esc(r["status"])}</td>
            <td>{progress}%</td>
            <td>{esc(r["enrolled_at"])}</td>
        </tr>
        """

    return _premium_page(
        "Premium Enrollment Management",
        f"""
        <div class="card">
            <h1>Premium Enrollment Management</h1>
            <p>Student enrollment and progress overview.</p>
        </div>

        <div class="card table-wrap">
            <table>
                <tr>
                    <th>ID</th>
                    <th>Student</th>
                    <th>Course</th>
                    <th>Status</th>
                    <th>Progress</th>
                    <th>Enrolled</th>
                </tr>

                {rows_html}
            </table>
        </div>

        <a class="btn"
           href="/premium-courses/admin">
           â† Course Admin
        </a>
        """
    )


# ===== SHAKIL AI PREMIUM COURSES V3 =====

def _premium_v3_init_db():
    conn = _premium_db()

    conn.execute("""
        CREATE TABLE IF NOT EXISTS premium_certificates (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            enrollment_id INTEGER NOT NULL UNIQUE,
            username TEXT NOT NULL,
            course_id INTEGER NOT NULL,
            certificate_code TEXT NOT NULL UNIQUE,
            issued_at TEXT NOT NULL
        )
    """)

    conn.commit()
    conn.close()


@app.route("/my-premium-courses/<int:enrollment_id>/certificate")
def premium_certificate(enrollment_id):
    if "username" not in session:
        return _premium_redirect(_premium_url_for("login"))

    _premium_v2_init_db()
    _premium_v3_init_db()

    username = session.get("username")

    conn = _premium_db()

    enrollment = conn.execute("""
        SELECT
            e.id,
            e.username,
            e.course_id,
            e.status,
            c.title
        FROM premium_enrollments e
        JOIN premium_courses c ON c.id=e.course_id
        WHERE e.id=? AND e.username=?
    """, (enrollment_id, username)).fetchone()

    if not enrollment:
        conn.close()
        return "Enrollment not found", 404

    total = conn.execute("""
        SELECT COUNT(*)
        FROM premium_course_files
        WHERE course_id=?
    """, (enrollment["course_id"],)).fetchone()[0]

    completed = conn.execute("""
        SELECT COUNT(*)
        FROM premium_progress p
        JOIN premium_course_files f ON f.id=p.resource_id
        WHERE p.enrollment_id=? AND p.completed=1
    """, (enrollment_id,)).fetchone()[0]

    if total == 0 or completed < total:
        conn.close()
        return "Course is not completed yet.", 403

    certificate = conn.execute("""
        SELECT certificate_code, issued_at
        FROM premium_certificates
        WHERE enrollment_id=?
    """, (enrollment_id,)).fetchone()

    if not certificate:
        import uuid

        code = "EWA-" + uuid.uuid4().hex[:10].upper()
        issued_at = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

        conn.execute("""
            INSERT INTO premium_certificates
            (enrollment_id, username, course_id, certificate_code, issued_at)
            VALUES (?, ?, ?, ?, ?)
        """, (
            enrollment_id,
            username,
            enrollment["course_id"],
            code,
            issued_at
        ))

        conn.commit()

        certificate = {
            "certificate_code": code,
            "issued_at": issued_at
        }

    conn.close()

    html = f"""
    <div class="card" style="max-width:850px;margin:30px auto;text-align:center;
        border:8px solid #1e3a8a;padding:55px 35px;background:#fff;">

        <div style="font-size:14px;letter-spacing:3px;font-weight:800;color:#1e3a8a;">
            ENGLISH WINGS ACADEMY
        </div>

        <h1 style="font-size:42px;margin:20px 0 8px;color:#111827;">
            Certificate of Completion
        </h1>

        <p style="font-size:18px;color:#64748b;">
            This certificate is proudly presented to
        </p>

        <h2 style="font-size:32px;margin:22px 0;color:#111827;">
            {esc(username)}
        </h2>

        <p style="font-size:18px;">
            for successfully completing
        </p>

        <h2 style="font-size:25px;color:#1e3a8a;">
            {esc(enrollment["title"])}
        </h2>

        <p style="margin-top:35px;">
            Certificate Code:
            <strong>{esc(certificate["certificate_code"])}</strong>
        </p>

        <p style="color:#64748b;">
            Issued: {esc(certificate["issued_at"])}
        </p>

        <button class="btn no-print" onclick="window.print()">
            Print Certificate
        </button>
    </div>
    """

    return page("Certificate", html)


@app.route("/premium-courses/admin/certificate/<int:enrollment_id>")
def premium_admin_certificate(enrollment_id):
    if not _premium_admin_required():
        return _premium_redirect(_premium_url_for("login"))

    return premium_certificate(enrollment_id)


# ===== END SHAKIL AI PREMIUM COURSES V3 =====

# ===== SHAKIL AI PREMIUM COURSES V4 =====

def _premium_v4_init_db():
    conn = _premium_db()

    conn.execute("""
        CREATE TABLE IF NOT EXISTS premium_modules (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            course_id INTEGER NOT NULL,
            title TEXT NOT NULL,
            description TEXT DEFAULT '',
            sort_order INTEGER DEFAULT 0,
            created_at TEXT NOT NULL
        )
    """)

    conn.execute("""
        CREATE TABLE IF NOT EXISTS premium_lessons (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            module_id INTEGER NOT NULL,
            title TEXT NOT NULL,
            lesson_type TEXT DEFAULT 'text',
            content TEXT DEFAULT '',
            video_url TEXT DEFAULT '',
            resource_id INTEGER,
            sort_order INTEGER DEFAULT 0,
            created_at TEXT NOT NULL
        )
    """)

    conn.commit()
    conn.close()


@app.route("/premium-courses/admin/<int:course_id>/modules", methods=["GET", "POST"])
def premium_admin_modules(course_id):
    if not _premium_admin_required():
        return _premium_redirect(_premium_url_for("login"))

    _premium_v2_init_db()
    _premium_v4_init_db()

    conn = _premium_db()
    course = conn.execute(
        "SELECT * FROM premium_courses WHERE id=?",
        (course_id,)
    ).fetchone()

    if not course:
        conn.close()
        return "Course not found", 404

    if request.method == "POST":
        title = request.form.get("title", "").strip()
        description = request.form.get("description", "").strip()
        sort_order = int(request.form.get("sort_order", "0") or 0)

        if title:
            conn.execute("""
                INSERT INTO premium_modules
                (course_id,title,description,sort_order,created_at)
                VALUES (?,?,?,?,?)
            """, (
                course_id,
                title,
                description,
                sort_order,
                datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            ))
            conn.commit()

        conn.close()
        return _premium_redirect(
            _premium_url_for("premium_admin_modules", course_id=course_id)
        )

    modules = conn.execute("""
        SELECT *
        FROM premium_modules
        WHERE course_id=?
        ORDER BY sort_order,id
    """, (course_id,)).fetchall()

    conn.close()

    rows = "".join(
        f"""
        <tr>
          <td>{m['sort_order']}</td>
          <td><strong>{m['title']}</strong><br>{m['description'] or ''}</td>
          <td>
            <a class="btn" href="/premium-courses/admin/module/{m['id']}/lessons">
              Lessons
            </a>
            <form method="post"
                  action="/premium-courses/admin/module/{m['id']}/delete"
                  style="display:inline"
                  onsubmit="return confirm('Delete this module and its lessons?')">
              <button class="btn" type="submit">Delete</button>
            </form>
          </td>
        </tr>
        """
        for m in modules
    )

    html = f"""
    <div class="card">
      <h2>Manage Modules — {course['title']}</h2>

      <form method="post">
        <p><label>Module Title</label>
        <input name="title" required></p>

        <p><label>Description</label>
        <textarea name="description" rows="3"></textarea></p>

        <p><label>Order</label>
        <input type="number" name="sort_order" value="0"></p>

        <button class="btn" type="submit">Add Module</button>
      </form>
    </div>

    <div class="card">
      <h2>Modules</h2>
      <div class="table-wrap">
        <table>
          <tr>
            <th>Order</th>
            <th>Module</th>
            <th>Actions</th>
          </tr>
          {rows or '<tr><td colspan="3">No modules yet.</td></tr>'}
        </table>
      </div>
    </div>
    """

    return page("Course Modules", html)


@app.route("/premium-courses/admin/module/<int:module_id>/delete", methods=["POST"])
def premium_admin_module_delete(module_id):
    if not _premium_admin_required():
        return _premium_redirect(_premium_url_for("login"))

    _premium_v2_init_db()
    _premium_v4_init_db()

    conn = _premium_db()

    module = conn.execute(
        "SELECT course_id FROM premium_modules WHERE id=?",
        (module_id,)
    ).fetchone()

    if not module:
        conn.close()
        return "Module not found", 404

    conn.execute(
        "DELETE FROM premium_lessons WHERE module_id=?",
        (module_id,)
    )
    conn.execute(
        "DELETE FROM premium_modules WHERE id=?",
        (module_id,)
    )
    conn.commit()
    conn.close()

    return _premium_redirect(
        _premium_url_for(
            "premium_admin_modules",
            course_id=module["course_id"]
        )
    )


@app.route("/premium-courses/admin/module/<int:module_id>/lessons", methods=["GET", "POST"])
def premium_admin_lessons(module_id):
    if not _premium_admin_required():
        return _premium_redirect(_premium_url_for("login"))

    _premium_v2_init_db()
    _premium_v4_init_db()

    conn = _premium_db()

    module = conn.execute("""
        SELECT m.*,c.title AS course_title
        FROM premium_modules m
        JOIN premium_courses c ON c.id=m.course_id
        WHERE m.id=?
    """, (module_id,)).fetchone()

    if not module:
        conn.close()
        return "Module not found", 404

    if request.method == "POST":
        title = request.form.get("title", "").strip()
        lesson_type = request.form.get("lesson_type", "text").strip()
        content = request.form.get("content", "").strip()
        video_url = request.form.get("video_url", "").strip()
        sort_order = int(request.form.get("sort_order", "0") or 0)

        if title:
            conn.execute("""
                INSERT INTO premium_lessons
                (module_id,title,lesson_type,content,video_url,sort_order,created_at)
                VALUES (?,?,?,?,?,?,?)
            """, (
                module_id,
                title,
                lesson_type,
                content,
                video_url,
                sort_order,
                datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            ))
            conn.commit()

        conn.close()
        return _premium_redirect(
            _premium_url_for(
                "premium_admin_lessons",
                module_id=module_id
            )
        )

    lessons = conn.execute("""
        SELECT *
        FROM premium_lessons
        WHERE module_id=?
        ORDER BY sort_order,id
    """, (module_id,)).fetchall()

    conn.close()

    rows = "".join(
        f"""
        <tr>
          <td>{l['sort_order']}</td>
          <td>
            <strong>{l['title']}</strong><br>
            Type: {l['lesson_type']}
          </td>
          <td>
            <form method="post"
                  action="/premium-courses/admin/lesson/{l['id']}/delete"
                  onsubmit="return confirm('Delete this lesson?')">
              <button class="btn" type="submit">Delete</button>
            </form>
          </td>
        </tr>
        """
        for l in lessons
    )

    html = f"""
    <div class="card">
      <h2>{module['course_title']} → {module['title']}</h2>

      <form method="post">

        <p><label>Lesson Title</label>
        <input name="title" required></p>

        <p><label>Lesson Type</label>
        <select name="lesson_type">
          <option value="text">Text</option>
          <option value="video">Video</option>
          <option value="resource">Resource</option>
        </select></p>

        <p><label>Lesson Content</label>
        <textarea name="content" rows="8"
                  placeholder="Write lesson content here..."></textarea></p>

        <p><label>Video URL</label>
        <input name="video_url"
               placeholder="Optional YouTube/video URL"></p>

        <p><label>Order</label>
        <input type="number" name="sort_order" value="0"></p>

        <button class="btn" type="submit">Add Lesson</button>
      </form>
    </div>

    <div class="card">
      <h2>Lessons</h2>
      <div class="table-wrap">
        <table>
          <tr>
            <th>Order</th>
            <th>Lesson</th>
            <th>Action</th>
          </tr>
          {rows or '<tr><td colspan="3">No lessons yet.</td></tr>'}
        </table>
      </div>
    </div>
    """

    return page("Course Lessons", html)


@app.route("/premium-courses/admin/lesson/<int:lesson_id>/delete", methods=["POST"])
def premium_admin_lesson_delete(lesson_id):
    if not _premium_admin_required():
        return _premium_redirect(_premium_url_for("login"))

    _premium_v2_init_db()
    _premium_v4_init_db()

    conn = _premium_db()

    lesson = conn.execute("""
        SELECT m.id AS module_id
        FROM premium_lessons l
        JOIN premium_modules m ON m.id=l.module_id
        WHERE l.id=?
    """, (lesson_id,)).fetchone()

    if not lesson:
        conn.close()
        return "Lesson not found", 404

    conn.execute(
        "DELETE FROM premium_lessons WHERE id=?",
        (lesson_id,)
    )
    conn.commit()
    conn.close()

    return _premium_redirect(
        _premium_url_for(
            "premium_admin_lessons",
            module_id=lesson["module_id"]
        )
    )


@app.route("/my-premium-courses/<int:enrollment_id>/lesson/<int:lesson_id>")
def premium_student_lesson(enrollment_id, lesson_id):
    if "username" not in session:
        return _premium_redirect(_premium_url_for("login"))

    _premium_v2_init_db()
    _premium_v4_init_db()

    username = session.get("username")
    conn = _premium_db()

    enrollment = conn.execute("""
        SELECT e.*,c.title AS course_title
        FROM premium_enrollments e
        JOIN premium_courses c ON c.id=e.course_id
        WHERE e.id=? AND e.username=?
    """, (enrollment_id, username)).fetchone()

    if not enrollment:
        conn.close()
        return "Enrollment not found", 404

    lesson = conn.execute("""
        SELECT l.*,m.title AS module_title,m.course_id
        FROM premium_lessons l
        JOIN premium_modules m ON m.id=l.module_id
        WHERE l.id=? AND m.course_id=?
    """, (lesson_id, enrollment["course_id"])).fetchone()

    if not lesson:
        conn.close()
        return "Lesson not found", 404

    conn.close()

    video = ""
    if lesson["video_url"]:
        video = f"""
        <p>
          <a class="btn" href="{lesson['video_url']}" target="_blank">
            Open Video
          </a>
        </p>
        """

    html = f"""
    <div class="card">
      <p><strong>{enrollment['course_title']}</strong></p>
      <p>Module: {lesson['module_title']}</p>
      <h1>{lesson['title']}</h1>
      <hr>
      <div style="white-space:pre-wrap;line-height:1.8">
        {lesson['content']}
      </div>
      {video}
    </div>
    """

    return page("Premium Lesson", html)


# ===== END SHAKIL AI PREMIUM COURSES V4 =====

# ===== SHAKIL AI PREMIUM COURSES V5 =====

def _premium_v5_init_db():
    conn = _premium_db()

    conn.execute("""
        CREATE TABLE IF NOT EXISTS premium_tests (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            module_id INTEGER NOT NULL,
            title TEXT NOT NULL,
            description TEXT DEFAULT '',
            duration_minutes INTEGER DEFAULT 30,
            pass_percentage REAL DEFAULT 50,
            created_at TEXT NOT NULL
        )
    """)

    conn.execute("""
        CREATE TABLE IF NOT EXISTS premium_test_questions (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            test_id INTEGER NOT NULL,
            question TEXT NOT NULL,
            option_a TEXT NOT NULL,
            option_b TEXT NOT NULL,
            option_c TEXT NOT NULL,
            option_d TEXT NOT NULL,
            correct_option TEXT NOT NULL,
            marks INTEGER DEFAULT 1,
            sort_order INTEGER DEFAULT 0,
            created_at TEXT NOT NULL
        )
    """)

    conn.execute("""
        CREATE TABLE IF NOT EXISTS premium_test_attempts (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            test_id INTEGER NOT NULL,
            enrollment_id INTEGER NOT NULL,
            username TEXT NOT NULL,
            score REAL DEFAULT 0,
            total_marks REAL DEFAULT 0,
            percentage REAL DEFAULT 0,
            passed INTEGER DEFAULT 0,
            started_at TEXT NOT NULL,
            submitted_at TEXT NOT NULL
        )
    """)

    conn.execute("""
        CREATE TABLE IF NOT EXISTS premium_test_answers (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            attempt_id INTEGER NOT NULL,
            question_id INTEGER NOT NULL,
            selected_option TEXT DEFAULT '',
            is_correct INTEGER DEFAULT 0,
            marks_awarded REAL DEFAULT 0
        )
    """)

    conn.commit()
    conn.close()


@app.route("/premium-courses/admin/module/<int:module_id>/tests", methods=["GET", "POST"])
def premium_admin_tests(module_id):
    if not _premium_admin_required():
        return _premium_redirect(_premium_url_for("login"))

    _premium_v2_init_db()
    _premium_v4_init_db()
    _premium_v5_init_db()

    conn = _premium_db()

    module = conn.execute("""
        SELECT m.*, c.title AS course_title
        FROM premium_modules m
        JOIN premium_courses c ON c.id=m.course_id
        WHERE m.id=?
    """, (module_id,)).fetchone()

    if not module:
        conn.close()
        return "Module not found", 404

    if request.method == "POST":
        title = request.form.get("title", "").strip()
        description = request.form.get("description", "").strip()

        try:
            duration = int(request.form.get("duration_minutes", "30") or 30)
        except ValueError:
            duration = 30

        try:
            pass_percentage = float(
                request.form.get("pass_percentage", "50") or 50
            )
        except ValueError:
            pass_percentage = 50

        duration = max(1, duration)
        pass_percentage = min(100, max(0, pass_percentage))

        if title:
            conn.execute("""
                INSERT INTO premium_tests
                (module_id,title,description,duration_minutes,pass_percentage,created_at)
                VALUES (?,?,?,?,?,?)
            """, (
                module_id,
                title,
                description,
                duration,
                pass_percentage,
                datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            ))
            conn.commit()

        conn.close()

        return _premium_redirect(
            _premium_url_for(
                "premium_admin_tests",
                module_id=module_id
            )
        )

    tests = conn.execute("""
        SELECT
            t.*,
            COUNT(q.id) AS question_count
        FROM premium_tests t
        LEFT JOIN premium_test_questions q
            ON q.test_id=t.id
        WHERE t.module_id=?
        GROUP BY t.id
        ORDER BY t.id
    """, (module_id,)).fetchall()

    conn.close()

    rows = ""

    for t in tests:
        rows += f"""
        <tr>
          <td>{t['id']}</td>
          <td><strong>{html.escape(t['title'])}</strong></td>
          <td>{t['duration_minutes']} min</td>
          <td>{t['question_count']}</td>
          <td>{t['pass_percentage']}%</td>
          <td>
            <a class="btn"
               href="/premium-courses/admin/test/{t['id']}/questions">
               Questions
            </a>

            <form method="post"
                  action="/premium-courses/admin/test/{t['id']}/delete"
                  style="display:inline"
                  onsubmit="return confirm('Delete this test and all questions?')">
              <button class="btn" type="submit">Delete</button>
            </form>
          </td>
        </tr>
        """

    html_content = f"""
    <div class="card">
      <h2>{html.escape(module['course_title'])} → {html.escape(module['title'])}</h2>

      <h3>Create Online Test</h3>

      <form method="post">

        <p>
          <label>Test Title</label>
          <input name="title" required>
        </p>

        <p>
          <label>Description</label>
          <textarea name="description" rows="4"></textarea>
        </p>

        <p>
          <label>Duration (minutes)</label>
          <input type="number"
                 name="duration_minutes"
                 value="30"
                 min="1"
                 max="300">
        </p>

        <p>
          <label>Pass Percentage</label>
          <input type="number"
                 name="pass_percentage"
                 value="50"
                 min="0"
                 max="100"
                 step="0.1">
        </p>

        <button class="btn" type="submit">
          Create Test
        </button>

      </form>
    </div>

    <div class="card">
      <h2>Online Tests</h2>

      <div class="table-wrap">
        <table>
          <tr>
            <th>ID</th>
            <th>Test</th>
            <th>Duration</th>
            <th>Questions</th>
            <th>Pass</th>
            <th>Actions</th>
          </tr>

          {rows or '<tr><td colspan="6">No tests created yet.</td></tr>'}
        </table>
      </div>
    </div>
    """

    return page("Online Tests", html_content)


@app.route("/premium-courses/admin/test/<int:test_id>/questions", methods=["GET", "POST"])
def premium_admin_test_questions(test_id):
    if not _premium_admin_required():
        return _premium_redirect(_premium_url_for("login"))

    _premium_v2_init_db()
    _premium_v4_init_db()
    _premium_v5_init_db()

    conn = _premium_db()

    test = conn.execute("""
        SELECT t.*, m.title AS module_title, m.course_id
        FROM premium_tests t
        JOIN premium_modules m ON m.id=t.module_id
        WHERE t.id=?
    """, (test_id,)).fetchone()

    if not test:
        conn.close()
        return "Test not found", 404

    if request.method == "POST":
        question = request.form.get("question", "").strip()
        option_a = request.form.get("option_a", "").strip()
        option_b = request.form.get("option_b", "").strip()
        option_c = request.form.get("option_c", "").strip()
        option_d = request.form.get("option_d", "").strip()
        correct_option = request.form.get("correct_option", "").strip().lower()

        try:
            marks = int(request.form.get("marks", "1") or 1)
        except ValueError:
            marks = 1

        try:
            sort_order = int(request.form.get("sort_order", "0") or 0)
        except ValueError:
            sort_order = 0

        if (
            question
            and option_a
            and option_b
            and option_c
            and option_d
            and correct_option in ("a", "b", "c", "d")
        ):
            conn.execute("""
                INSERT INTO premium_test_questions
                (
                    test_id,
                    question,
                    option_a,
                    option_b,
                    option_c,
                    option_d,
                    correct_option,
                    marks,
                    sort_order,
                    created_at
                )
                VALUES (?,?,?,?,?,?,?,?,?,?)
            """, (
                test_id,
                question,
                option_a,
                option_b,
                option_c,
                option_d,
                correct_option,
                max(1, marks),
                sort_order,
                datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            ))

            conn.commit()

        conn.close()

        return _premium_redirect(
            _premium_url_for(
                "premium_admin_test_questions",
                test_id=test_id
            )
        )

    questions = conn.execute("""
        SELECT *
        FROM premium_test_questions
        WHERE test_id=?
        ORDER BY sort_order,id
    """, (test_id,)).fetchall()

    conn.close()

    rows = ""

    for q in questions:
        rows += f"""
        <tr>
          <td>{q['id']}</td>
          <td>{html.escape(q['question'])}</td>
          <td>{q['correct_option'].upper()}</td>
          <td>{q['marks']}</td>
          <td>
            <form method="post"
                  action="/premium-courses/admin/question/{q['id']}/delete"
                  onsubmit="return confirm('Delete this question?')">
              <button class="btn" type="submit">Delete</button>
            </form>
          </td>
        </tr>
        """

    html_content = f"""
    <div class="card">
      <h2>
        {html.escape(test['module_title'])}
        → {html.escape(test['title'])}
      </h2>

      <p>
        Duration: <strong>{test['duration_minutes']} minutes</strong>
        &nbsp; | &nbsp;
        Pass: <strong>{test['pass_percentage']}%</strong>
      </p>

      <h3>Add Question</h3>

      <form method="post">

        <p>
          <label>Question</label>
          <textarea name="question" rows="4" required></textarea>
        </p>

        <p>
          <label>Option A</label>
          <input name="option_a" required>
        </p>

        <p>
          <label>Option B</label>
          <input name="option_b" required>
        </p>

        <p>
          <label>Option C</label>
          <input name="option_c" required>
        </p>

        <p>
          <label>Option D</label>
          <input name="option_d" required>
        </p>

        <p>
          <label>Correct Answer</label>
          <select name="correct_option" required>
            <option value="a">A</option>
            <option value="b">B</option>
            <option value="c">C</option>
            <option value="d">D</option>
          </select>
        </p>

        <p>
          <label>Marks</label>
          <input type="number"
                 name="marks"
                 value="1"
                 min="1"
                 max="100">
        </p>

        <p>
          <label>Order</label>
          <input type="number"
                 name="sort_order"
                 value="0">
        </p>

        <button class="btn" type="submit">
          Add Question
        </button>

      </form>
    </div>

    <div class="card">
      <h2>Questions</h2>

      <div class="table-wrap">
        <table>
          <tr>
            <th>ID</th>
            <th>Question</th>
            <th>Answer</th>
            <th>Marks</th>
            <th>Action</th>
          </tr>

          {rows or '<tr><td colspan="5">No questions yet.</td></tr>'}
        </table>
      </div>
    </div>
    """

    return page("Test Questions", html_content)


@app.route("/premium-courses/admin/question/<int:question_id>/delete", methods=["POST"])
def premium_admin_question_delete(question_id):
    if not _premium_admin_required():
        return _premium_redirect(_premium_url_for("login"))

    _premium_v2_init_db()
    _premium_v4_init_db()
    _premium_v5_init_db()

    conn = _premium_db()

    q = conn.execute("""
        SELECT test_id
        FROM premium_test_questions
        WHERE id=?
    """, (question_id,)).fetchone()

    if not q:
        conn.close()
        return "Question not found", 404

    conn.execute("""
        DELETE FROM premium_test_questions
        WHERE id=?
    """, (question_id,))

    conn.commit()
    conn.close()

    return _premium_redirect(
        _premium_url_for(
            "premium_admin_test_questions",
            test_id=q["test_id"]
        )
    )


@app.route("/premium-courses/admin/test/<int:test_id>/delete", methods=["POST"])
def premium_admin_test_delete(test_id):
    if not _premium_admin_required():
        return _premium_redirect(_premium_url_for("login"))

    _premium_v2_init_db()
    _premium_v4_init_db()
    _premium_v5_init_db()

    conn = _premium_db()

    test = conn.execute("""
        SELECT module_id
        FROM premium_tests
        WHERE id=?
    """, (test_id,)).fetchone()

    if not test:
        conn.close()
        return "Test not found", 404

    attempts = conn.execute("""
        SELECT id
        FROM premium_test_attempts
        WHERE test_id=?
    """, (test_id,)).fetchall()

    for attempt in attempts:
        conn.execute("""
            DELETE FROM premium_test_answers
            WHERE attempt_id=?
        """, (attempt["id"],))

    conn.execute("""
        DELETE FROM premium_test_attempts
        WHERE test_id=?
    """, (test_id,))

    conn.execute("""
        DELETE FROM premium_test_questions
        WHERE test_id=?
    """, (test_id,))

    conn.execute("""
        DELETE FROM premium_tests
        WHERE id=?
    """, (test_id,))

    conn.commit()
    conn.close()

    return _premium_redirect(
        _premium_url_for(
            "premium_admin_tests",
            module_id=test["module_id"]
        )
    )


@app.route("/my-premium-courses/<int:enrollment_id>/test/<int:test_id>")
def premium_student_test(enrollment_id, test_id):
    if "username" not in session:
        return _premium_redirect(_premium_url_for("login"))

    _premium_v2_init_db()
    _premium_v4_init_db()
    _premium_v5_init_db()

    username = session.get("username")

    conn = _premium_db()

    enrollment = conn.execute("""
        SELECT e.*, c.title AS course_title
        FROM premium_enrollments e
        JOIN premium_courses c ON c.id=e.course_id
        WHERE e.id=? AND e.username=?
    """, (enrollment_id, username)).fetchone()

    if not enrollment:
        conn.close()
        return "Enrollment not found", 404

    test = conn.execute("""
        SELECT
            t.*,
            m.title AS module_title,
            m.course_id
        FROM premium_tests t
        JOIN premium_modules m ON m.id=t.module_id
        WHERE t.id=? AND m.course_id=?
    """, (test_id, enrollment["course_id"])).fetchone()

    if not test:
        conn.close()
        return "Test not found", 404

    questions = conn.execute("""
        SELECT *
        FROM premium_test_questions
        WHERE test_id=?
        ORDER BY sort_order,id
    """, (test_id,)).fetchall()

    conn.close()

    if not questions:
        return page(
            "Online Test",
            """
            <div class="card">
              <h2>Test Not Ready</h2>
              <p>This test does not have any questions yet.</p>
            </div>
            """
        )

    question_html = ""

    for index, q in enumerate(questions, start=1):
        question_html += f"""
        <div class="card">
          <p>
            <strong>Question {index}</strong>
            ({q['marks']} mark{'s' if q['marks'] != 1 else ''})
          </p>

          <p>{html.escape(q['question'])}</p>

          <label>
            <input type="radio"
                   name="q_{q['id']}"
                   value="a"
                   required>
            A. {html.escape(q['option_a'])}
          </label>
          <br>

          <label>
            <input type="radio"
                   name="q_{q['id']}"
                   value="b">
            B. {html.escape(q['option_b'])}
          </label>
          <br>

          <label>
            <input type="radio"
                   name="q_{q['id']}"
                   value="c">
            C. {html.escape(q['option_c'])}
          </label>
          <br>

          <label>
            <input type="radio"
                   name="q_{q['id']}"
                   value="d">
            D. {html.escape(q['option_d'])}
          </label>
        </div>
        """

    html_content = f"""
    <div class="card">
      <h1>{html.escape(test['title'])}</h1>

      <p>
        Course: {html.escape(enrollment['course_title'])}
      </p>

      <p>
        Module: {html.escape(test['module_title'])}
      </p>

      <p>
        <strong>Duration:</strong>
        {test['duration_minutes']} minutes
      </p>

      <p>
        <strong>Pass mark:</strong>
        {test['pass_percentage']}%
      </p>
    </div>

    <form method="post"
          action="/my-premium-courses/{enrollment_id}/test/{test_id}/submit">

      {question_html}

      <div class="card">
        <button class="btn"
                type="submit"
                onclick="return confirm('Submit this test now?')">
          Submit Test
        </button>
      </div>

    </form>
    """

    return page("Online Test", html_content)


@app.route(
    "/my-premium-courses/<int:enrollment_id>/test/<int:test_id>/submit",
    methods=["POST"]
)
def premium_student_test_submit(enrollment_id, test_id):
    if "username" not in session:
        return _premium_redirect(_premium_url_for("login"))

    _premium_v2_init_db()
    _premium_v4_init_db()
    _premium_v5_init_db()

    username = session.get("username")

    conn = _premium_db()

    enrollment = conn.execute("""
        SELECT e.*, c.title AS course_title
        FROM premium_enrollments e
        JOIN premium_courses c ON c.id=e.course_id
        WHERE e.id=? AND e.username=?
    """, (enrollment_id, username)).fetchone()

    if not enrollment:
        conn.close()
        return "Enrollment not found", 404

    test = conn.execute("""
        SELECT
            t.*,
            m.title AS module_title,
            m.course_id
        FROM premium_tests t
        JOIN premium_modules m ON m.id=t.module_id
        WHERE t.id=? AND m.course_id=?
    """, (test_id, enrollment["course_id"])).fetchone()

    if not test:
        conn.close()
        return "Test not found", 404

    questions = conn.execute("""
        SELECT *
        FROM premium_test_questions
        WHERE test_id=?
        ORDER BY sort_order,id
    """, (test_id,)).fetchall()

    if not questions:
        conn.close()
        return "This test has no questions.", 400

    total_marks = 0
    score = 0

    answers = []

    for q in questions:
        selected = request.form.get(
            f"q_{q['id']}",
            ""
        ).strip().lower()

        marks = float(q["marks"] or 1)
        total_marks += marks

        is_correct = (
            1
            if selected and selected == q["correct_option"].lower()
            else 0
        )

        awarded = marks if is_correct else 0
        score += awarded

        answers.append((
            q["id"],
            selected,
            is_correct,
            awarded
        ))

    percentage = (
        (score / total_marks) * 100
        if total_marks > 0
        else 0
    )

    passed = (
        1
        if percentage >= float(test["pass_percentage"] or 50)
        else 0
    )

    now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

    cursor = conn.execute("""
        INSERT INTO premium_test_attempts
        (
            test_id,
            enrollment_id,
            username,
            score,
            total_marks,
            percentage,
            passed,
            started_at,
            submitted_at
        )
        VALUES (?,?,?,?,?,?,?,?,?)
    """, (
        test_id,
        enrollment_id,
        username,
        score,
        total_marks,
        percentage,
        passed,
        now,
        now
    ))

    attempt_id = cursor.lastrowid

    for question_id, selected, is_correct, awarded in answers:
        conn.execute("""
            INSERT INTO premium_test_answers
            (
                attempt_id,
                question_id,
                selected_option,
                is_correct,
                marks_awarded
            )
            VALUES (?,?,?,?,?)
        """, (
            attempt_id,
            question_id,
            selected,
            is_correct,
            awarded
        ))

    conn.commit()
    conn.close()

    result_word = "PASSED" if passed else "NOT PASSED"

    result_class = (
        "color:#15803d;"
        if passed
        else "color:#b91c1c;"
    )

    html_content = f"""
    <div class="card" style="text-align:center">

      <h1>Test Result</h1>

      <h2 style="{result_class}">
        {result_word}
      </h2>

      <p>
        <strong>Score:</strong>
        {score:g} / {total_marks:g}
      </p>

      <p>
        <strong>Percentage:</strong>
        {percentage:.2f}%
      </p>

      <p>
        <strong>Pass Mark:</strong>
        {float(test['pass_percentage'] or 50):.2f}%
      </p>

      <p>
        Attempt ID: {attempt_id}
      </p>

      <p>
        <a class="btn"
           href="/my-premium-courses/{enrollment_id}">
          Back to My Course
        </a>
      </p>

    </div>
    """

    return page("Test Result", html_content)


@app.route("/my-premium-courses/<int:enrollment_id>/test-results")
def premium_student_test_results(enrollment_id):
    if "username" not in session:
        return _premium_redirect(_premium_url_for("login"))

    _premium_v2_init_db()
    _premium_v4_init_db()
    _premium_v5_init_db()

    username = session.get("username")

    conn = _premium_db()

    enrollment = conn.execute("""
        SELECT e.*, c.title AS course_title
        FROM premium_enrollments e
        JOIN premium_courses c ON c.id=e.course_id
        WHERE e.id=? AND e.username=?
    """, (enrollment_id, username)).fetchone()

    if not enrollment:
        conn.close()
        return "Enrollment not found", 404

    attempts = conn.execute("""
        SELECT
            a.*,
            t.title AS test_title
        FROM premium_test_attempts a
        JOIN premium_tests t ON t.id=a.test_id
        WHERE a.enrollment_id=?
        ORDER BY a.id DESC
    """, (enrollment_id,)).fetchall()

    conn.close()

    rows = ""

    for a in attempts:
        status = "Passed" if a["passed"] else "Not Passed"

        rows += f"""
        <tr>
          <td>{html.escape(a['test_title'])}</td>
          <td>{a['score']:g} / {a['total_marks']:g}</td>
          <td>{a['percentage']:.2f}%</td>
          <td>{status}</td>
          <td>{a['submitted_at']}</td>
        </tr>
        """

    html_content = f"""
    <div class="card">
      <h2>Test Results</h2>
      <p>{html.escape(enrollment['course_title'])}</p>
    </div>

    <div class="card">
      <div class="table-wrap">
        <table>
          <tr>
            <th>Test</th>
            <th>Score</th>
            <th>Percentage</th>
            <th>Status</th>
            <th>Submitted</th>
          </tr>

          {rows or '<tr><td colspan="5">No test attempts yet.</td></tr>'}
        </table>
      </div>
    </div>
    """

    return page("Test Results", html_content)


@app.route("/premium-courses/admin/test-results")
def premium_admin_test_results():
    if not _premium_admin_required():
        return _premium_redirect(_premium_url_for("login"))

    _premium_v2_init_db()
    _premium_v4_init_db()
    _premium_v5_init_db()

    conn = _premium_db()

    attempts = conn.execute("""
        SELECT
            a.*,
            t.title AS test_title
        FROM premium_test_attempts a
        JOIN premium_tests t ON t.id=a.test_id
        ORDER BY a.id DESC
    """).fetchall()

    conn.close()

    rows = ""

    for a in attempts:
        status = "Passed" if a["passed"] else "Not Passed"

        rows += f"""
        <tr>
          <td>{a['id']}</td>
          <td>{html.escape(a['username'])}</td>
          <td>{html.escape(a['test_title'])}</td>
          <td>{a['score']:g} / {a['total_marks']:g}</td>
          <td>{a['percentage']:.2f}%</td>
          <td>{status}</td>
          <td>{a['submitted_at']}</td>
        </tr>
        """

    html_content = f"""
    <div class="card">
      <h2>Premium Test Results</h2>

      <div class="table-wrap">
        <table>
          <tr>
            <th>Attempt</th>
            <th>Student</th>
            <th>Test</th>
            <th>Score</th>
            <th>Percentage</th>
            <th>Status</th>
            <th>Submitted</th>
          </tr>

          {rows or '<tr><td colspan="7">No attempts yet.</td></tr>'}
        </table>
      </div>
    </div>
    """

    return page("Premium Test Results", html_content)


# ===== END SHAKIL AI PREMIUM COURSES V5 =====



# ===== END SHAKIL AI PREMIUM COURSES V2 =====





# ===== SHAKIL AI ACADEMY UPGRADE V1 =====


def _academy_v1_db():
    import sqlite3
    db_path = globals().get(
        "DATABASE",
        r"C:\Users\Md Shakil Hossain\ShakilAI\websites\student_management\students.db"
    )
    conn = sqlite3.connect(db_path)
    conn.row_factory = sqlite3.Row
    return conn


def _academy_v1_init_db():
    conn = _academy_v1_db()

    conn.execute("""
        CREATE TABLE IF NOT EXISTS academy_courses (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            title TEXT NOT NULL,
            category TEXT,
            level TEXT,
            description TEXT,
            duration TEXT,
            fee REAL DEFAULT 0,
            status TEXT DEFAULT 'Active',
            created_at TEXT NOT NULL
        )
    """)

    conn.execute("""
        CREATE TABLE IF NOT EXISTS academy_batches (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            course_id INTEGER,
            name TEXT NOT NULL,
            teacher TEXT,
            schedule TEXT,
            start_date TEXT,
            end_date TEXT,
            status TEXT DEFAULT 'Active',
            created_at TEXT NOT NULL
        )
    """)

    conn.execute("""
        CREATE TABLE IF NOT EXISTS academy_assignments (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            course_id INTEGER,
            batch_id INTEGER,
            title TEXT NOT NULL,
            description TEXT,
            due_date TEXT,
            marks REAL DEFAULT 0,
            created_at TEXT NOT NULL
        )
    """)

    conn.execute("""
        CREATE TABLE IF NOT EXISTS academy_resources (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            title TEXT NOT NULL,
            category TEXT,
            description TEXT,
            filename TEXT,
            stored_path TEXT,
            uploaded_by TEXT,
            created_at TEXT NOT NULL,
            download_count INTEGER DEFAULT 0
        )
    """)

    conn.commit()
    conn.close()


def _academy_v1_admin():
    try:
        username = session.get("username")
        role = str(session.get("role", "")).lower()

        return (
            username == "admin"
            or role in ("admin", "administrator")
        )
    except Exception:
        return False


def _academy_v1_page(title, body):
    return f"""
    <!doctype html>
    <html>
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width,initial-scale=1">
        <title>{title} - English Wings Academy</title>
        <style>
            body {{
                margin:0;
                font-family:Arial,Helvetica,sans-serif;
                background:#f4f7fb;
                color:#17202a;
            }}
            .top {{
                background:#173b72;
                color:white;
                padding:22px 28px;
            }}
            .top h1 {{
                margin:0 0 6px;
                font-size:25px;
            }}
            .top p {{
                margin:0;
                opacity:.9;
            }}
            .nav {{
                background:white;
                padding:12px 24px;
                border-bottom:1px solid #e2e8f0;
            }}
            .nav a {{
                display:inline-block;
                margin:4px 8px 4px 0;
                padding:8px 12px;
                border-radius:7px;
                background:#eef4ff;
                color:#173b72;
                text-decoration:none;
                font-weight:700;
            }}
            .container {{
                max-width:1200px;
                margin:25px auto;
                padding:0 18px;
            }}
            .card {{
                background:white;
                border:1px solid #e2e8f0;
                border-radius:12px;
                padding:20px;
                margin-bottom:20px;
                box-shadow:0 3px 10px rgba(0,0,0,.04);
            }}
            .grid {{
                display:grid;
                grid-template-columns:repeat(auto-fit,minmax(220px,1fr));
                gap:16px;
            }}
            .stat {{
                background:white;
                border:1px solid #e2e8f0;
                border-radius:12px;
                padding:20px;
            }}
            .stat strong {{
                display:block;
                font-size:30px;
                color:#2563eb;
                margin-top:8px;
            }}
            table {{
                width:100%;
                border-collapse:collapse;
            }}
            th,td {{
                padding:11px;
                border-bottom:1px solid #e5e7eb;
                text-align:left;
                vertical-align:top;
            }}
            th {{
                background:#f8fafc;
            }}
            input,select,textarea {{
                width:100%;
                box-sizing:border-box;
                padding:10px;
                border:1px solid #cbd5e1;
                border-radius:7px;
                margin:5px 0 12px;
                font:inherit;
            }}
            textarea {{
                min-height:100px;
            }}
            button {{
                background:#2563eb;
                color:white;
                border:0;
                padding:10px 16px;
                border-radius:7px;
                font-weight:700;
                cursor:pointer;
            }}
            .muted {{
                color:#64748b;
            }}
            .success {{
                padding:12px;
                background:#ecfdf5;
                border:1px solid #a7f3d0;
                border-radius:8px;
                color:#065f46;
                margin-bottom:15px;
            }}
            @media(max-width:700px) {{
                table {{
                    display:block;
                    overflow-x:auto;
                }}
            }}
        </style>
    </head>
    <body>
        <div class="top">
            <h1>English Wings Academy</h1>
            <p>Shakil AI Academy Management</p>
        </div>

        <div class="nav">
            <a href="/academy/dashboard">Dashboard</a>
            <a href="/academy/courses">Courses</a>
            <a href="/academy/batches">Batches</a>
            <a href="/academy/assignments">Assignments</a>
            <a href="/academy/resources">Resources</a>
            <a href="/">SMC Dashboard</a>
        </div>

        <div class="container">
            {body}
        </div>
    </body>
    </html>
    """


def _academy_v1_count(conn, table):
    allowed = {
        "academy_courses",
        "academy_batches",
        "academy_assignments",
        "academy_resources"
    }

    if table not in allowed:
        return 0

    return conn.execute(
        "SELECT COUNT(*) FROM " + table
    ).fetchone()[0]


# Initialize Academy V1 database tables.
try:
    _academy_v1_init_db()
except Exception as _academy_v1_init_error:
    print("Academy V1 database initialization warning:", _academy_v1_init_error)


@app.route("/academy/dashboard")
def academy_v1_dashboard():
    if "username" not in session:
        return redirect(url_for("login"))

    conn = _academy_v1_db()

    courses = _academy_v1_count(conn, "academy_courses")
    batches = _academy_v1_count(conn, "academy_batches")
    assignments = _academy_v1_count(conn, "academy_assignments")
    resources = _academy_v1_count(conn, "academy_resources")

    conn.close()

    body = f"""
    <h2>Academy Dashboard</h2>
    <p class="muted">
        English Wings Academy learning management overview.
    </p>

    <div class="grid">
        <div class="stat">
            Courses
            <strong>{courses}</strong>
        </div>

        <div class="stat">
            Batches
            <strong>{batches}</strong>
        </div>

        <div class="stat">
            Assignments
            <strong>{assignments}</strong>
        </div>

        <div class="stat">
            Resources
            <strong>{resources}</strong>
        </div>
    </div>

    <div class="card">
        <h3>Academy V1 Modules</h3>
        <p>
            Courses → Batches → Assignments → Resources
        </p>
        <p class="muted">
            Existing Academy Students, Notes, Vocabulary, IELTS Papers,
            Answer Keys, Tests, Results, Progress and Certificates are preserved.
        </p>
    </div>
    """

    return _academy_v1_page("Academy Dashboard", body)


@app.route("/academy/courses", methods=["GET", "POST"])
def academy_v1_courses():
    if "username" not in session:
        return redirect(url_for("login"))

    conn = _academy_v1_db()

    if request.method == "POST":
        if not _academy_v1_admin():
            conn.close()
            return "Admin access required", 403

        from datetime import datetime

        title = request.form.get("title", "").strip()

        if not title:
            conn.close()
            return "Course title is required", 400

        conn.execute("""
            INSERT INTO academy_courses
            (title, category, level, description, duration, fee, status, created_at)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)
        """, (
            title,
            request.form.get("category", "").strip(),
            request.form.get("level", "").strip(),
            request.form.get("description", "").strip(),
            request.form.get("duration", "").strip(),
            float(request.form.get("fee") or 0),
            request.form.get("status", "Active"),
            datetime.now().isoformat(timespec="seconds")
        ))

        conn.commit()

    rows = conn.execute("""
        SELECT *
        FROM academy_courses
        ORDER BY id DESC
    """).fetchall()

    form = ""

    if _academy_v1_admin():
        form = """
        <div class="card">
            <h3>Add Course</h3>

            <form method="post">
                <label>Course Title</label>
                <input name="title" required>

                <label>Category</label>
                <input name="category" placeholder="IELTS / Spoken English / O Level / A Level">

                <label>Level</label>
                <input name="level" placeholder="Beginner / Intermediate / Advanced">

                <label>Description</label>
                <textarea name="description"></textarea>

                <label>Duration</label>
                <input name="duration" placeholder="3 months">

                <label>Fee</label>
                <input name="fee" type="number" step="0.01">

                <label>Status</label>
                <select name="status">
                    <option>Active</option>
                    <option>Inactive</option>
                </select>

                <button type="submit">Add Course</button>
            </form>
        </div>
        """

    table = """
    <div class="card">
        <h3>Academy Courses</h3>
        <table>
            <tr>
                <th>ID</th>
                <th>Course</th>
                <th>Category</th>
                <th>Level</th>
                <th>Duration</th>
                <th>Fee</th>
                <th>Status</th>
            </tr>
    """

    for r in rows:
        table += f"""
            <tr>
                <td>{r["id"]}</td>
                <td><strong>{r["title"]}</strong><br>
                    <span class="muted">{r["description"] or ""}</span>
                </td>
                <td>{r["category"] or ""}</td>
                <td>{r["level"] or ""}</td>
                <td>{r["duration"] or ""}</td>
                <td>{r["fee"]}</td>
                <td>{r["status"]}</td>
            </tr>
        """

    table += "</table></div>"

    conn.close()

    return _academy_v1_page("Courses", form + table)


@app.route("/academy/batches", methods=["GET", "POST"])
def academy_v1_batches():
    if "username" not in session:
        return redirect(url_for("login"))

    conn = _academy_v1_db()

    if request.method == "POST":
        if not _academy_v1_admin():
            conn.close()
            return "Admin access required", 403

        from datetime import datetime

        name = request.form.get("name", "").strip()

        if not name:
            conn.close()
            return "Batch name is required", 400

        course_id = request.form.get("course_id") or None

        conn.execute("""
            INSERT INTO academy_batches
            (course_id, name, teacher, schedule, start_date, end_date, status, created_at)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)
        """, (
            course_id,
            name,
            request.form.get("teacher", "").strip(),
            request.form.get("schedule", "").strip(),
            request.form.get("start_date", "").strip(),
            request.form.get("end_date", "").strip(),
            request.form.get("status", "Active"),
            datetime.now().isoformat(timespec="seconds")
        ))

        conn.commit()

    courses = conn.execute("""
        SELECT id, title
        FROM academy_courses
        ORDER BY title
    """).fetchall()

    rows = conn.execute("""
        SELECT
            b.*,
            c.title AS course_title
        FROM academy_batches b
        LEFT JOIN academy_courses c
            ON c.id = b.course_id
        ORDER BY b.id DESC
    """).fetchall()

    form = ""

    if _academy_v1_admin():
        options = '<option value="">-- Select Course --</option>'

        for c in courses:
            options += f'<option value="{c["id"]}">{c["title"]}</option>'

        form = f"""
        <div class="card">
            <h3>Add Batch</h3>

            <form method="post">
                <label>Course</label>
                <select name="course_id">
                    {options}
                </select>

                <label>Batch Name</label>
                <input name="name" required>

                <label>Teacher</label>
                <input name="teacher">

                <label>Schedule</label>
                <input name="schedule" placeholder="Sat/Mon/Wed - 7:00 PM">

                <label>Start Date</label>
                <input name="start_date" type="date">

                <label>End Date</label>
                <input name="end_date" type="date">

                <label>Status</label>
                <select name="status">
                    <option>Active</option>
                    <option>Completed</option>
                    <option>Inactive</option>
                </select>

                <button type="submit">Add Batch</button>
            </form>
        </div>
        """

    table = """
    <div class="card">
        <h3>Academy Batches</h3>
        <table>
            <tr>
                <th>ID</th>
                <th>Batch</th>
                <th>Course</th>
                <th>Teacher</th>
                <th>Schedule</th>
                <th>Dates</th>
                <th>Status</th>
            </tr>
    """

    for r in rows:
        table += f"""
            <tr>
                <td>{r["id"]}</td>
                <td><strong>{r["name"]}</strong></td>
                <td>{r["course_title"] or ""}</td>
                <td>{r["teacher"] or ""}</td>
                <td>{r["schedule"] or ""}</td>
                <td>{r["start_date"] or ""} → {r["end_date"] or ""}</td>
                <td>{r["status"]}</td>
            </tr>
        """

    table += "</table></div>"

    conn.close()

    return _academy_v1_page("Batches", form + table)


@app.route("/academy/assignments", methods=["GET", "POST"])
def academy_v1_assignments():
    if "username" not in session:
        return redirect(url_for("login"))

    conn = _academy_v1_db()

    if request.method == "POST":
        if not _academy_v1_admin():
            conn.close()
            return "Admin access required", 403

        from datetime import datetime

        title = request.form.get("title", "").strip()

        if not title:
            conn.close()
            return "Assignment title is required", 400

        course_id = request.form.get("course_id") or None
        batch_id = request.form.get("batch_id") or None

        conn.execute("""
            INSERT INTO academy_assignments
            (course_id, batch_id, title, description, due_date, marks, created_at)
            VALUES (?, ?, ?, ?, ?, ?, ?)
        """, (
            course_id,
            batch_id,
            title,
            request.form.get("description", "").strip(),
            request.form.get("due_date", "").strip(),
            float(request.form.get("marks") or 0),
            datetime.now().isoformat(timespec="seconds")
        ))

        conn.commit()

    courses = conn.execute("""
        SELECT id, title
        FROM academy_courses
        ORDER BY title
    """).fetchall()

    batches = conn.execute("""
        SELECT id, name
        FROM academy_batches
        ORDER BY name
    """).fetchall()

    rows = conn.execute("""
        SELECT
            a.*,
            c.title AS course_title,
            b.name AS batch_name
        FROM academy_assignments a
        LEFT JOIN academy_courses c
            ON c.id = a.course_id
        LEFT JOIN academy_batches b
            ON b.id = a.batch_id
        ORDER BY a.id DESC
    """).fetchall()

    form = ""

    if _academy_v1_admin():
        course_options = '<option value="">-- Course --</option>'

        for c in courses:
            course_options += f'<option value="{c["id"]}">{c["title"]}</option>'

        batch_options = '<option value="">-- Batch --</option>'

        for b in batches:
            batch_options += f'<option value="{b["id"]}">{b["name"]}</option>'

        form = f"""
        <div class="card">
            <h3>Add Assignment</h3>

            <form method="post">
                <label>Course</label>
                <select name="course_id">
                    {course_options}
                </select>

                <label>Batch</label>
                <select name="batch_id">
                    {batch_options}
                </select>

                <label>Assignment Title</label>
                <input name="title" required>

                <label>Description</label>
                <textarea name="description"></textarea>

                <label>Due Date</label>
                <input name="due_date" type="date">

                <label>Total Marks</label>
                <input name="marks" type="number" step="0.01">

                <button type="submit">Add Assignment</button>
            </form>
        </div>
        """

    table = """
    <div class="card">
        <h3>Assignments</h3>
        <table>
            <tr>
                <th>ID</th>
                <th>Assignment</th>
                <th>Course</th>
                <th>Batch</th>
                <th>Due</th>
                <th>Marks</th>
            </tr>
    """

    for r in rows:
        table += f"""
            <tr>
                <td>{r["id"]}</td>
                <td>
                    <strong>{r["title"]}</strong><br>
                    <span class="muted">{r["description"] or ""}</span>
                </td>
                <td>{r["course_title"] or ""}</td>
                <td>{r["batch_name"] or ""}</td>
                <td>{r["due_date"] or ""}</td>
                <td>{r["marks"]}</td>
            </tr>
        """

    table += "</table></div>"

    conn.close()

    return _academy_v1_page("Assignments", form + table)


@app.route("/academy/resources")
def academy_v1_resources():
    if "username" not in session:
        return redirect(url_for("login"))

    conn = _academy_v1_db()

    rows = conn.execute("""
        SELECT *
        FROM academy_resources
        ORDER BY id DESC
    """).fetchall()

    table = """
    <div class="card">
        <h2>Academy Resource Library</h2>

        <p class="muted">
            Central location for course notes, PDFs, presentations,
            worksheets, videos and other Academy learning resources.
        </p>

        <table>
            <tr>
                <th>ID</th>
                <th>Resource</th>
                <th>Category</th>
                <th>Description</th>
                <th>Uploaded By</th>
                <th>Downloads</th>
            </tr>
    """

    for r in rows:
        table += f"""
            <tr>
                <td>{r["id"]}</td>
                <td><strong>{r["title"]}</strong></td>
                <td>{r["category"] or ""}</td>
                <td>{r["description"] or ""}</td>
                <td>{r["uploaded_by"] or ""}</td>
                <td>{r["download_count"] or 0}</td>
            </tr>
        """

    table += "</table></div>"

    if _academy_v1_admin():
        table = """
        <div class="card">
            <h3>Resource Library</h3>
            <p>
                The resource database is ready in V1.
                File upload/download workflow will be connected in the next
                Academy Resource upgrade.
            </p>
        </div>
        """ + table

    conn.close()

    return _academy_v1_page("Resources", table)


# ===== END SHAKIL AI ACADEMY UPGRADE V1 =====

if __name__ == "__main__":
    debug_mode = os.environ.get("SHAKIL_AI_DEBUG", "false").lower() == "true"
    host = os.environ.get("SHAKIL_AI_HOST", "127.0.0.1")
    port = int(os.environ.get("SHAKIL_AI_PORT", "5000"))

    print("==========================================")
    print(" SHAKIL AI STUDENT MANAGEMENT SYSTEM")
    print("==========================================")
    print(f"URL: http://{host}:{port}")
    print("Database:", DATABASE)
    if debug_mode:
        print("WARNING: running with debug=True. Never do this on a")
        print("public or production server â€” it exposes a remote code")
        print("execution console. Only use for local development.")
    print("==========================================")
    app.run(host=host, port=port, debug=debug_mode)





