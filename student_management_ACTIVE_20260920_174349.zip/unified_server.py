from flask import Flask

app = Flask(__name__)


@app.route("/")
def home():
    return """
    <!DOCTYPE html>
    <html>
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>Shakil AI Unified System</title>

        <style>
            body {
                font-family: Arial, sans-serif;
                max-width: 900px;
                margin: 40px auto;
                padding: 20px;
            }

            h1 {
                margin-bottom: 30px;
            }

            .grid {
                display: grid;
                grid-template-columns: repeat(auto-fit, minmax(220px, 1fr));
                gap: 15px;
            }

            a {
                display: block;
                padding: 25px;
                border: 1px solid #ccc;
                border-radius: 10px;
                text-decoration: none;
                color: black;
                font-size: 18px;
            }

            a:hover {
                background: #f2f2f2;
            }
        </style>
    </head>

    <body>

        <h1>🚀 Shakil AI Unified System</h1>

        <div class="grid">

            <a href="http://127.0.0.1:5001">
                🏫<br>
                <b>Shakil AI SMC</b>
            </a>

            <a href="http://127.0.0.1:8000">
                🌐<br>
                <b>English Wings Academy</b>
            </a>

            <a href="http://127.0.0.1:7000">
                🤖<br>
                <b>Shakil AI Assistant</b>
            </a>

            <a href="http://127.0.0.1:7100">
                📊<br>
                <b>AI Student Analytics</b>
            </a>

        </div>

    </body>
    </html>
    """


if __name__ == "__main__":
    app.run(
        host="0.0.0.0",
        port=7200,
        debug=False
    )