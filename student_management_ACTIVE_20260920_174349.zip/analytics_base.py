from flask import Flask, render_template_string, request, jsonify
import sqlite3
from pathlib import Path
from collections import defaultdict
import requests

app = Flask(__name__)

BASE = Path(
    r"C:\Users\Md Shakil Hossain\ShakilAI\websites\student_management"
)
DB = BASE / "students.db"


HTML = """
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Shakil AI — Student Analytics</title>
<meta name="viewport" content="width=device-width, initial-scale=1">

<style>

body {
    font-family: Arial, sans-serif;
    background: #f5f7fb;
    margin: 0;
    color: #222;
}

header {
    background: #1f2937;
    color: white;
    padding: 20px;
}

.container {
    max-width: 1200px;
    margin: 20px auto;
    padding: 0 15px;
}

.cards {
    display: grid;
    grid-template-columns:
    repeat(auto-fit, minmax(180px, 1fr));
    gap: 15px;
}

.card {
    background: white;
    padding: 20px;
    border-radius: 12px;
    box-shadow: 0 2px 8px #0001;
}

.card h2 {
    margin: 0 0 8px;
}

.section {
    margin-top: 30px;
}

table {
    width: 100%;
    border-collapse: collapse;
    background: white;
    margin-top: 15px;
}

th,
td {
    padding: 10px;
    border-bottom: 1px solid #ddd;
    text-align: left;
}

th {
    background: #eef2f7;
}

.warning {
    color: #b45309;
    font-weight: bold;
}

.danger {
    color: #dc2626;
    font-weight: bold;
}

.good {
    color: #15803d;
    font-weight: bold;
}

button {
    margin-top: 6px;
    padding: 7px 12px;
    border: 0;
    border-radius: 6px;
    cursor: pointer;
    background: #1f2937;
    color: white;
}

button:hover {
    opacity: 0.85;
}

.ai-box {
    display: none;
    background: white;
    border-left: 5px solid #1f2937;
    padding: 15px;
    margin-top: 20px;
    border-radius: 8px;
    white-space: pre-wrap;
    box-shadow: 0 2px 8px #0001;
}

@media (max-width: 700px) {

    table {
        font-size: 13px;
    }

    th,
    td {
        padding: 7px;
    }

}

</style>
</head>


<body>

<header>

<h1>🤖 Shakil AI — Student Analytics</h1>

<p>
Read-only analysis from Students, Attendance and Results
</p>

</header>


<div class="container">


<div class="cards">

<div class="card">
<h2>{{ total_students }}</h2>
<p>Total Students</p>
</div>

<div class="card">
<h2>{{ students_with_attendance }}</h2>
<p>Students with Attendance</p>
</div>

<div class="card">
<h2>{{ students_with_results }}</h2>
<p>Students with Results</p>
</div>

<div class="card">
<h2>{{ low_attendance }}</h2>
<p>Low Attendance</p>
</div>

<div class="card">
<h2>{{ low_results }}</h2>
<p>Low Performance</p>
</div>

</div>


<div class="section">

<h2>🏫 Class-wise Analytics</h2>

<table>

<tr>
<th>Class</th>
<th>Students</th>
<th>Attendance</th>
<th>Average Result</th>
</tr>

{% for c in classes %}

<tr>

<td>{{ c.class_name }}</td>

<td>{{ c.students }}</td>

<td>
{{ "%.1f"|format(c.attendance) }}%
</td>

<td>
{{ "%.1f"|format(c.result) }}%
</td>

</tr>

{% endfor %}

</table>

</div>


<div class="section">

<h2>⚠️ Students Needing Attention</h2>

<table>

<tr>
<th>Student</th>
<th>Class</th>
<th>Attendance</th>
<th>Average Result</th>
<th>Status</th>
</tr>

{% for s in alerts %}

<tr>

<td>{{ s.name }}</td>

<td>{{ s.class_name }}</td>

<td>
{{ "%.1f"|format(s.attendance) }}%
</td>

<td>
{{ "%.1f"|format(s.result) }}%
</td>

<td class="{{ s.css }}">
{{ s.status }}
</td>

</tr>

{% endfor %}

</table>

</div>


<div class="section">

<h2>📊 Student Performance</h2>

<table>

<tr>
<th>Student</th>
<th>Class</th>
<th>Attendance</th>
<th>Average Result</th>
<th>Assessment</th>
</tr>

{% for s in students %}

<tr>

<td>{{ s.name }}</td>

<td>{{ s.class_name }}</td>

<td>
{{ "%.1f"|format(s.attendance) }}%
</td>

<td>
{{ "%.1f"|format(s.result) }}%
</td>

<td class="{{ s.css }}">

{{ s.assessment }}

<br>

<button onclick='askAI({{ s|tojson }})'>
🤖 Ask Shakil AI
</button>

</td>

</tr>

{% endfor %}

</table>

</div>


<div id="aiBox" class="ai-box"></div>


</div>


<script>

async function askAI(student) {

    const box = document.getElementById("aiBox");

    box.style.display = "block";

    box.innerText = "🤖 Shakil AI is analyzing...";

    try {

        const response = await fetch(
            "/api/ai-explain",
            {
                method: "POST",
                headers: {
                    "Content-Type": "application/json"
                },
                body: JSON.stringify(student)
            }
        );

        const data = await response.json();

        if (data.ok) {

            box.innerText =
                "🤖 Shakil AI\\n\\n" + data.answer;

        } else {

            box.innerText =
                "AI is currently unavailable.";

        }

    } catch (error) {

        box.innerText =
            "Could not connect to Shakil AI.";

    }

}

</script>


</body>
</html>
"""


def get_data():

    conn = sqlite3.connect(DB)
    conn.row_factory = sqlite3.Row

    students = conn.execute("""
        SELECT id, name, class_name
        FROM students
        ORDER BY class_name, name
    """).fetchall()

    attendance = conn.execute("""
        SELECT student_id, status
        FROM attendance
    """).fetchall()

    results = conn.execute("""
        SELECT student_id, marks, total_marks
        FROM results
    """).fetchall()

    conn.close()


    # Attendance

    att = {}

    for row in attendance:

        sid = row["student_id"]

        if sid not in att:

            att[sid] = {
                "present": 0,
                "total": 0
            }

        att[sid]["total"] += 1

        status = str(
            row["status"]
        ).strip().lower()

        if status in ("present", "p", "1"):

            att[sid]["present"] += 1


    # Results

    res = {}

    for row in results:

        sid = row["student_id"]

        if sid not in res:

            res[sid] = {
                "marks": 0,
                "total": 0
            }

        res[sid]["marks"] += float(
            row["marks"] or 0
        )

        res[sid]["total"] += float(
            row["total_marks"] or 0
        )


    data = []
    alerts = []


    # Class data

    class_data = defaultdict(
        lambda: {
            "students": 0,
            "attendance_total": 0,
            "attendance_present": 0,
            "result_marks": 0,
            "result_total": 0
        }
    )


    # Process students

    for st in students:

        sid = st["id"]
        class_name = st["class_name"]


        class_data[class_name]["students"] += 1


        # Attendance

        if sid in att and att[sid]["total"]:

            attendance_pct = (
                att[sid]["present"]
                / att[sid]["total"]
                * 100
            )

            has_att = True

            class_data[class_name][
                "attendance_total"
            ] += att[sid]["total"]

            class_data[class_name][
                "attendance_present"
            ] += att[sid]["present"]

        else:

            attendance_pct = 0
            has_att = False


        # Results

        if sid in res and res[sid]["total"]:

            result_pct = (
                res[sid]["marks"]
                / res[sid]["total"]
                * 100
            )

            has_result = True

            class_data[class_name][
                "result_marks"
            ] += res[sid]["marks"]

            class_data[class_name][
                "result_total"
            ] += res[sid]["total"]

        else:

            result_pct = 0
            has_result = False


        # Alerts

        reasons = []

        if has_att and attendance_pct < 75:

            reasons.append(
                "Low attendance"
            )

        if has_result and result_pct < 50:

            reasons.append(
                "Low result"
            )

        if reasons:

            alerts.append(
                {
                    "name": st["name"],
                    "class_name": class_name,
                    "attendance": attendance_pct,
                    "result": result_pct,
                    "status": " + ".join(reasons),
                    "css": "danger"
                }
            )


        # Assessment

        if not has_att and not has_result:

            assessment = "Insufficient data"
            css = "warning"

        elif result_pct >= 80:

            assessment = "Strong performance"
            css = "good"

        elif result_pct >= 50:

            assessment = "Average performance"
            css = ""

        else:

            assessment = "Needs academic support"
            css = "danger"


        data.append(
            {
                "name": st["name"],
                "class_name": class_name,
                "attendance": attendance_pct,
                "result": result_pct,
                "assessment": assessment,
                "css": css
            }
        )


    # Class percentages

    classes = []

    for class_name, info in sorted(
        class_data.items()
    ):

        if info["attendance_total"]:

            class_attendance = (
                info["attendance_present"]
                / info["attendance_total"]
                * 100
            )

        else:

            class_attendance = 0


        if info["result_total"]:

            class_result = (
                info["result_marks"]
                / info["result_total"]
                * 100
            )

        else:

            class_result = 0


        classes.append(
            {
                "class_name": class_name,
                "students": info["students"],
                "attendance": class_attendance,
                "result": class_result
            }
        )


    return (
        data,
        alerts,
        len(students),
        len(att),
        len(res),
        classes
    )


@app.route(
    "/api/ai-explain",
    methods=["POST"]
)
def ai_explain():

    data = request.get_json() or {}

    prompt = f"""
You are Shakil AI, an educational analytics assistant.

Analyze this student data for a teacher.

Student: {data.get("name", "")}
Class: {data.get("class_name", "")}
Attendance: {data.get("attendance", 0)}%
Average Result: {data.get("result", 0)}%

Provide:

1. Short performance summary.
2. Possible academic concerns.
3. Three practical teacher actions.

Do not make medical or psychological diagnoses.
Do not make high-stakes decisions automatically.
Keep the response concise and teacher-friendly.
"""


    try:

        response = requests.post(
            "http://127.0.0.1:11434/api/generate",

            json={
                "model": "llama3.2:3b",
                "prompt": prompt,
                "stream": False,
                "options": {
                    "num_ctx": 2048,
                    "num_predict": 300,
                    "temperature": 0.3
                }
            },

            timeout=60
        )

        result = response.json()

        return jsonify(
            {
                "ok": True,
                "answer": result.get(
                    "response",
                    ""
                )
            }
        )


    except Exception as e:

        return jsonify(
            {
                "ok": False,
                "answer":
                    "AI is currently unavailable.",
                "error": str(e)
            }
        ), 503


@app.route("/")
def dashboard():

    (
        students,
        alerts,
        total,
        with_att,
        with_results,
        classes
    ) = get_data()


    return render_template_string(
        HTML,

        students=students,
        alerts=alerts,
        classes=classes,

        total_students=total,

        students_with_attendance=
            with_att,

        students_with_results=
            with_results,

        low_attendance=sum(
            1
            for s in students
            if 0 < s["attendance"] < 75
        ),

        low_results=sum(
            1
            for s in students
            if 0 < s["result"] < 50
        )
    )


if __name__ == "__main__":

    print("=" * 50)

    print(
        " SHAKIL AI STUDENT ANALYTICS"
    )

    print("=" * 50)

    print(
        "Database:",
        DB
    )

    print(
        "URL: http://127.0.0.1:7100"
    )

    print(
        "LAN: http://192.168.1.5:7100"
    )

    print("=" * 50)

    app.run(
        host="0.0.0.0",
        port=7100,
        debug=False
    )