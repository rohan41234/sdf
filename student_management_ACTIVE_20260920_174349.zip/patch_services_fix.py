﻿from pathlib import Path

p = Path("smc_base.py")
s = p.read_text(encoding="utf-8")

old = """/* ===== END SHAKIL AI DASHBOARD V3 ===== */"""

css = """
/* ===== ENGLISH WINGS SERVICES BUTTON FIX ===== */

.card:last-child{
  background:linear-gradient(135deg,#f8fbff,#eef5ff);
}

.card:last-child > h2{
  color:#17202a;
  font-size:22px;
  font-weight:800;
  margin-bottom:18px;
}

.card:last-child > h2:after{
  background:#cbd5e1;
}

.card:last-child .btn{
  display:inline-block;
  margin:4px 6px 4px 0;
  min-width:145px;
  padding:10px 16px;
  border:0;
  border-radius:9px;
  background:#2563eb;
  color:#fff;
  font-weight:700;
  text-decoration:none;
  box-shadow:0 3px 8px rgba(37,99,235,.18);
}

.card:last-child .btn:hover{
  background:#1d4ed8;
  color:#fff;
  text-decoration:none;
  transform:translateY(-1px);
}

@media(max-width:800px){
  .card:last-child .btn{
    min-width:130px;
    margin-bottom:7px;
  }
}

/* ===== END ENGLISH WINGS SERVICES BUTTON FIX ===== */
"""

if old not in s:
    raise SystemExit("V3 end marker not found. No changes made.")

s = s.replace(old, old + "\n" + css, 1)

p.write_text(s, encoding="utf-8")
print("SERVICES BUTTON FIX APPLIED")
