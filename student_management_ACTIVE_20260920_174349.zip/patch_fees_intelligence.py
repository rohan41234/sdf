from pathlib import Path

p = Path("smc_base.py")
s = p.read_text(encoding="utf-8")

old = """    html=f'''<h1>Fees & Accounts</h1><div class="card"><form method="post" """

new = """    # Fees intelligence summary
    total_fee_records = len(rows)
    total_amount = sum(float(r["amount"] or 0) for r in rows)
    paid_amount = sum(float(r["paid"] or 0) for r in rows)
    due_amount = max(total_amount - paid_amount, 0)
    collection_rate = (
        paid_amount / total_amount * 100
        if total_amount else 0
    )

    fee_summary = f'''
    <div class="grid">
      <div class="stat"><h3>Fee Records</h3><h2>{total_fee_records}</h2></div>
      <div class="stat"><h3>Total Amount</h3><h2>{total_amount:,.2f}</h2></div>
      <div class="stat"><h3>Paid Amount</h3><h2>{paid_amount:,.2f}</h2></div>
      <div class="stat"><h3>Due Amount</h3><h2>{due_amount:,.2f}</h2></div>
      <div class="stat"><h3>Collection Rate</h3><h2>{collection_rate:.1f}%</h2></div>
    </div>
    <div class="card">
      <strong>Fee Collection Summary:</strong>
      Paid {paid_amount:,.2f} out of {total_amount:,.2f}.
      Outstanding amount: {due_amount:,.2f}.
    </div>
    '''

    html=f'''<h1>Fees & Accounts</h1>{fee_summary}<div class="card"><form method="post" """

if old not in s:
    raise SystemExit("TARGET NOT FOUND")

s = s.replace(old, new, 1)

p.write_text(s, encoding="utf-8")
print("FEES INTELLIGENCE ADDED")