﻿from pathlib import Path

src = Path("smc_base.py")
text = src.read_text(encoding="utf-8")

MARKER = "# ===== SHAKIL AI PREMIUM COURSES V2 ====="

if MARKER in text:
    print("Premium Courses V2 already exists. No changes made.")
    raise SystemExit(0)

anchor = "# ===== END SHAKIL AI PREMIUM COURSES V1 ====="

if anchor not in text:
    raise SystemExit("ERROR: Premium Courses V1 marker not found.")

block = r'''

# ===== SHAKIL AI PREMIUM COURSES V2 =====

def _premium_v2_init_db():
    conn = _premium_db()

    conn.execute("""
        CREATE TABLE IF NOT EXISTS premium_enrollments (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            course_id INTEGER NOT NULL,
            username TEXT NOT NULL,
            status TEXT DEFAULT 'Active',
            enrolled_at TEXT DEFAULT CURRENT_TIMESTAMP,
            UNIQUE(course_id, username)
        )
    """)

    conn.execute("""
        CREATE TABLE IF NOT EXISTS premium_progress (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            enrollment_id INTEGER NOT NULL,
            resource_id INTEGER,
            completed INTEGER DEFAULT 0,
            completed_at TEXT,
            UNIQUE(enrollment_id, resource_id)
        )
    """)

    conn.commit()
    conn.close()

_premium_v2_init_db()


@app.route("/premium-courses/enroll/<int:course_id>", methods=["POST"])
def premium_course_enroll(course_id):
    if not session.get("username"):
        return _premium_redirect(_premium_url_for("login"))

    _premium_v2_init_db()

    username = str(session.get("username"))

    conn = _premium_db()

    course = conn.execute(
        "SELECT id FROM premium_courses WHERE id=? AND status='Published'",
        (course_id,)
    ).fetchone()

    if not course:
        conn.close()
        return "Course not found", 404

    conn.execute("""
        INSERT OR IGNORE INTO premium_enrollments
        (course_id, username, status)
        VALUES (?, ?, 'Active')
    """, (course_id, username))

    conn.commit()
    conn.close()

    return _premium_redirect(
        _premium_url_for(
            "premium_my_courses"
        )
    )


@app.route("/my-premium-courses")
def premium_my_courses():
    if not session.get("username"):
        return _premium_redirect(_premium_url_for("login"))

    _premium_v2_init_db()

    username = str(session.get("username"))

    conn = _premium_db()

    rows = conn.execute("""
        SELECT
            e.id AS enrollment_id,
            e.status AS enrollment_status,
            e.enrolled_at,
            c.*
        FROM premium_enrollments e
        JOIN premium_courses c
          ON c.id=e.course_id
        WHERE e.username=?
        ORDER BY e.id DESC
    """, (username,)).fetchall()

    cards = ""

    for row in rows:

        total = conn.execute("""
            SELECT COUNT(*)
            FROM premium_course_files
            WHERE course_id=?
        """, (row["id"],)).fetchone()[0]

        completed = conn.execute("""
            SELECT COUNT(*)
            FROM premium_progress p
            JOIN premium_course_files f
              ON f.id=p.resource_id
            WHERE p.enrollment_id=?
              AND p.completed=1
              AND f.course_id=?
        """, (
            row["enrollment_id"],
            row["id"]
        )).fetchone()[0]

        progress = 0

        if total:
            progress = round((completed / total) * 100)

        cards += f"""
        <div class="card">
            <h2>{esc(row["title"])}</h2>

            <p>
                <strong>Category:</strong>
                {esc(row["category"] or "")}
            </p>

            <p>
                <strong>Status:</strong>
                {esc(row["enrollment_status"] or "")}
            </p>

            <div style="
                background:#e5e7eb;
                border-radius:10px;
                height:16px;
                overflow:hidden;
                margin:15px 0;
            ">
                <div style="
                    width:{progress}%;
                    height:100%;
                    background:#2563eb;
                "></div>
            </div>

            <p>
                <strong>Progress:</strong> {progress}%
            </p>

            <a class="btn btn-info"
               href="{_premium_url_for(
                   'premium_my_course_detail',
                   enrollment_id=row['enrollment_id']
               )}">
               Open Course
            </a>
        </div>
        """

    conn.close()

    if not cards:
        cards = """
        <div class="card">
            <h2>No Enrolled Courses</h2>
            <p>You have not enrolled in any premium course yet.</p>
            <a class="btn btn-info"
               href="/premium-courses">
               Browse Premium Courses
            </a>
        </div>
        """

    return _premium_page(
        "My Premium Courses",
        f"""
        <div class="card">
            <h1>My Premium Courses</h1>
            <p>Welcome, {esc(username)}</p>
        </div>

        <div class="grid">
            {cards}
        </div>
        """
    )


@app.route("/my-premium-courses/<int:enrollment_id>")
def premium_my_course_detail(enrollment_id):
    if not session.get("username"):
        return _premium_redirect(_premium_url_for("login"))

    _premium_v2_init_db()

    username = str(session.get("username"))

    conn = _premium_db()

    enrollment = conn.execute("""
        SELECT
            e.*,
            c.title,
            c.description,
            c.category,
            c.instructor,
            c.duration
        FROM premium_enrollments e
        JOIN premium_courses c
          ON c.id=e.course_id
        WHERE e.id=?
          AND e.username=?
    """, (
        enrollment_id,
        username
    )).fetchone()

    if not enrollment:
        conn.close()
        return "Enrollment not found", 404

    resources = conn.execute("""
        SELECT *
        FROM premium_course_files
        WHERE course_id=?
        ORDER BY id
    """, (enrollment["course_id"],)).fetchall()

    items = ""

    for r in resources:

        p = conn.execute("""
            SELECT completed
            FROM premium_progress
            WHERE enrollment_id=?
              AND resource_id=?
        """, (
            enrollment_id,
            r["id"]
        )).fetchone()

        completed = bool(p["completed"]) if p else False

        status = "Completed" if completed else "Not completed"

        action = ""

        if completed:
            action = """
            <span style="color:#218c74;font-weight:700;">
                ✓ Completed
            </span>
            """
        else:
            action = f"""
            <form method="post"
                  action="{_premium_url_for(
                      'premium_mark_resource_complete',
                      enrollment_id=enrollment_id,
                      resource_id=r['id']
                  )}">
                <button class="btn btn-success" type="submit">
                    Mark Complete
                </button>
            </form>
            """

        items += f"""
        <tr>
            <td>{esc(r["original_name"])}</td>
            <td>{esc(r["file_type"])}</td>
            <td>{status}</td>
            <td>
                <a class="btn btn-info"
                   href="{_premium_url_for(
                       'premium_course_file',
                       file_id=r['id']
                   )}">
                   Open
                </a>
                {action}
            </td>
        </tr>
        """

    total = len(resources)

    completed_count = conn.execute("""
        SELECT COUNT(*)
        FROM premium_progress
        WHERE enrollment_id=?
          AND completed=1
    """, (enrollment_id,)).fetchone()[0]

    progress = round(
        (completed_count / total) * 100
    ) if total else 0

    conn.close()

    return _premium_page(
        enrollment["title"],
        f"""
        <div class="card">
            <h1>{esc(enrollment["title"])}</h1>

            <p>{esc(enrollment["description"] or "")}</p>

            <p>
                <strong>Instructor:</strong>
                {esc(enrollment["instructor"] or "")}
            </p>

            <p>
                <strong>Duration:</strong>
                {esc(enrollment["duration"] or "")}
            </p>

            <div style="
                background:#e5e7eb;
                border-radius:10px;
                height:18px;
                overflow:hidden;
                margin:18px 0;
            ">
                <div style="
                    width:{progress}%;
                    height:100%;
                    background:#218c74;
                "></div>
            </div>

            <h2>Course Progress: {progress}%</h2>
        </div>

        <div class="card table-wrap">
            <h2>Course Resources</h2>

            <table>
                <tr>
                    <th>Resource</th>
                    <th>Type</th>
                    <th>Status</th>
                    <th>Action</th>
                </tr>

                {items}
            </table>
        </div>

        <a class="btn"
           href="/my-premium-courses">
           ← My Courses
        </a>
        """
    )


@app.route(
    "/my-premium-courses/<int:enrollment_id>/complete/<int:resource_id>",
    methods=["POST"]
)
def premium_mark_resource_complete(
    enrollment_id,
    resource_id
):
    if not session.get("username"):
        return _premium_redirect(_premium_url_for("login"))

    _premium_v2_init_db()

    username = str(session.get("username"))

    conn = _premium_db()

    valid = conn.execute("""
        SELECT e.id
        FROM premium_enrollments e
        JOIN premium_course_files f
          ON f.course_id=e.course_id
        WHERE e.id=?
          AND e.username=?
          AND f.id=?
    """, (
        enrollment_id,
        username,
        resource_id
    )).fetchone()

    if not valid:
        conn.close()
        return "Invalid enrollment/resource", 403

    conn.execute("""
        INSERT INTO premium_progress
        (enrollment_id, resource_id, completed, completed_at)
        VALUES (?, ?, 1, CURRENT_TIMESTAMP)
        ON CONFLICT(enrollment_id, resource_id)
        DO UPDATE SET
            completed=1,
            completed_at=CURRENT_TIMESTAMP
    """, (
        enrollment_id,
        resource_id
    ))

    conn.commit()
    conn.close()

    return _premium_redirect(
        _premium_url_for(
            "premium_my_course_detail",
            enrollment_id=enrollment_id
        )
    )


@app.route("/premium-courses/admin/enrollments")
def premium_admin_enrollments():
    if not _premium_admin_required():
        return _premium_redirect(_premium_url_for("login"))

    _premium_v2_init_db()

    conn = _premium_db()

    rows = conn.execute("""
        SELECT
            e.id,
            e.username,
            e.status,
            e.enrolled_at,
            c.title,
            (
                SELECT COUNT(*)
                FROM premium_course_files f
                WHERE f.course_id=c.id
            ) AS total_resources,
            (
                SELECT COUNT(*)
                FROM premium_progress p
                JOIN premium_course_files f2
                  ON f2.id=p.resource_id
                WHERE p.enrollment_id=e.id
                  AND p.completed=1
                  AND f2.course_id=c.id
            ) AS completed_resources
        FROM premium_enrollments e
        JOIN premium_courses c
          ON c.id=e.course_id
        ORDER BY e.id DESC
    """).fetchall()

    conn.close()

    rows_html = ""

    for r in rows:

        total = r["total_resources"] or 0
        completed = r["completed_resources"] or 0

        progress = round(
            completed / total * 100
        ) if total else 0

        rows_html += f"""
        <tr>
            <td>{r["id"]}</td>
            <td>{esc(r["username"])}</td>
            <td>{esc(r["title"])}</td>
            <td>{esc(r["status"])}</td>
            <td>{progress}%</td>
            <td>{esc(r["enrolled_at"])}</td>
        </tr>
        """

    return _premium_page(
        "Premium Enrollment Management",
        f"""
        <div class="card">
            <h1>Premium Enrollment Management</h1>
            <p>Student enrollment and progress overview.</p>
        </div>

        <div class="card table-wrap">
            <table>
                <tr>
                    <th>ID</th>
                    <th>Student</th>
                    <th>Course</th>
                    <th>Status</th>
                    <th>Progress</th>
                    <th>Enrolled</th>
                </tr>

                {rows_html}
            </table>
        </div>

        <a class="btn"
           href="/premium-courses/admin">
           ← Course Admin
        </a>
        """
    )

# ===== END SHAKIL AI PREMIUM COURSES V2 =====

'''

new_text = text.replace(
    anchor,
    anchor + "\n" + block,
    1
)

src.write_text(new_text, encoding="utf-8")

print("PREMIUM COURSES V2 APPLIED")
