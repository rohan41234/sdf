﻿from pathlib import Path
import shutil
from datetime import datetime

path = Path("smc_base.py")
source = path.read_text(encoding="utf-8-sig")

print("=" * 70)
print("IELTS UPGRADE PATCH")
print("=" * 70)

# ------------------------------------------------------------
# 1. Safety checks
# ------------------------------------------------------------

required = [
    'ACADEMY_MODULES={',
    'def xlist(area,module):',
    'def xform(area,module,row=None):',
    'def xadd(area,module):',
    'def xedit(area,module,item_id):',
    'def xdelete(area,module,item_id):',
]

for item in required:
    if item not in source:
        raise SystemExit(f"STOP: Required code not found: {item}")

old_config = '"ielts":("IELTS",[("student_id","Student ID",1),("skill","Skill",0),("module","Module",0),("test_no","Test No.",0),("score","Score",0),("remarks","Remarks",0)]),'

if old_config not in source:
    raise SystemExit("STOP: Expected original IELTS configuration was not found.")

print("Safety checks: PASSED")

# ------------------------------------------------------------
# 2. Backup current code
# ------------------------------------------------------------

backup_root = Path(r"C:\Users\Md Shakil Hossain\ShakilAI\backups")
backup_root.mkdir(parents=True, exist_ok=True)

stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
backup_dir = backup_root / f"student_management_before_ielts_patch_{stamp}"
backup_dir.mkdir()

backup_file = backup_dir / "smc_base.py"
shutil.copy2(path, backup_file)

print("Code backup:")
print(backup_file)

# ------------------------------------------------------------
# 3. Replace IELTS module configuration
# ------------------------------------------------------------

new_config = '''"ielts":("IELTS",[
("student_id","Student ID",1),
("test_date","Test Date",1),
("test_no","Test No.",0),
("listening","Listening",0),
("reading","Reading",0),
("writing","Writing",0),
("speaking","Speaking",0),
("overall_band","Overall Band",0),
("cefr","CEFR Level",0),
("remarks","Remarks",0)
]),'''

source = source.replace(old_config, new_config, 1)

# ------------------------------------------------------------
# 4. Add IELTS-specific helpers immediately before xlist
# ------------------------------------------------------------

marker = "def xlist(area,module):"

if marker not in source:
    raise SystemExit("STOP: xlist marker not found.")

ielts_helpers = r'''
def _ielts_band_value(value):
 try:
  if value is None or str(value).strip()=='':
   return None
  x=float(str(value).strip())
  if x<0 or x>9:
   return None
  return x
 except Exception:
  return None

def _ielts_round_band(value):
 if value is None:return ''
 return round(float(value)*2)/2

def _ielts_cefr(value):
 try:
  x=float(value)
 except Exception:
  return ''
 if x>=8.5:return 'C2'
 if x>=7.0:return 'C1'
 if x>=5.5:return 'B2'
 if x>=4.0:return 'B1'
 if x>=3.5:return 'A2'
 return 'A1'

def _ielts_overall_from_form(form):
 vals=[]
 for key in ('listening','reading','writing','speaking'):
  v=_ielts_band_value(form.get(key,''))
  if v is None:return ''
  vals.append(v)
 return _ielts_round_band(sum(vals)/4)

def _ielts_migrate_db():
 conn=get_db()
 try:
  cols={r[1] for r in conn.execute("PRAGMA table_info(academy_ielts)").fetchall()}
  wanted=[
   ('test_date','TEXT'),
   ('listening','TEXT'),
   ('reading','TEXT'),
   ('writing','TEXT'),
   ('speaking','TEXT'),
   ('overall_band','TEXT'),
   ('cefr','TEXT')
  ]
  for col,typ in wanted:
   if col not in cols:
    conn.execute(f"ALTER TABLE academy_ielts ADD COLUMN {col} {typ}")

  # Preserve the existing test record and map its old Speaking score
  # into the new Speaking field when possible.
  conn.execute("""
   UPDATE academy_ielts
   SET speaking=score
   WHERE (speaking IS NULL OR speaking='')
     AND skill='Speaking'
     AND score IS NOT NULL
     AND score!=''
  """)

  conn.commit()
 finally:
  conn.close()

_ielts_migrate_db()

'''

source = source.replace(marker, ielts_helpers + marker, 1)

# ------------------------------------------------------------
# 5. Replace xlist with IELTS-aware version
# ------------------------------------------------------------

start = source.index("def xlist(area,module):")
end = source.index("\ndef xform(area,module,row=None):", start)

new_xlist = r'''def xlist(area,module):
 cfg=xcfg(area,module)
 if not cfg:return redirect(url_for("home"))

 # IELTS gets a dedicated results/history interface.
 if area=="academy" and module=="ielts":
  _ielts_migrate_db()
  conn=get_db()
  rows=conn.execute("""
   SELECT * FROM academy_ielts
   ORDER BY
    CASE WHEN test_date IS NULL OR test_date='' THEN created_at ELSE test_date END DESC,
    id DESC
  """).fetchall()
  conn.close()

  body=""
  for r in rows:
   body+=(
    "<tr>"
    f"<td>{esc(r['student_id'] or '')}</td>"
    f"<td>{esc(r['test_date'] or '')}</td>"
    f"<td>{esc(r['test_no'] or '')}</td>"
    f"<td>{esc(r['listening'] or '')}</td>"
    f"<td>{esc(r['reading'] or '')}</td>"
    f"<td>{esc(r['writing'] or '')}</td>"
    f"<td>{esc(r['speaking'] or '')}</td>"
    f"<td><strong>{esc(r['overall_band'] or '')}</strong></td>"
    f"<td>{esc(r['cefr'] or '')}</td>"
    f"<td>{esc(r['remarks'] or '')}</td>"
    f"<td>"
    f"<a class='btn btn-info' href='{url_for('xedit',area='academy',module='ielts',item_id=r['id'])}'>Edit</a> "
    f"<a class='btn btn-danger' href='{url_for('xdelete',area='academy',module='ielts',item_id=r['id'])}' onclick=\"return confirm('Delete this IELTS record?');\">Delete</a>"
    f"</td>"
    "</tr>"
   )

  if not body:
   body="<tr><td colspan='11'>No IELTS records yet.</td></tr>"

  return page(
   "IELTS",
   f"""
   <div class='toolbar'>
    <h1 style='flex:1'>IELTS Results & Progress</h1>
    <a class='btn btn-success' href='{url_for('xadd',area='academy',module='ielts')}'>+ Add IELTS Test</a>
   </div>

   <div class='card'>
    <p>
     Record Listening, Reading, Writing and Speaking bands.
     Overall Band is calculated automatically.
    </p>
   </div>

   <div class='card' style='overflow-x:auto'>
    <table>
     <tr>
      <th>Student ID</th>
      <th>Test Date</th>
      <th>Test No.</th>
      <th>Listening</th>
      <th>Reading</th>
      <th>Writing</th>
      <th>Speaking</th>
      <th>Overall</th>
      <th>CEFR</th>
      <th>Remarks</th>
      <th>Actions</th>
     </tr>
     {body}
    </table>
   </div>
   """
  )

 title,fields=cfg
 table=("academy_" if area=="academy" else "consultancy_")+module
 conn=get_db()
 rows=conn.execute(f"SELECT * FROM {table} ORDER BY id DESC").fetchall()
 conn.close()
 heads="".join(f"<th>{esc(label)}</th>" for _,label,_ in fields)
 body=""
 for r in rows:
  body+="<tr>"+"".join(f"<td>{esc(r[k] if k in r.keys() else '')}</td>" for k,_,_ in fields)+f"<td><a class='btn btn-info' href='{f"/extended/{area}/{module}/{r['id']}/edit" }'>Edit</a> <a class='btn btn-danger' href='{f"/extended/{area}/{module}/{r['id']}/delete" }' onclick=\"return confirm('Delete this record?');\">Delete</a></td></tr>"
 if not body:body=f"<tr><td colspan='{len(fields)+1}'>No records yet.</td></tr>"
 return page(title,f"<div class='toolbar'><h1 style='flex:1'>{esc(title)}</h1><a class='btn btn-success' href='{url_for('xadd',area=area,module=module)}'>+ Add</a></div><div class='card'><table><tr>{heads}<th>Actions</th></tr>{body}</table></div>")
'''

source = source[:start] + new_xlist + source[end:]

# ------------------------------------------------------------
# 6. Replace xform with IELTS-specific form
# ------------------------------------------------------------

start = source.index("def xform(area,module,row=None):")
end = source.index("\ndef xadd(area,module):", start)

new_xform = r'''def xform(area,module,row=None):
 title,fields=xcfg(area,module)

 if area=="academy" and module=="ielts":
  v=lambda k: esc(row[k] if row and k in row.keys() and row[k] is not None else '')

  act='Update' if row else 'Save'

  form=f"""
  <h1>{act} — IELTS Test</h1>

  <div class='card'>
   <form method='post'>

    <label>Student ID</label>
    <input name='student_id' value='{v("student_id")}' required
     style='width:100%;padding:10px;margin:5px 0 12px'>

    <label>Test Date</label>
    <input type='date' name='test_date' value='{v("test_date")}' required
     style='width:100%;padding:10px;margin:5px 0 12px'>

    <label>Test No.</label>
    <input name='test_no' value='{v("test_no")}'
     style='width:100%;padding:10px;margin:5px 0 12px'>

    <h3>IELTS Band Scores</h3>

    <label>Listening</label>
    <input type='number' name='listening' value='{v("listening")}'
     min='0' max='9' step='0.5'
     style='width:100%;padding:10px;margin:5px 0 12px'>

    <label>Reading</label>
    <input type='number' name='reading' value='{v("reading")}'
     min='0' max='9' step='0.5'
     style='width:100%;padding:10px;margin:5px 0 12px'>

    <label>Writing</label>
    <input type='number' name='writing' value='{v("writing")}'
     min='0' max='9' step='0.5'
     style='width:100%;padding:10px;margin:5px 0 12px'>

    <label>Speaking</label>
    <input type='number' name='speaking' value='{v("speaking")}'
     min='0' max='9' step='0.5'
     style='width:100%;padding:10px;margin:5px 0 12px'>

    <label>Overall Band</label>
    <input name='overall_band' value='{v("overall_band")}' readonly
     style='width:100%;padding:10px;margin:5px 0 12px;background:#f3f3f3'>

    <label>CEFR Level</label>
    <input name='cefr' value='{v("cefr")}' readonly
     style='width:100%;padding:10px;margin:5px 0 12px;background:#f3f3f3'>

    <label>Remarks</label>
    <textarea name='remarks' rows='3'
     style='width:100%;padding:10px;margin:5px 0 12px'>{v("remarks")}</textarea>

    <button class='btn btn-success'>{act}</button>
    <a class='btn' href='{url_for("xlist_route",area=area,module=module)}'>Cancel</a>

   </form>
  </div>

  <script>
  (function(){{
   const ids=['listening','reading','writing','speaking'];

   function calc(){{
    const values=ids.map(function(id){{
     const n=parseFloat(document.querySelector("[name='"+id+"']").value);
     return Number.isFinite(n) ? n : null;
    }});

    const overall=document.querySelector("[name='overall_band']");
    const cefr=document.querySelector("[name='cefr']");

    if(values.some(function(x){{return x===null;}})){{
     overall.value='';
     cefr.value='';
     return;
    }}

    const avg=values.reduce(function(a,b){{return a+b;}},0)/4;
    const rounded=Math.round(avg*2)/2;

    overall.value=rounded.toFixed(1).replace('.0','');

    let level='';
    if(rounded>=8.5) level='C2';
    else if(rounded>=7.0) level='C1';
    else if(rounded>=5.5) level='B2';
    else if(rounded>=4.0) level='B1';
    else if(rounded>=3.5) level='A2';
    else level='A1';

    cefr.value=level;
   }}

   ids.forEach(function(id){{
    document.querySelector("[name='"+id+"']").addEventListener('input',calc);
   }});

   calc();
  }})();
  </script>
  """

  return page(f"{act} {title}",form)

 fs=""
 for k,label,req in fields:
  v=esc(row[k]) if row else ""
  fs+=f"<label>{esc(label)}</label><textarea name='{k}' rows='3' style='width:100%;padding:10px;margin:5px 0 12px' {'required' if req else ''}>{v}</textarea>"
 act='Update' if row else 'Save'
 return page(f'{act} {title}',f"<h1>{act} — {esc(title)}</h1><div class='card'><form method='post'>{fs}<button class='btn btn-success'>{act}</button> <a class='btn' href='{url_for('xlist_route',area=area,module=module)}'>Cancel</a></form></div>")
'''

source = source[:start] + new_xform + source[end:]

# ------------------------------------------------------------
# 7. Replace xadd with IELTS-aware POST handling
# ------------------------------------------------------------

start = source.index("def xadd(area,module):")
end = source.index("\ndef xedit(area,module,item_id):", start)

new_xadd = r'''def xadd(area,module):
 cfg=xcfg(area,module)
 if not cfg:return redirect(url_for('home'))

 if area=="academy" and module=="ielts":
  if request.method=='POST':
   student_id=request.form.get('student_id','').strip()
   test_date=request.form.get('test_date','').strip()
   test_no=request.form.get('test_no','').strip()
   listening=request.form.get('listening','').strip()
   reading=request.form.get('reading','').strip()
   writing=request.form.get('writing','').strip()
   speaking=request.form.get('speaking','').strip()
   remarks=request.form.get('remarks','').strip()

   overall=_ielts_overall_from_form(request.form)
   cefr=_ielts_cefr(overall) if overall!='' else ''

   if not student_id or not test_date:
    flash('Student ID and Test Date are required.')
    return xform(area,module)

   if overall=='':
    flash('Please enter valid Listening, Reading, Writing and Speaking band scores.')
    return xform(area,module)

   conn=get_db()
   conn.execute("""
    INSERT INTO academy_ielts
    (student_id,test_date,test_no,listening,reading,writing,speaking,overall_band,cefr,remarks,created_at)
    VALUES (?,?,?,?,?,?,?,?,?,?,?)
   """,(
    student_id,test_date,test_no,listening,reading,writing,speaking,
    str(overall),cefr,remarks,datetime.now().isoformat(timespec='seconds')
   ))
   conn.commit()
   conn.close()

   flash('IELTS test record added successfully.')
   return redirect(url_for('xlist_route',area=area,module=module))

  return xform(area,module)

 if request.method=='POST':
  title,fields=cfg
  vals=[request.form.get(k,'').strip() for k,_,_ in fields]
  table=('academy_' if area=='academy' else 'consultancy_')+module
  cols=','.join(k for k,_,_ in fields)
  ph=','.join('?' for _ in vals)
  conn=get_db()
  conn.execute(
   f'INSERT INTO {table} ({cols},created_at) VALUES ({ph},?)',
   vals+[datetime.now().isoformat(timespec='seconds')]
  )
  conn.commit()
  conn.close()
  flash(f'{title} record added successfully.')
  return redirect(url_for('xlist_route',area=area,module=module))

 return xform(area,module)
'''

source = source[:start] + new_xadd + source[end:]

# ------------------------------------------------------------
# 8. Replace xedit with IELTS-aware POST handling
# ------------------------------------------------------------

start = source.index("def xedit(area,module,item_id):")
end = source.index("\ndef xdelete(area,module,item_id):", start)

new_xedit = r'''def xedit(area,module,item_id):
 cfg=xcfg(area,module)
 if not cfg:return redirect(url_for('home'))

 title,fields=cfg
 table=('academy_' if area=='academy' else 'consultancy_')+module

 conn=get_db()
 row=conn.execute(
  f'SELECT * FROM {table} WHERE id=?',
  (item_id,)
 ).fetchone()

 if not row:
  conn.close()
  flash('Record not found.')
  return redirect(url_for('xlist_route',area=area,module=module))

 if area=="academy" and module=="ielts":
  if request.method=='POST':
   student_id=request.form.get('student_id','').strip()
   test_date=request.form.get('test_date','').strip()
   test_no=request.form.get('test_no','').strip()
   listening=request.form.get('listening','').strip()
   reading=request.form.get('reading','').strip()
   writing=request.form.get('writing','').strip()
   speaking=request.form.get('speaking','').strip()
   remarks=request.form.get('remarks','').strip()

   overall=_ielts_overall_from_form(request.form)
   cefr=_ielts_cefr(overall) if overall!='' else ''

   if not student_id or not test_date or overall=='':
    conn.close()
    flash('Student ID, Test Date and all four band scores are required.')
    return xform(area,module,row)

   conn.execute("""
    UPDATE academy_ielts
    SET student_id=?,
        test_date=?,
        test_no=?,
        listening=?,
        reading=?,
        writing=?,
        speaking=?,
        overall_band=?,
        cefr=?,
        remarks=?
    WHERE id=?
   """,(
    student_id,test_date,test_no,listening,reading,writing,speaking,
    str(overall),cefr,remarks,item_id
   ))
   conn.commit()
   conn.close()

   flash('IELTS test record updated successfully.')
   return redirect(url_for('xlist_route',area=area,module=module))

  conn.close()
  return xform(area,module,row)

 if request.method=='POST':
  vals=[request.form.get(k,'').strip() for k,_,_ in fields]
  sets=','.join(f'{k}=?' for k,_,_ in fields)
  conn.execute(
   f'UPDATE {table} SET {sets} WHERE id=?',
   vals+[item_id]
  )
  conn.commit()
  conn.close()
  flash(f'{title} record updated successfully.')
  return redirect(url_for('xlist_route',area=area,module=module))

 conn.close()
 return xform(area,module,row)
'''

source = source[:start] + new_xedit + source[end:]

# ------------------------------------------------------------
# 9. Preserve BOM when writing
# ------------------------------------------------------------

path.write_text(source, encoding="utf-8-sig")

print()
print("PATCH APPLIED SUCCESSFULLY")
print("File:", path)
print("Encoding: UTF-8 with BOM preserved")
print()
print("Next: syntax check will be run separately.")
print("=" * 70)
