from pathlib import Path

p = Path("smc_base.py")
s = p.read_text(encoding="utf-8")

old = """    html=f'''<h1>Exam Management</h1><div class="card"><form method="post" """

new = """    # Exams intelligence summary
    total_exams = len(rows)

    subjects = {
        str(r["subject"]).strip()
        for r in rows
        if r["subject"]
    }

    classes = {
        str(r["class_name"]).strip()
        for r in rows
        if r["class_name"]
    }

    total_marks_values = [
        float(r["total_marks"] or 0)
        for r in rows
        if r["total_marks"] is not None
    ]

    average_total_marks = (
        sum(total_marks_values) / len(total_marks_values)
        if total_marks_values else 0
    )

    today = date.today().isoformat()

    upcoming_exams = sum(
        1 for r in rows
        if r["exam_date"] and str(r["exam_date"]) >= today
    )

    exam_summary = f'''
    <div class="grid">
      <div class="stat"><h3>Total Exams</h3><h2>{total_exams}</h2></div>
      <div class="stat"><h3>Subjects</h3><h2>{len(subjects)}</h2></div>
      <div class="stat"><h3>Classes</h3><h2>{len(classes)}</h2></div>
      <div class="stat"><h3>Avg Total Marks</h3><h2>{average_total_marks:.1f}</h2></div>
      <div class="stat"><h3>Upcoming Exams</h3><h2>{upcoming_exams}</h2></div>
    </div>
    '''

    html=f'''<h1>Exam Management</h1>{exam_summary}<div class="card"><form method="post" """

if old not in s:
    raise SystemExit("TARGET NOT FOUND")

s = s.replace(old, new, 1)

p.write_text(s, encoding="utf-8")
print("EXAMS INTELLIGENCE ADDED")